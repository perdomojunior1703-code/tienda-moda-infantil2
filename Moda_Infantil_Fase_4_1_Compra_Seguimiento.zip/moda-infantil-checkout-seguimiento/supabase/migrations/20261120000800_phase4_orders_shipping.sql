-- MODA INFANTIL / FASE 4 — Pedidos por WhatsApp, seguimiento y envíos.
-- Ejecutar una sola vez DESPUÉS de 00700. No borra ni reemplaza datos.
-- REQUIERE las tablas/roles de Fases 1 y 2. Operaciones sensibles solo por RPC.
-- Los pedidos pendientes NO descuentan stock físico; reservan hasta 60 min.
-- Las reservas vencidas se excluyen de la disponibilidad sin depender de cron.

alter table public.orders add column if not exists request_id uuid;
create unique index if not exists orders_idempotency_idx on public.orders(user_id,request_id)
  where user_id is not null and request_id is not null;

-- Reducir el saldo público mostrado por las reservas vigentes. Nunca publicar datos personales.
create or replace function public.storefront_data()
returns jsonb language sql stable security definer set search_path = '' as $$
  select jsonb_build_object(
    'categories', coalesce((select jsonb_agg(jsonb_build_object(
      'id',c.id,'name',c.name,'slug',c.slug,'description',c.description,
      'image_path',c.image_path,'parent_id',c.parent_id) order by c.name)
      from public.categories c where c.is_active),'[]'::jsonb),
    'products', coalesce((select jsonb_agg(jsonb_build_object(
      'id',p.id,'category_id',p.category_id,'name',p.name,'slug',p.slug,
      'description',p.description,'sku',p.sku,'sale_price',p.sale_price,
      'previous_price',p.previous_price,'is_featured',p.is_featured,'is_new',p.is_new,
      'created_at',p.created_at) order by p.created_at desc)
      from public.products p left join public.categories c on c.id=p.category_id
      where p.is_active and p.deleted_at is null and (p.category_id is null or c.is_active)),'[]'::jsonb),
    'sizes',coalesce((select jsonb_agg(jsonb_build_object('id',s.id,'label',s.label,'sort_order',s.sort_order)
      order by s.sort_order,s.label) from public.sizes s),'[]'::jsonb),
    'colors',coalesce((select jsonb_agg(jsonb_build_object('id',c.id,'name',c.name,'hex_code',c.hex_code)
      order by c.name) from public.colors c),'[]'::jsonb),
    'variants',coalesce((select jsonb_agg(jsonb_build_object(
      'id',v.id,'product_id',v.product_id,'size_id',v.size_id,'color_id',v.color_id,
      'sku',v.sku,'price_override',v.price_override,
      'quantity',greatest(0,coalesce(i.quantity,0)-coalesce((
        select sum(r.quantity) from public.stock_reservations r
        where r.variant_id=v.id and r.status='reservada' and r.expires_at>now()
      ),0))) order by v.created_at)
      from public.product_variants v join public.products p on p.id=v.product_id
      left join public.categories c on c.id=p.category_id
      left join public.inventory i on i.variant_id=v.id
      where v.is_active and p.is_active and p.deleted_at is null
        and (p.category_id is null or c.is_active)),'[]'::jsonb),
    'images',coalesce((select jsonb_agg(jsonb_build_object(
      'id',im.id,'product_id',im.product_id,'storage_path',im.storage_path,
      'alt_text',im.alt_text,'sort_order',im.sort_order) order by im.sort_order,im.created_at)
      from public.product_images im join public.products p on p.id=im.product_id
      left join public.categories c on c.id=p.category_id
      where p.is_active and p.deleted_at is null
        and (p.category_id is null or c.is_active)),'[]'::jsonb),
    'banners',coalesce((select jsonb_agg(jsonb_build_object(
      'id',b.id,'title',b.title,'description',b.description,'image_path',b.image_path,
      'button_text',b.button_text,'target_url',b.target_url,'sort_order',b.sort_order)
      order by b.sort_order,b.created_at)
      from public.banners b where b.is_active and (b.starts_at is null or b.starts_at<=now())
        and (b.ends_at is null or b.ends_at>now())),'[]'::jsonb),
    'settings',(select jsonb_build_object('store_name',s.store_name,'logo_path',s.logo_path,
      'whatsapp',s.whatsapp,'phone',s.phone,'address',s.address,'city',s.city,
      'department',s.department,'opening_hours',s.opening_hours,'about_us',s.about_us,
      'instagram_url',s.instagram_url,'facebook_url',s.facebook_url,
      'shipping_information',s.shipping_information,'return_policy',s.return_policy)
      from public.store_settings s where s.id=1)
  );
$$;
revoke all on function public.storefront_data() from public;
grant execute on function public.storefront_data() to anon,authenticated;

-- Tarifas solo si el negocio las configuró. Recogida gratuita por definición.
create or replace function public.shipping_public_options()
returns jsonb language sql stable security definer set search_path = '' as $$
  select jsonb_build_object('rates',coalesce((select jsonb_agg(jsonb_build_object(
    'id',r.id,'method',r.shipping_method,'price',r.price,'zone_name',z.name,
    'city',z.city,'department',z.department) order by r.shipping_method,z.name)
    from public.shipping_rates r left join public.shipping_zones z on z.id=r.zone_id
    where r.is_active and z.is_active),'[]'::jsonb),
    'whatsapp',(select s.whatsapp from public.store_settings s where s.id=1));
$$;
revoke all on function public.shipping_public_options() from public;
grant execute on function public.shipping_public_options() to anon,authenticated;

create or replace function public.shipping_admin_data()
returns jsonb language plpgsql stable security definer set search_path = '' as $$
begin
  if not public.has_permission('shipping.manage') then raise exception 'Sin permiso para configurar entregas' using errcode='42501'; end if;
  return jsonb_build_object(
    'rates',coalesce((select jsonb_agg(jsonb_build_object('id',r.id,'zone_id',z.id,
      'zone_name',z.name,'city',z.city,'department',z.department,
      'method',r.shipping_method,'price',r.price,'active',r.is_active)
      order by r.created_at desc) from public.shipping_rates r
      left join public.shipping_zones z on z.id=r.zone_id),'[]'::jsonb),
    'carriers',coalesce((select jsonb_agg(jsonb_build_object('id',id,'name',name,'website',website,
      'active',is_active) order by name) from public.carriers),'[]'::jsonb),
    'whatsapp',(select whatsapp from public.store_settings where id=1));
end;
$$;

create or replace function public.shipping_save_rate(
  p_id uuid,p_name text,p_method text,p_price numeric,p_city text,p_department text,p_active boolean
) returns uuid language plpgsql security definer set search_path = '' as $$
declare v_id uuid; v_zone uuid;
begin
  if not public.has_permission('shipping.manage') then raise exception 'Sin permiso' using errcode='42501'; end if;
  if p_method not in ('domicilio_local','envio_nacional') then raise exception 'Modalidad inválida'; end if;
  if length(btrim(coalesce(p_name,''))) not between 3 and 120 then raise exception 'Nombre de zona inválido'; end if;
  if p_price is null or p_price<0 or p_price>10000000 or p_price<>round(p_price,2) then raise exception 'Tarifa inválida'; end if;
  if p_method='domicilio_local' and (length(btrim(coalesce(p_city,'')))<2 or length(btrim(coalesce(p_department,'')))<2) then
    raise exception 'El domicilio local requiere ciudad y departamento';
  end if;
  if p_id is null then
    insert into public.shipping_zones(name,city,department,is_active)
      values(btrim(p_name),nullif(btrim(coalesce(p_city,'')),''),nullif(btrim(coalesce(p_department,'')),''),true)
      returning id into v_zone;
    insert into public.shipping_rates(zone_id,shipping_method,price,is_active)
      values(v_zone,p_method,p_price,coalesce(p_active,true)) returning id into v_id;
  else
    select zone_id into v_zone from public.shipping_rates where id=p_id for update;
    if not found then raise exception 'Tarifa no encontrada'; end if;
    if v_zone is null then raise exception 'La tarifa no tiene zona asociada'; end if;
    update public.shipping_zones set name=btrim(p_name),city=nullif(btrim(coalesce(p_city,'')),''),
      department=nullif(btrim(coalesce(p_department,'')),'') where id=v_zone;
    update public.shipping_rates set shipping_method=p_method,price=p_price,
      is_active=coalesce(p_active,true) where id=p_id returning id into v_id;
  end if;
  insert into public.audit_logs(actor_id,action,entity_type,entity_id)
    values(auth.uid(),'envio.tarifa_guardada','shipping_rate',v_id);
  return v_id;
end;
$$;

create or replace function public.shipping_save_carrier(p_id uuid,p_name text,p_website text,p_active boolean)
returns uuid language plpgsql security definer set search_path = '' as $$
declare v_id uuid;
begin
  if not public.has_permission('shipping.manage') then raise exception 'Sin permiso' using errcode='42501'; end if;
  if length(btrim(coalesce(p_name,''))) not between 3 and 140 then raise exception 'Transportadora inválida'; end if;
  if nullif(btrim(coalesce(p_website,'')),'') is not null and p_website !~ '^https://[^[:space:]]+$' then raise exception 'Usa URL https://'; end if;
  if p_id is null then
    insert into public.carriers(name,website,is_active) values(btrim(p_name),nullif(btrim(coalesce(p_website,'')),''),coalesce(p_active,true)) returning id into v_id;
  else
    update public.carriers set name=btrim(p_name),website=nullif(btrim(coalesce(p_website,'')),''),
      is_active=coalesce(p_active,true) where id=p_id returning id into v_id;
    if v_id is null then raise exception 'Transportadora no encontrada'; end if;
  end if;
  return v_id;
end;
$$;

create or replace function public.shipping_save_whatsapp(p_whatsapp text)
returns void language plpgsql security definer set search_path = '' as $$
begin
  if not public.has_permission('store.configure') then raise exception 'Solo el administrador puede cambiar WhatsApp' using errcode='42501'; end if;
  if nullif(btrim(coalesce(p_whatsapp,'')),'') is not null and p_whatsapp !~ '^\+?[0-9 ]{10,18}$' then raise exception 'WhatsApp inválido; utiliza indicativo del país'; end if;
  update public.store_settings set whatsapp=nullif(btrim(coalesce(p_whatsapp,'')),'') where id=1;
  insert into public.audit_logs(actor_id,action,entity_type,details)
    values(auth.uid(),'tienda.whatsapp_actualizado','store_settings','{}'::jsonb);
end;
$$;

-- Registro idempotente de pedidos para usuarios autenticados (invitados quedan pendientes
-- hasta habilitar protección antispam/captcha en una Edge Function).
create or replace function public.orders_create_whatsapp(
  p_request_id uuid,p_items jsonb,p_contact_name text,p_contact_phone text,
  p_shipping_method text,p_shipping_rate_id uuid,p_address text,p_city text,
  p_department text,p_notes text
) returns jsonb language plpgsql security definer set search_path = '' as $$
declare v_user uuid := auth.uid(); v_order uuid := gen_random_uuid(); v_existing record;
  v_item record; v_qty integer; v_reserved integer; v_price numeric(12,2);
  v_subtotal numeric(12,2) := 0; v_shipping numeric(12,2) := 0; v_customer uuid;
  v_number text := 'MI-'||upper(left(replace(v_order::text,'-',''),12)); v_count integer;
begin
  if v_user is null then raise exception 'Inicia sesión para enviar un pedido' using errcode='42501'; end if;
  if p_request_id is null then raise exception 'Falta el identificador de solicitud'; end if;
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(v_user::text||p_request_id::text,0));
  select id,order_number into v_existing from public.orders where user_id=v_user and request_id=p_request_id;
  if found then return jsonb_build_object('id',v_existing.id,'number',v_existing.order_number,'repeated',true); end if;
  if p_items is null or jsonb_typeof(p_items)<>'array' or jsonb_array_length(p_items) not between 1 and 30 then
    raise exception 'El pedido debe tener entre 1 y 30 variantes';
  end if;
  select count(*) into v_count from jsonb_to_recordset(p_items) as t(variant_id uuid,quantity integer);
  if v_count <> (select count(distinct variant_id) from jsonb_to_recordset(p_items) as t(variant_id uuid,quantity integer)) then
    raise exception 'No repitas variantes dentro del mismo pedido';
  end if;
  if exists(select 1 from jsonb_to_recordset(p_items) as t(variant_id uuid,quantity integer)
      where variant_id is null or quantity is null or quantity not between 1 and 100) then
    raise exception 'Cantidades inválidas';
  end if;
  if (select count(*) from public.orders where user_id=v_user
      and order_status='pendiente' and created_at>now()-interval '15 minutes')>=5 then
    raise exception 'Demasiados pedidos recientes. Intenta más tarde'; end if;
  if length(btrim(coalesce(p_contact_name,''))) not between 3 and 140 then raise exception 'Ingresa tu nombre completo'; end if;
  if replace(replace(coalesce(p_contact_phone,''),' ',''),'+','') !~ '^[0-9]{10,15}$' then raise exception 'Teléfono inválido'; end if;
  if p_shipping_method not in ('recogida','domicilio_local','envio_nacional') then raise exception 'Modalidad inválida'; end if;
  if length(coalesce(p_notes,''))>1000 then raise exception 'Observaciones demasiado largas'; end if;
  if p_shipping_method='recogida' then
    if p_shipping_rate_id is not null then raise exception 'Recogida no requiere tarifa'; end if;
  else
    if length(btrim(coalesce(p_address,'')))<5 or length(btrim(coalesce(p_city,'')))<2
      or length(btrim(coalesce(p_department,'')))<2 then raise exception 'Completa la dirección de entrega'; end if;
    select r.price into v_shipping from public.shipping_rates r
      join public.shipping_zones z on z.id=r.zone_id
      where r.id=p_shipping_rate_id and r.is_active and z.is_active
        and r.shipping_method=p_shipping_method
        and (z.city is null or lower(btrim(z.city))=lower(btrim(p_city)))
        and (z.department is null or lower(btrim(z.department))=lower(btrim(p_department)));
    if not found then raise exception 'Selecciona una tarifa válida para tu ciudad y departamento'; end if;
  end if;
  -- Bloqueos de inventario ordenados: evita reservas simultáneas sobre la última unidad.
  for v_item in select variant_id from jsonb_to_recordset(p_items) as t(variant_id uuid,quantity integer)
    order by variant_id loop
    perform 1 from public.inventory i where i.variant_id=v_item.variant_id for update;
    if not found then raise exception 'Una variante no tiene inventario disponible'; end if;
  end loop;
  insert into public.customers(user_id,full_name,email,phone)
    values(v_user,btrim(p_contact_name),(select email from auth.users where id=v_user),btrim(p_contact_phone))
    on conflict(user_id) do update set full_name=excluded.full_name,phone=excluded.phone
    returning id into v_customer;
  insert into public.orders(id,order_number,user_id,customer_id,channel,shipping_method,shipping_address,
    customer_notes,shipping_amount,request_id)
    values(v_order,v_number,v_user,v_customer,'whatsapp',p_shipping_method,
      case when p_shipping_method='recogida' then null else jsonb_build_object(
        'address',btrim(p_address),'city',btrim(p_city),'department',btrim(p_department)) end,
      nullif(btrim(coalesce(p_notes,'')),''),v_shipping,p_request_id);
  for v_item in select variant_id,quantity from jsonb_to_recordset(p_items) as t(variant_id uuid,quantity integer)
    order by variant_id loop
    select greatest(0,i.quantity - coalesce((select sum(r.quantity)
      from public.stock_reservations r where r.variant_id=i.variant_id
        and r.status='reservada' and r.expires_at>now()),0)),
      coalesce(v.price_override,p.sale_price)
      into v_qty,v_price
      from public.product_variants v join public.products p on p.id=v.product_id
      left join public.categories c on c.id=p.category_id
      join public.inventory i on i.variant_id=v.id
      where v.id=v_item.variant_id and v.is_active and p.is_active and p.deleted_at is null
        and (p.category_id is null or c.is_active);
    if not found or v_qty<v_item.quantity then raise exception 'No hay existencias suficientes para una variante'; end if;
    insert into public.order_items(order_id,variant_id,product_name_snapshot,sku_snapshot,size_snapshot,
      color_snapshot,quantity,unit_price,line_total)
      select v_order,v.id,p.name,v.sku,s.label,c.name,v_item.quantity,v_price,v_price*v_item.quantity
      from public.product_variants v join public.products p on p.id=v.product_id
      join public.sizes s on s.id=v.size_id join public.colors c on c.id=v.color_id where v.id=v_item.variant_id;
    insert into public.stock_reservations(order_id,variant_id,quantity,expires_at)
      values(v_order,v_item.variant_id,v_item.quantity,now()+interval '60 minutes');
    v_subtotal:=v_subtotal+v_price*v_item.quantity;
  end loop;
  update public.orders set subtotal=v_subtotal,total=v_subtotal+v_shipping where id=v_order;
  insert into public.shipments(order_id,shipping_method,shipping_cost)
    values(v_order,p_shipping_method,v_shipping);
  insert into public.order_status_history(order_id,new_status,reason)
    values(v_order,'pendiente','Pedido enviado para conversación por WhatsApp');
  return jsonb_build_object('id',v_order,'number',v_number,'repeated',false,
    'subtotal',v_subtotal,'shipping',v_shipping,'total',v_subtotal+v_shipping);
end;
$$;

create or replace function public.orders_list(p_scope text default 'mine')
returns jsonb language plpgsql stable security definer set search_path = '' as $$
declare v_user uuid := auth.uid();
begin
  if v_user is null then raise exception 'Inicia sesión' using errcode='42501'; end if;
  if p_scope not in ('mine','staff') then raise exception 'Consulta inválida'; end if;
  if p_scope='staff' and not public.has_permission('orders.read') then
    raise exception 'Sin permiso para ver pedidos' using errcode='42501'; end if;
  return coalesce((select jsonb_agg(jsonb_build_object(
    'id',o.id,'number',o.order_number,'status',o.order_status,'payment',o.payment_status,
    'channel',o.channel,'subtotal',o.subtotal,'shipping',o.shipping_amount,'total',o.total,
    'method',o.shipping_method,'address',o.shipping_address,'notes',o.customer_notes,
    'created_at',o.created_at,'name',c.full_name,'phone',c.phone,
    'tracking_number',sh.tracking_number,'carrier',ca.name,
    'items',coalesce((select jsonb_agg(jsonb_build_object('name',it.product_name_snapshot,
       'sku',it.sku_snapshot,'size',it.size_snapshot,'color',it.color_snapshot,
       'quantity',it.quantity,'price',it.unit_price,'total',it.line_total) order by it.product_name_snapshot)
       from public.order_items it where it.order_id=o.id),'[]'::jsonb),
    'history',coalesce((select jsonb_agg(jsonb_build_object('status',h.new_status,'reason',h.reason,
       'at',h.changed_at) order by h.changed_at)
       from public.order_status_history h where h.order_id=o.id),'[]'::jsonb)
   ) order by o.created_at desc) from (
     select * from public.orders where (p_scope='staff' or user_id=v_user)
     order by created_at desc limit 200
   ) o left join public.customers c on c.id=o.customer_id
   left join public.shipments sh on sh.order_id=o.id
   left join public.carriers ca on ca.id=sh.carrier_id),'[]'::jsonb);
end;
$$;

create or replace function public.orders_change_status(
  p_order_id uuid,p_status text,p_reason text default null,p_carrier_id uuid default null,
  p_tracking_number text default null
) returns void language plpgsql security definer set search_path = '' as $$
declare o record; it record; v_qty integer; v_reserved integer; v_after integer; v_old text;
begin
  if not public.has_permission('orders.manage') then raise exception 'Sin permiso para gestionar pedidos' using errcode='42501'; end if;
  select * into o from public.orders where id=p_order_id for update;
  if not found then raise exception 'Pedido no encontrado'; end if;
  if o.channel<>'whatsapp' then raise exception 'Esta operación es solo para pedidos por WhatsApp'; end if;
  v_old:=o.order_status;
  if p_status=v_old then return; end if;
  if not ((v_old='pendiente' and p_status in ('confirmado','cancelado')) or
    (v_old='confirmado' and p_status in ('en_preparacion','cancelado')) or
    (v_old='en_preparacion' and p_status in ('enviado','entregado','cancelado')) or
    (v_old='enviado' and p_status='entregado')) then
    raise exception 'Transición de estado no permitida'; end if;
  if p_status='enviado' and o.shipping_method='recogida' then
    raise exception 'La recogida en tienda no requiere estado enviado'; end if;
  if p_status='cancelado' and length(btrim(coalesce(p_reason,'')))<5 then
    raise exception 'Indica el motivo de cancelación (mínimo 5 caracteres)'; end if;
  if p_tracking_number is not null and length(p_tracking_number)>100 then raise exception 'Número de guía demasiado largo'; end if;
  -- Bloquear existencias en orden estable antes de confirmar/restaurar stock.
  if p_status in ('confirmado','cancelado') then
    for it in select variant_id from public.order_items where order_id=p_order_id order by variant_id loop
      perform 1 from public.inventory where variant_id=it.variant_id for update;
      if not found then raise exception 'Variante sin inventario'; end if;
    end loop;
  end if;
  if p_status='confirmado' then
    for it in select variant_id,quantity from public.order_items where order_id=p_order_id order by variant_id loop
      select i.quantity - coalesce((select sum(r.quantity) from public.stock_reservations r
        where r.variant_id=i.variant_id and r.order_id<>p_order_id and r.status='reservada'
        and r.expires_at>now()),0) into v_qty
        from public.inventory i where i.variant_id=it.variant_id;
      if v_qty<it.quantity then raise exception 'Inventario insuficiente: no puedes confirmar este pedido'; end if;
      update public.inventory set quantity=quantity-it.quantity where variant_id=it.variant_id returning quantity into v_after;
      insert into public.inventory_movements(variant_id,movement_type,quantity_delta,balance_after,
        reason,source_type,source_id,actor_id)
        values(it.variant_id,'salida',-it.quantity,v_after,'Confirmación de pedido '||o.order_number,
          'pedido',p_order_id,auth.uid());
    end loop;
    update public.stock_reservations set status='confirmada' where order_id=p_order_id;
  elsif p_status='cancelado' then
    if v_old<>'pendiente' then
      for it in select variant_id,quantity from public.order_items where order_id=p_order_id order by variant_id loop
        update public.inventory set quantity=quantity+it.quantity where variant_id=it.variant_id returning quantity into v_after;
        insert into public.inventory_movements(variant_id,movement_type,quantity_delta,balance_after,
          reason,source_type,source_id,actor_id)
          values(it.variant_id,'devolucion',it.quantity,v_after,'Cancelación de pedido '||o.order_number,
            'pedido',p_order_id,auth.uid());
      end loop;
    end if;
    update public.stock_reservations set status='liberada' where order_id=p_order_id and status='reservada';
  end if;
  update public.orders set order_status=p_status where id=p_order_id;
  if p_status='enviado' then
    update public.shipments set shipping_status='enviado',tracking_number=nullif(btrim(coalesce(p_tracking_number,'')),''),
      carrier_id=p_carrier_id,shipped_at=now() where order_id=p_order_id;
  elsif p_status='entregado' then
    update public.shipments set shipping_status='entregado',delivered_at=now() where order_id=p_order_id;
  elsif p_status='cancelado' then
    update public.shipments set shipping_status='cancelado' where order_id=p_order_id;
  end if;
  insert into public.order_status_history(order_id,previous_status,new_status,changed_by,reason)
    values(p_order_id,v_old,p_status,auth.uid(),nullif(btrim(coalesce(p_reason,'')),''));
  insert into public.audit_logs(actor_id,action,entity_type,entity_id,details)
    values(auth.uid(),'pedido.estado','order',p_order_id,
      jsonb_build_object('from',v_old,'to',p_status));
end;
$$;

-- No se conceden permisos de escritura directa a orders, items, inventory ni shipment.
revoke all on function public.shipping_admin_data() from public,anon;
revoke all on function public.shipping_save_rate(uuid,text,text,numeric,text,text,boolean) from public,anon;
revoke all on function public.shipping_save_carrier(uuid,text,text,boolean) from public,anon;
revoke all on function public.shipping_save_whatsapp(text) from public,anon;
revoke all on function public.orders_create_whatsapp(uuid,jsonb,text,text,text,uuid,text,text,text,text) from public,anon;
revoke all on function public.orders_list(text) from public,anon;
revoke all on function public.orders_change_status(uuid,text,text,uuid,text) from public,anon;
grant execute on function public.shipping_admin_data() to authenticated;
grant execute on function public.shipping_save_rate(uuid,text,text,numeric,text,text,boolean) to authenticated;
grant execute on function public.shipping_save_carrier(uuid,text,text,boolean) to authenticated;
grant execute on function public.shipping_save_whatsapp(text) to authenticated;
grant execute on function public.orders_create_whatsapp(uuid,jsonb,text,text,text,uuid,text,text,text,text) to authenticated;
grant execute on function public.orders_list(text) to authenticated;
grant execute on function public.orders_change_status(uuid,text,text,uuid,text) to authenticated;

-- Actualiza caché PostgREST después de crear funciones.
notify pgrst, 'reload schema';
