-- MODA INFANTIL / FASE 1 / Identidad y RBAC
-- Ejecutar primero. Nunca poner la clave secret/service_role en React.

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name varchar(120) not null default '',
  phone varchar(25),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.roles (
  code text primary key,
  name text not null,
  description text not null default ''
);

create table public.permissions (
  code text primary key,
  description text not null default ''
);

create table public.role_permissions (
  role_code text not null references public.roles(code) on delete cascade,
  permission_code text not null references public.permissions(code) on delete cascade,
  primary key (role_code, permission_code)
);

create table public.user_roles (
  user_id uuid not null references auth.users(id) on delete cascade,
  role_code text not null references public.roles(code),
  assigned_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  primary key (user_id, role_code)
);
create index user_roles_role_idx on public.user_roles(role_code);

insert into public.roles (code, name, description) values
  ('administrador', 'Administrador', 'Control general de la aplicación'),
  ('supervisor', 'Supervisor', 'Supervisión de operaciones autorizadas'),
  ('cajero', 'Cajero', 'Ventas presenciales y control de caja'),
  ('inventario', 'Encargado de inventario', 'Productos, variantes y existencias'),
  ('cliente', 'Cliente', 'Tienda, perfil y pedidos propios');

insert into public.permissions (code, description) values
  ('panel.access', 'Entrar al panel privado'),
  ('dashboard.view', 'Consultar indicadores del panel'),
  ('catalog.read', 'Consultar catálogo de gestión'),
  ('catalog.manage', 'Administrar productos y categorías'),
  ('inventory.read', 'Consultar existencias y movimientos'),
  ('inventory.adjust', 'Registrar ajustes de inventario'),
  ('orders.read', 'Consultar pedidos de operación'),
  ('orders.manage', 'Gestionar pedidos y su estado'),
  ('pos.sell', 'Realizar ventas presenciales'),
  ('pos.read', 'Consultar ventas presenciales'),
  ('cash.manage', 'Administrar aperturas y cierres de caja'),
  ('returns.manage', 'Aprobar y registrar devoluciones'),
  ('returns.request', 'Solicitar una devolución'),
  ('customers.read', 'Consultar clientes según autorización'),
  ('reports.view', 'Consultar reportes'),
  ('banners.manage', 'Administrar banners y promociones'),
  ('shipping.manage', 'Administrar envíos y tarifas'),
  ('store.configure', 'Editar configuración del almacén'),
  ('roles.manage', 'Administrar personal y roles'),
  ('audit.read', 'Consultar auditoría'),
  ('store.browse', 'Explorar la tienda'),
  ('cart.manage', 'Administrar carrito propio'),
  ('favorites.manage', 'Administrar favoritos propios'),
  ('orders.own', 'Consultar pedidos propios'),
  ('profile.manage', 'Actualizar perfil propio');

-- El administrador dispone de todo el conjunto de permisos.
insert into public.role_permissions (role_code, permission_code)
select 'administrador', code from public.permissions;

insert into public.role_permissions (role_code, permission_code) values
  ('supervisor','panel.access'), ('supervisor','dashboard.view'),
  ('supervisor','catalog.read'), ('supervisor','inventory.read'),
  ('supervisor','inventory.adjust'), ('supervisor','orders.read'),
  ('supervisor','orders.manage'), ('supervisor','pos.read'),
  ('supervisor','cash.manage'), ('supervisor','returns.manage'),
  ('supervisor','customers.read'), ('supervisor','reports.view'),
  ('supervisor','shipping.manage'),
  ('cajero','panel.access'), ('cajero','catalog.read'),
  ('cajero','inventory.read'), ('cajero','orders.read'),
  ('cajero','pos.sell'), ('cajero','pos.read'),
  ('cajero','cash.manage'), ('cajero','returns.request'),
  ('inventario','panel.access'), ('inventario','catalog.read'),
  ('inventario','catalog.manage'), ('inventario','inventory.read'),
  ('inventario','inventory.adjust'), ('inventario','orders.read'),
  ('cliente','store.browse'), ('cliente','cart.manage'),
  ('cliente','favorites.manage'), ('cliente','orders.own'),
  ('cliente','profile.manage');

create or replace function public.touch_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;
create trigger profiles_touch_updated_at
before update on public.profiles
for each row execute function public.touch_updated_at();

-- Se ejecuta dentro de la transacción de creación de auth.users.
-- Los metadatos del usuario jamás determinan un rol privilegiado.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, left(coalesce(new.raw_user_meta_data ->> 'full_name', ''), 120))
  on conflict (id) do nothing;
  insert into public.user_roles (user_id, role_code)
  values (new.id, 'cliente')
  on conflict (user_id, role_code) do nothing;
  return new;
end;
$$;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Utilizar las tablas RBAC como autoridad al consultar permisos:
-- evita que un JWT con rol antiguo otorgue privilegios por error.
create or replace function public.has_permission(requested_permission text)
returns boolean
language sql stable security definer
set search_path = ''
as $$
  select (select auth.uid()) is not null and exists (
    select 1
    from public.user_roles ur
    join public.role_permissions rp on rp.role_code = ur.role_code
    where ur.user_id = (select auth.uid())
      and rp.permission_code = requested_permission
  );
$$;

create or replace function public.get_my_access()
returns jsonb
language sql stable security definer
set search_path = ''
as $$
  select jsonb_build_object(
    'roles', coalesce((
      select jsonb_agg(ur.role_code order by ur.role_code)
      from public.user_roles ur
      where ur.user_id = (select auth.uid())
    ), '[]'::jsonb),
    'permissions', coalesce((
      select jsonb_agg(p.permission_code order by p.permission_code)
      from (
        select distinct rp.permission_code
        from public.user_roles ur
        join public.role_permissions rp on rp.role_code = ur.role_code
        where ur.user_id = (select auth.uid())
      ) p
    ), '[]'::jsonb)
  );
$$;

-- RBAC: lectura de perfil propio, sin ninguna vía pública de escritura de roles.
alter table public.profiles enable row level security;
alter table public.roles enable row level security;
alter table public.permissions enable row level security;
alter table public.role_permissions enable row level security;
alter table public.user_roles enable row level security;

create policy profiles_select_own on public.profiles
  for select to authenticated using ((select auth.uid()) = id);
create policy profiles_update_own on public.profiles
  for update to authenticated
  using ((select auth.uid()) = id)
  with check ((select auth.uid()) = id);

-- Revocar escritura sobre datos de seguridad y limitar columnas del perfil.
revoke all on table public.profiles from anon, authenticated;
grant select (id, full_name, phone, created_at, updated_at) on public.profiles to authenticated;
grant update (full_name, phone) on public.profiles to authenticated;
revoke all on table public.roles, public.permissions, public.role_permissions, public.user_roles from anon, authenticated;

revoke execute on function public.handle_new_user() from public, anon, authenticated;
revoke execute on function public.touch_updated_at() from public, anon, authenticated;
revoke execute on function public.has_permission(text) from public, anon;
revoke execute on function public.get_my_access() from public, anon;
grant execute on function public.has_permission(text) to authenticated;
grant execute on function public.get_my_access() to authenticated;

-- Nota: los roles de empleado se asignan exclusivamente con un proceso
-- administrativo autorizado (ver supabase/manual/bootstrap_admin.sql).
