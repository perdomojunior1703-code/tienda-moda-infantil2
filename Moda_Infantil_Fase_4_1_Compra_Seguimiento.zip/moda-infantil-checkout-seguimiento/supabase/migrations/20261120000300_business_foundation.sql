-- MODA INFANTIL / FASE 1 / Modelo relacional de las fases 3 a 6.
-- Esquema protegido SIN endpoints operativos. Las políticas y transacciones
-- específicas se desarrollarán al implementar cada módulo.

-- Datos del comercio y contenidos visibles.
create table public.store_settings (
  id smallint primary key default 1 check (id = 1),
  store_name varchar(150) not null default 'Moda Infantil',
  logo_path text,
  whatsapp varchar(30),
  phone varchar(30),
  address text,
  city varchar(100),
  department varchar(100),
  opening_hours text,
  about_us text,
  instagram_url text,
  facebook_url text,
  shipping_information text,
  return_policy text,
  updated_at timestamptz not null default now()
);
insert into public.store_settings (id, store_name) values (1, 'Moda Infantil');
create trigger store_settings_touch_updated_at before update on public.store_settings
for each row execute function public.touch_updated_at();

create table public.banners (
  id uuid primary key default gen_random_uuid(),
  title varchar(160) not null,
  description text,
  image_path text not null,
  button_text varchar(70),
  target_url text,
  sort_order integer not null default 0,
  is_active boolean not null default false,
  starts_at timestamptz,
  ends_at timestamptz,
  created_at timestamptz not null default now(),
  check (ends_at is null or starts_at is null or ends_at > starts_at)
);
create table public.product_discounts (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete restrict,
  discount_kind text not null check (discount_kind in ('porcentaje','monto')),
  discount_value numeric(12,2) not null check (discount_value >= 0),
  starts_at timestamptz,
  ends_at timestamptz,
  is_active boolean not null default false,
  created_at timestamptz not null default now(),
  check (discount_kind <> 'porcentaje' or discount_value <= 100),
  check (ends_at is null or starts_at is null or ends_at > starts_at)
);
create index discounts_product_idx on public.product_discounts(product_id);

-- Clientes pueden no tener una cuenta auth (comprador ocasional).
create table public.customers (
  id uuid primary key default gen_random_uuid(),
  user_id uuid unique references auth.users(id) on delete set null,
  full_name varchar(140) not null,
  email varchar(254),
  phone varchar(30),
  status text not null default 'activo' check (status in ('activo','inactivo')),
  created_at timestamptz not null default now()
);
create table public.customer_addresses (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.customers(id) on delete cascade,
  label varchar(60),
  recipient varchar(140),
  street_address text not null,
  city varchar(100) not null,
  department varchar(100) not null,
  detail text,
  is_default boolean not null default false
);
create index customer_addresses_customer_idx on public.customer_addresses(customer_id);
create table public.favorites (
  user_id uuid not null references auth.users(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, product_id)
);
create table public.carts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid unique references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table public.cart_items (
  id uuid primary key default gen_random_uuid(),
  cart_id uuid not null references public.carts(id) on delete cascade,
  variant_id uuid not null references public.product_variants(id) on delete restrict,
  quantity integer not null check (quantity > 0),
  unique (cart_id, variant_id)
);
create index cart_items_variant_idx on public.cart_items(variant_id);

-- Envíos y zonas de tarifa configuradas manualmente.
create table public.shipping_zones (
  id uuid primary key default gen_random_uuid(),
  name varchar(120) not null,
  city varchar(100),
  department varchar(100),
  is_active boolean not null default true
);
create table public.carriers (
  id uuid primary key default gen_random_uuid(),
  name varchar(140) not null unique,
  website text,
  tracking_url_template text,
  is_active boolean not null default true
);
create table public.shipping_rates (
  id uuid primary key default gen_random_uuid(),
  zone_id uuid references public.shipping_zones(id) on delete restrict,
  shipping_method text not null check (shipping_method in ('recogida','domicilio_local','envio_nacional')),
  price numeric(12,2) not null check (price >= 0),
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

-- Pedido y pago son estados independientes.
create table public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number varchar(40) not null unique,
  user_id uuid references auth.users(id) on delete set null,
  customer_id uuid references public.customers(id) on delete set null,
  channel text not null check (channel in ('online','whatsapp','pos')),
  order_status text not null default 'pendiente' check (order_status in ('pendiente','confirmado','en_preparacion','enviado','entregado','cancelado')),
  payment_status text not null default 'pendiente' check (payment_status in ('pendiente','pagado','parcial','reembolsado','fallido','cancelado')),
  subtotal numeric(12,2) not null default 0 check (subtotal >= 0),
  discount_amount numeric(12,2) not null default 0 check (discount_amount >= 0),
  shipping_amount numeric(12,2) not null default 0 check (shipping_amount >= 0),
  total numeric(12,2) not null default 0 check (total >= 0),
  shipping_method text check (shipping_method in ('recogida','domicilio_local','envio_nacional')),
  shipping_address jsonb,
  guest_lookup_hash text,
  customer_notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (discount_amount <= subtotal)
);
create index orders_user_time_idx on public.orders(user_id, created_at desc);
create index orders_customer_idx on public.orders(customer_id);
create index orders_status_idx on public.orders(order_status, created_at desc);
create trigger orders_touch_updated_at before update on public.orders
for each row execute function public.touch_updated_at();

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete restrict,
  variant_id uuid references public.product_variants(id) on delete restrict,
  product_name_snapshot varchar(180) not null,
  sku_snapshot varchar(80),
  size_snapshot varchar(40),
  color_snapshot varchar(70),
  quantity integer not null check (quantity > 0),
  unit_price numeric(12,2) not null check (unit_price >= 0),
  discount_amount numeric(12,2) not null default 0 check (discount_amount >= 0),
  line_total numeric(12,2) not null check (line_total >= 0)
);
create index order_items_order_idx on public.order_items(order_id);

create table public.order_status_history (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete restrict,
  previous_status text,
  new_status text not null,
  changed_by uuid references auth.users(id) on delete set null,
  reason text,
  changed_at timestamptz not null default now()
);
create index order_history_idx on public.order_status_history(order_id, changed_at desc);

create table public.stock_reservations (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete restrict,
  variant_id uuid not null references public.product_variants(id) on delete restrict,
  quantity integer not null check (quantity > 0),
  status text not null default 'reservada' check (status in ('reservada','confirmada','liberada','expirada')),
  expires_at timestamptz not null,
  created_at timestamptz not null default now(),
  unique (order_id, variant_id)
);
create index stock_reservations_expiry_idx on public.stock_reservations(expires_at)
where status = 'reservada';

create table public.payments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid references public.orders(id) on delete restrict,
  sale_id uuid,
  method text not null check (method in ('efectivo','transferencia','nequi','daviplata','tarjeta','pasarela')),
  amount numeric(12,2) not null check (amount > 0),
  status text not null default 'pendiente' check (status in ('pendiente','registrado','confirmado','rechazado','reembolsado')),
  received_by uuid references auth.users(id) on delete set null,
  recorded_at timestamptz not null default now(),
  check (num_nonnulls(order_id, sale_id) = 1)
);
create index payments_order_idx on public.payments(order_id);

create table public.payment_transactions (
  id uuid primary key default gen_random_uuid(),
  payment_id uuid not null references public.payments(id) on delete restrict,
  provider varchar(80),
  provider_reference text,
  idempotency_key text unique,
  provider_status text,
  verified_at timestamptz,
  recorded_at timestamptz not null default now()
);
create index payment_transactions_payment_idx on public.payment_transactions(payment_id);

create table public.shipments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null unique references public.orders(id) on delete restrict,
  carrier_id uuid references public.carriers(id) on delete set null,
  tracking_number text,
  shipping_method text not null check (shipping_method in ('recogida','domicilio_local','envio_nacional')),
  shipping_status text not null default 'pendiente',
  shipping_cost numeric(12,2) not null default 0 check (shipping_cost >= 0),
  shipped_at timestamptz,
  delivered_at timestamptz,
  notes text
);

-- POS, caja y devoluciones.
create table public.cash_registers (
  id uuid primary key default gen_random_uuid(),
  name varchar(100) not null unique,
  is_active boolean not null default true
);
create table public.cash_shifts (
  id uuid primary key default gen_random_uuid(),
  register_id uuid not null references public.cash_registers(id) on delete restrict,
  cashier_id uuid not null references auth.users(id) on delete restrict,
  opened_at timestamptz not null default now(),
  closed_at timestamptz,
  opening_cash numeric(12,2) not null check (opening_cash >= 0),
  counted_cash numeric(12,2) check (counted_cash >= 0),
  expected_cash numeric(12,2) check (expected_cash >= 0),
  close_notes text,
  check (closed_at is null or closed_at >= opened_at)
);
create unique index one_open_shift_per_register_idx
  on public.cash_shifts(register_id) where closed_at is null;
create index cash_shifts_cashier_idx on public.cash_shifts(cashier_id, opened_at desc);

create table public.sales (
  id uuid primary key default gen_random_uuid(),
  sale_number varchar(40) not null unique,
  order_id uuid unique references public.orders(id) on delete restrict,
  customer_id uuid references public.customers(id) on delete set null,
  shift_id uuid not null references public.cash_shifts(id) on delete restrict,
  cashier_id uuid not null references auth.users(id) on delete restrict,
  subtotal numeric(12,2) not null check (subtotal >= 0),
  discount_amount numeric(12,2) not null default 0 check (discount_amount >= 0),
  total numeric(12,2) not null check (total >= 0),
  created_at timestamptz not null default now(),
  check (discount_amount <= subtotal)
);
create index sales_shift_idx on public.sales(shift_id, created_at desc);
create index sales_customer_idx on public.sales(customer_id);
-- Se crea la FK inversa al existir sales.
alter table public.payments add constraint payments_sale_fk
foreign key (sale_id) references public.sales(id) on delete restrict;

create table public.sale_items (
  id uuid primary key default gen_random_uuid(),
  sale_id uuid not null references public.sales(id) on delete restrict,
  variant_id uuid references public.product_variants(id) on delete restrict,
  product_name_snapshot varchar(180) not null,
  size_snapshot varchar(40),
  color_snapshot varchar(70),
  quantity integer not null check (quantity > 0),
  unit_price numeric(12,2) not null check (unit_price >= 0),
  cost_price_snapshot numeric(12,2) check (cost_price_snapshot >= 0),
  discount_amount numeric(12,2) not null default 0 check (discount_amount >= 0),
  line_total numeric(12,2) not null check (line_total >= 0)
);
create index sale_items_sale_idx on public.sale_items(sale_id);

create table public.cash_movements (
  id uuid primary key default gen_random_uuid(),
  shift_id uuid not null references public.cash_shifts(id) on delete restrict,
  movement_type text not null check (movement_type in ('ingreso','egreso')),
  amount numeric(12,2) not null check (amount > 0),
  reason text not null,
  actor_id uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now()
);
create index cash_movements_shift_idx on public.cash_movements(shift_id, created_at desc);

create table public.returns (
  id uuid primary key default gen_random_uuid(),
  sale_id uuid not null references public.sales(id) on delete restrict,
  processed_by uuid references auth.users(id) on delete set null,
  return_kind text not null check (return_kind in ('devolucion','cambio')),
  status text not null default 'pendiente' check (status in ('pendiente','aprobada','rechazada','procesada')),
  reason text not null,
  refund_amount numeric(12,2) not null default 0 check (refund_amount >= 0),
  created_at timestamptz not null default now()
);
create table public.return_items (
  id uuid primary key default gen_random_uuid(),
  return_id uuid not null references public.returns(id) on delete restrict,
  sale_item_id uuid not null references public.sale_items(id) on delete restrict,
  quantity integer not null check (quantity > 0),
  physical_condition text not null check (physical_condition in ('apto','danado','en_revision')),
  restocked boolean not null default false,
  unique (return_id, sale_item_id)
);
create index return_items_sale_item_idx on public.return_items(sale_item_id);

create table public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references auth.users(id) on delete set null,
  action varchar(100) not null,
  entity_type varchar(100) not null,
  entity_id uuid,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index audit_logs_time_idx on public.audit_logs(created_at desc);

-- Denegación por defecto en TODOS los nuevos módulos sensibles.
-- Habilitar RLS sin políticas operativas es intencional y seguro mientras
-- se implementan las funciones específicas en fases 2–6.
do $$
declare table_name text;
begin
  foreach table_name in array array[
    'store_settings','banners','product_discounts','customers','customer_addresses',
    'favorites','carts','cart_items','shipping_zones','carriers','shipping_rates',
    'orders','order_items','order_status_history','stock_reservations',
    'payments','payment_transactions','shipments','cash_registers','cash_shifts',
    'sales','sale_items','cash_movements','returns','return_items','audit_logs'
  ] loop
    execute format('alter table public.%I enable row level security', table_name);
    execute format('revoke all on table public.%I from anon, authenticated', table_name);
  end loop;
end;
$$;

-- Solo datos comerciales visibles (no personales) en modo lectura.
create policy public_store_settings_read on public.store_settings
for select to anon, authenticated using (id = 1);
grant select on public.store_settings to anon, authenticated;

create policy public_active_banners_read on public.banners
for select to anon, authenticated using (
  is_active and (starts_at is null or starts_at <= now())
  and (ends_at is null or ends_at > now())
);
grant select on public.banners to anon, authenticated;

-- Nada de INSERT/UPDATE/DELETE cliente hasta las fases correspondientes.
