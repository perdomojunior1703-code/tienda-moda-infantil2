-- MODA INFANTIL / FASE 2: Catálogo y movimientos de inventario.
-- Ejecutar UNA vez, DESPUÉS de las 5 migraciones de Fase 1.
-- No borra tablas ni perfiles. Todas las escrituras se realizan mediante RPC autenticadas.

-- Semillas de tallas y colores, editables desde el panel.
insert into public.sizes (label, sort_order) values
 ('0-3M',1),('3-6M',2),('6-12M',3),('12-18M',4),('2',5),('4',6),('6',7),('8',8),('10',9),('12',10),('14',11),('16',12),('Única',13)
on conflict (label) do nothing;
insert into public.colors (name, hex_code) values
 ('Rojo','#E53935'),('Blanco','#FFFFFF'),('Negro','#292929'),('Azul','#2563EB'),('Rosa','#EC4899'),('Verde','#16A34A'),('Amarillo','#FACC15'),('Gris','#94A3B8')
on conflict (name) do nothing;

-- Lectura de registros desactivados sólo para personal con permiso; no acceso de clientes a costos.
create policy categories_staff_read on public.categories for select to authenticated
  using (public.has_permission('catalog.read'));
create policy products_staff_read on public.products for select to authenticated
  using (public.has_permission('catalog.read'));
create policy product_images_staff_read on public.product_images for select to authenticated
  using (public.has_permission('catalog.read'));
create policy product_variants_staff_read on public.product_variants for select to authenticated
  using (public.has_permission('catalog.read'));
create policy inventory_staff_read on public.inventory for select to authenticated
  using (public.has_permission('inventory.read'));
create policy movements_staff_read on public.inventory_movements for select to authenticated
  using (public.has_permission('inventory.read'));
grant select on public.inventory, public.inventory_movements to authenticated;
-- ATENCIÓN: no se concede SELECT directo sobre products.cost_price.

-- Lectura privada mediante función RPC con verificación RBAC real.
create or replace function public.catalog_management_data()
returns jsonb language plpgsql stable security definer set search_path = '' as $$
declare output jsonb;
begin
  if not public.has_permission('catalog.read') then
    raise exception 'Sin permiso para consultar el catálogo' using errcode='42501';
  end if;
  select jsonb_build_object(
    'categories', coalesce((select jsonb_agg(to_jsonb(c) order by c.name) from public.categories c),'[]'::jsonb),
    'products', coalesce((select jsonb_agg(to_jsonb(p) - 'cost_price' || jsonb_build_object('cost_price', case when public.has_permission('catalog.manage') then p.cost_price else null end) order by p.created_at desc) from public.products p),'[]'::jsonb),
    'sizes', coalesce((select jsonb_agg(to_jsonb(s) order by s.sort_order, s.label) from public.sizes s),'[]'::jsonb),
    'colors', coalesce((select jsonb_agg(to_jsonb(c) order by c.name) from public.colors c),'[]'::jsonb),
    'variants', coalesce((select jsonb_agg(to_jsonb(v) order by v.created_at desc) from public.product_variants v),'[]'::jsonb),
    'inventory', coalesce((select jsonb_agg(to_jsonb(i)) from public.inventory i),'[]'::jsonb),
    'images', coalesce((select jsonb_agg(to_jsonb(im) order by im.sort_order, im.created_at) from public.product_images im),'[]'::jsonb),
    'movements', case when public.has_permission('inventory.read') then
      coalesce((select jsonb_agg(to_jsonb(m) order by m.created_at desc) from (select * from public.inventory_movements order by created_at desc limit 200) m),'[]'::jsonb)
      else '[]'::jsonb end
  ) into output;
  return output;
end;
$$;

create or replace function public.catalog_save_category(
  p_id uuid, p_name text, p_slug text, p_description text,
  p_is_active boolean, p_parent_id uuid, p_image_path text
) returns uuid language plpgsql security definer set search_path = '' as $$
declare out_id uuid;
begin
  if not public.has_permission('catalog.manage') then raise exception 'Sin permiso' using errcode='42501'; end if;
  if length(btrim(coalesce(p_name,''))) not between 2 and 120 or
     coalesce(p_slug,'') !~ '^[a-z0-9]+(-[a-z0-9]+)*$' or length(p_slug)>140 then
    raise exception 'Nombre o identificador de categoría inválido';
  end if;
  if p_id is not null and p_id = p_parent_id then raise exception 'Una categoría no puede ser su propia madre'; end if;
  if p_parent_id is not null and not exists(select 1 from public.categories where id=p_parent_id) then
    raise exception 'Categoría principal inválida';
  end if;
  -- Evitar ciclos en las relaciones de categorías.
  if p_id is not null and p_parent_id is not null and exists (
    with recursive ancestors as (
      select id,parent_id from public.categories where id=p_parent_id
      union all
      select c.id,c.parent_id from public.categories c join ancestors a on c.id=a.parent_id
    ) select 1 from ancestors where id=p_id
  ) then raise exception 'No se puede formar un ciclo de categorías'; end if;
  if p_id is null then
    insert into public.categories(name,slug,description,is_active,parent_id,image_path)
    values(btrim(p_name),p_slug,nullif(btrim(coalesce(p_description,'')),''),coalesce(p_is_active,true),p_parent_id,nullif(btrim(coalesce(p_image_path,'')),''))
    returning id into out_id;
  else
    update public.categories set name=btrim(p_name),slug=p_slug,
      description=nullif(btrim(coalesce(p_description,'')),''),is_active=coalesce(p_is_active,true),
      parent_id=p_parent_id,image_path=nullif(btrim(coalesce(p_image_path,'')), '')
    where id=p_id returning id into out_id;
    if out_id is null then raise exception 'Categoría no encontrada'; end if;
  end if;
  insert into public.audit_logs(actor_id,action,entity_type,entity_id)
    values(auth.uid(),case when p_id is null then 'categoria.crear' else 'categoria.editar' end,'category',out_id);
  return out_id;
end;
$$;

create or replace function public.catalog_delete_category(p_id uuid)
returns void language plpgsql security definer set search_path = '' as $$
begin
  if not public.has_permission('catalog.manage') then raise exception 'Sin permiso' using errcode='42501'; end if;
  if exists(select 1 from public.products where category_id=p_id) or
     exists(select 1 from public.categories where parent_id=p_id) then
    raise exception 'La categoría tiene productos o subcategorías; desactívala en su lugar';
  end if;
  delete from public.categories where id=p_id;
  if not found then raise exception 'Categoría no encontrada'; end if;
  insert into public.audit_logs(actor_id,action,entity_type,entity_id) values(auth.uid(),'categoria.eliminar','category',p_id);
end;
$$;

create or replace function public.catalog_save_product(
  p_id uuid, p_category_id uuid, p_name text, p_slug text, p_description text,
  p_sku text, p_sale_price numeric, p_previous_price numeric, p_cost_price numeric,
  p_is_active boolean, p_is_featured boolean, p_is_new boolean
) returns uuid language plpgsql security definer set search_path = '' as $$
declare out_id uuid;
begin
  if not public.has_permission('catalog.manage') then raise exception 'Sin permiso' using errcode='42501'; end if;
  if length(btrim(coalesce(p_name,''))) not between 2 and 180 or
    coalesce(p_slug,'') !~ '^[a-z0-9]+(-[a-z0-9]+)*$' or length(p_slug)>200 then
    raise exception 'Nombre o identificador del producto inválido'; end if;
  if p_sale_price is null or p_sale_price < 0 or p_sale_price > 9999999999.99 or
     p_previous_price < 0 or p_cost_price < 0 or
     (p_previous_price is not null and p_previous_price <= p_sale_price) then
    raise exception 'Precios inválidos: el anterior debe superar el precio de venta'; end if;
  if p_category_id is not null and not exists(select 1 from public.categories where id=p_category_id) then
    raise exception 'La categoría seleccionada no existe'; end if;
  if p_id is null then
    insert into public.products(category_id,name,slug,description,sku,sale_price,previous_price,cost_price,is_active,is_featured,is_new)
    values(p_category_id,btrim(p_name),p_slug,nullif(btrim(coalesce(p_description,'')),''),nullif(btrim(coalesce(p_sku,'')),''),p_sale_price,p_previous_price,p_cost_price,coalesce(p_is_active,false),coalesce(p_is_featured,false),coalesce(p_is_new,false))
    returning id into out_id;
  else
    update public.products set category_id=p_category_id,name=btrim(p_name),slug=p_slug,
      description=nullif(btrim(coalesce(p_description,'')),''),sku=nullif(btrim(coalesce(p_sku,'')),''),
      sale_price=p_sale_price,previous_price=p_previous_price,cost_price=p_cost_price,
      is_active=coalesce(p_is_active,false),is_featured=coalesce(p_is_featured,false),
      is_new=coalesce(p_is_new,false)
    where id=p_id and deleted_at is null returning id into out_id;
    if out_id is null then raise exception 'Producto archivado o inexistente'; end if;
  end if;
  insert into public.audit_logs(actor_id,action,entity_type,entity_id)
    values(auth.uid(),case when p_id is null then 'producto.crear' else 'producto.editar' end,'product',out_id);
  return out_id;
end;
$$;

create or replace function public.catalog_archive_product(p_id uuid)
returns void language plpgsql security definer set search_path = '' as $$
begin
  if not public.has_permission('catalog.manage') then raise exception 'Sin permiso' using errcode='42501'; end if;
  update public.products set is_active=false,deleted_at=now() where id=p_id and deleted_at is null;
  if not found then raise exception 'Producto no encontrado o ya archivado'; end if;
  insert into public.audit_logs(actor_id,action,entity_type,entity_id) values(auth.uid(),'producto.archivar','product',p_id);
end;
$$;

create or replace function public.catalog_save_size(p_id uuid, p_label text, p_sort_order integer)
returns uuid language plpgsql security definer set search_path = '' as $$
declare out_id uuid;
begin
  if not public.has_permission('catalog.manage') then raise exception 'Sin permiso' using errcode='42501'; end if;
  if length(btrim(coalesce(p_label,''))) not between 1 and 40 then raise exception 'Talla inválida'; end if;
  if p_id is null then
    insert into public.sizes(label,sort_order) values(btrim(p_label),coalesce(p_sort_order,0)) returning id into out_id;
  else
    update public.sizes set label=btrim(p_label),sort_order=coalesce(p_sort_order,0) where id=p_id returning id into out_id;
    if out_id is null then raise exception 'Talla no encontrada'; end if;
  end if;
  insert into public.audit_logs(actor_id,action,entity_type,entity_id) values(auth.uid(),'talla.guardar','size',out_id);
  return out_id;
end;
$$;

create or replace function public.catalog_save_color(p_id uuid, p_name text, p_hex_code text)
returns uuid language plpgsql security definer set search_path = '' as $$
declare out_id uuid;
begin
  if not public.has_permission('catalog.manage') then raise exception 'Sin permiso' using errcode='42501'; end if;
  if length(btrim(coalesce(p_name,''))) not between 2 and 70 or
    (p_hex_code is not null and p_hex_code !~ '^#[0-9A-Fa-f]{6}$') then raise exception 'Color o código hexadecimal inválido'; end if;
  if p_id is null then
    insert into public.colors(name,hex_code) values(btrim(p_name),p_hex_code) returning id into out_id;
  else
    update public.colors set name=btrim(p_name),hex_code=p_hex_code where id=p_id returning id into out_id;
    if out_id is null then raise exception 'Color no encontrado'; end if;
  end if;
  insert into public.audit_logs(actor_id,action,entity_type,entity_id) values(auth.uid(),'color.guardar','color',out_id);
  return out_id;
end;
$$;

create or replace function public.catalog_save_variant(
  p_id uuid, p_product_id uuid, p_size_id uuid, p_color_id uuid,
  p_sku text, p_barcode text, p_price_override numeric,
  p_is_active boolean, p_low_stock_threshold integer
) returns uuid language plpgsql security definer set search_path = '' as $$
declare out_id uuid;
begin
  if not public.has_permission('catalog.manage') then raise exception 'Sin permiso' using errcode='42501'; end if;
  if length(btrim(coalesce(p_sku,''))) not between 1 and 80 or
    p_low_stock_threshold is null or p_low_stock_threshold < 0 or
    p_price_override < 0 then raise exception 'SKU, precio o umbral inválidos'; end if;
  if not exists(select 1 from public.products where id=p_product_id and deleted_at is null) then
    raise exception 'Producto no válido'; end if;
  if not exists(select 1 from public.sizes where id=p_size_id) or
     not exists(select 1 from public.colors where id=p_color_id) then raise exception 'Talla o color no válido'; end if;
  if p_id is null then
    insert into public.product_variants(product_id,size_id,color_id,sku,barcode,price_override,is_active)
    values(p_product_id,p_size_id,p_color_id,btrim(p_sku),nullif(btrim(coalesce(p_barcode,'')),''),p_price_override,coalesce(p_is_active,true))
    returning id into out_id;
    insert into public.inventory(variant_id,quantity,low_stock_threshold) values(out_id,0,p_low_stock_threshold);
  else
    -- No trasladar una variante de producto: preserva el historial de ventas.
    update public.product_variants set size_id=p_size_id,color_id=p_color_id,
      sku=btrim(p_sku),barcode=nullif(btrim(coalesce(p_barcode,'')),''),
      price_override=p_price_override,is_active=coalesce(p_is_active,true)
    where id=p_id and product_id=p_product_id returning id into out_id;
    if out_id is null then raise exception 'Variante no encontrada'; end if;
    insert into public.inventory(variant_id,quantity,low_stock_threshold)
      values(out_id,0,p_low_stock_threshold)
      on conflict (variant_id) do update set low_stock_threshold=excluded.low_stock_threshold;
  end if;
  insert into public.audit_logs(actor_id,action,entity_type,entity_id) values(auth.uid(),'variante.guardar','variant',out_id);
  return out_id;
end;
$$;

-- Ajuste de stock ATÓMICO, protegido frente a concurrencia, con clave idempotente.
-- Solo ajustes MANUALES en fase 2: ventas/devoluciones tendrán RPC específicas más adelante.
create or replace function public.catalog_adjust_stock(
  p_variant_id uuid, p_delta integer, p_reason text, p_request_id uuid
) returns jsonb language plpgsql security definer set search_path = '' as $$
declare v_balance integer; v_movement uuid; v_old public.inventory_movements%rowtype;
begin
  if not public.has_permission('inventory.adjust') then raise exception 'Sin permiso para ajustar inventario' using errcode='42501'; end if;
  if p_delta is null or p_delta = 0 or abs(p_delta::bigint)>1000000 or
    length(btrim(coalesce(p_reason,''))) < 5 or p_request_id is null then
    raise exception 'Cantidad, motivo (mínimo 5 caracteres) o solicitud inválidos'; end if;
  -- Bloquear la misma solicitud y luego comprobar si ya fue aplicada.
  perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(p_request_id::text,0));
  select * into v_old from public.inventory_movements m
    where m.source_type='ajuste_manual' and m.source_id=p_request_id limit 1;
  if found then
    if v_old.variant_id<>p_variant_id or v_old.quantity_delta<>p_delta then
      raise exception 'La clave de solicitud ya se utilizó con otros datos'; end if;
    return jsonb_build_object('movement_id',v_old.id,'balance_after',v_old.balance_after,'repeated',true);
  end if;
  select quantity into v_balance from public.inventory where variant_id=p_variant_id for update;
  if not found then raise exception 'La variante no tiene registro de inventario'; end if;
  if v_balance::bigint + p_delta::bigint < 0 then raise exception 'Inventario insuficiente: hay % unidades',v_balance; end if;
  update public.inventory set quantity=quantity + p_delta where variant_id=p_variant_id returning quantity into v_balance;
  insert into public.inventory_movements(variant_id,movement_type,quantity_delta,balance_after,reason,source_type,source_id,actor_id)
  values(p_variant_id,'ajuste',p_delta,v_balance,btrim(p_reason),'ajuste_manual',p_request_id,auth.uid()) returning id into v_movement;
  insert into public.audit_logs(actor_id,action,entity_type,entity_id,details)
  values(auth.uid(),'inventario.ajustar','variant',p_variant_id,
    jsonb_build_object('delta',p_delta,'balance_after',v_balance,'movement_id',v_movement,'reason',btrim(p_reason)));
  return jsonb_build_object('movement_id',v_movement,'balance_after',v_balance,'repeated',false);
end;
$$;

-- Metadatos de imágenes; se valida que el archivo existe en Storage.
create or replace function public.catalog_add_product_image(
  p_product_id uuid, p_storage_path text, p_alt_text text, p_sort_order integer
) returns uuid language plpgsql security definer set search_path = '' as $$
declare out_id uuid;
begin
  if not public.has_permission('catalog.manage') then raise exception 'Sin permiso' using errcode='42501'; end if;
  if not exists(select 1 from public.products where id=p_product_id and deleted_at is null) then raise exception 'Producto no encontrado'; end if;
  if p_storage_path is null or left(p_storage_path,length(p_product_id::text)+1) <> p_product_id::text || '/' or
     not exists(select 1 from storage.objects where bucket_id='product-images' and name=p_storage_path) then
    raise exception 'Archivo no encontrado en Storage o ruta inválida'; end if;
  insert into public.product_images(product_id,storage_path,alt_text,sort_order)
    values(p_product_id,p_storage_path,left(nullif(btrim(coalesce(p_alt_text,'')),''),200),coalesce(p_sort_order,0)) returning id into out_id;
  insert into public.audit_logs(actor_id,action,entity_type,entity_id) values(auth.uid(),'producto.imagen_crear','product',p_product_id);
  return out_id;
end;
$$;

create or replace function public.catalog_remove_product_image(p_id uuid)
returns void language plpgsql security definer set search_path = '' as $$
declare v_product_id uuid;
begin
  if not public.has_permission('catalog.manage') then raise exception 'Sin permiso' using errcode='42501'; end if;
  delete from public.product_images where id=p_id returning product_id into v_product_id;
  if not found then raise exception 'Imagen no encontrada'; end if;
  insert into public.audit_logs(actor_id,action,entity_type,entity_id) values(auth.uid(),'producto.imagen_eliminar','product',v_product_id);
end;
$$;

-- Funciones SECURITY DEFINER: cerradas a público y anon; permisos se revisan en su interior.
revoke execute on function public.catalog_management_data() from public,anon;
revoke execute on function public.catalog_save_category(uuid,text,text,text,boolean,uuid,text) from public,anon;
revoke execute on function public.catalog_delete_category(uuid) from public,anon;
revoke execute on function public.catalog_save_product(uuid,uuid,text,text,text,text,numeric,numeric,numeric,boolean,boolean,boolean) from public,anon;
revoke execute on function public.catalog_archive_product(uuid) from public,anon;
revoke execute on function public.catalog_save_size(uuid,text,integer) from public,anon;
revoke execute on function public.catalog_save_color(uuid,text,text) from public,anon;
revoke execute on function public.catalog_save_variant(uuid,uuid,uuid,uuid,text,text,numeric,boolean,integer) from public,anon;
revoke execute on function public.catalog_adjust_stock(uuid,integer,text,uuid) from public,anon;
revoke execute on function public.catalog_add_product_image(uuid,text,text,integer) from public,anon;
revoke execute on function public.catalog_remove_product_image(uuid) from public,anon;
grant execute on function public.catalog_management_data() to authenticated;
grant execute on function public.catalog_save_category(uuid,text,text,text,boolean,uuid,text) to authenticated;
grant execute on function public.catalog_delete_category(uuid) to authenticated;
grant execute on function public.catalog_save_product(uuid,uuid,text,text,text,text,numeric,numeric,numeric,boolean,boolean,boolean) to authenticated;
grant execute on function public.catalog_archive_product(uuid) to authenticated;
grant execute on function public.catalog_save_size(uuid,text,integer) to authenticated;
grant execute on function public.catalog_save_color(uuid,text,text) to authenticated;
grant execute on function public.catalog_save_variant(uuid,uuid,uuid,uuid,text,text,numeric,boolean,integer) to authenticated;
grant execute on function public.catalog_adjust_stock(uuid,integer,text,uuid) to authenticated;
grant execute on function public.catalog_add_product_image(uuid,text,text,integer) to authenticated;
grant execute on function public.catalog_remove_product_image(uuid) to authenticated;

-- El bucket se creó en la Fase 1. Solo personal autorizado puede subir/quitar imágenes.
create policy mi_product_images_upload on storage.objects for insert to authenticated
  with check (
    bucket_id = 'product-images' and public.has_permission('catalog.manage') and
    exists (select 1 from public.products p where p.id::text = (storage.foldername(name))[1] and p.deleted_at is null)
  );
create policy mi_product_images_staff_select on storage.objects for select to authenticated
  using (bucket_id = 'product-images' and public.has_permission('catalog.manage'));
create policy mi_product_images_staff_delete on storage.objects for delete to authenticated
  using (bucket_id = 'product-images' and public.has_permission('catalog.manage'));

-- Comprobación rápida al finalizar:
-- select to_regprocedure('public.catalog_adjust_stock(uuid,integer,text,uuid)') is not null as fase_2_instalada;

-- Imágenes para categorías, aisladas del bucket de productos.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values ('category-images','category-images',true,5242880,array['image/jpeg','image/png','image/webp'])
on conflict(id) do nothing;
create policy mi_category_images_upload on storage.objects for insert to authenticated
  with check (
    bucket_id='category-images' and public.has_permission('catalog.manage')
    and (storage.foldername(name))[1]='categories'
    and exists(select 1 from public.categories c where c.id::text=(storage.foldername(name))[2])
  );
create policy mi_category_images_staff_select on storage.objects for select to authenticated
  using(bucket_id='category-images' and public.has_permission('catalog.manage'));
create policy mi_category_images_staff_delete on storage.objects for delete to authenticated
  using(bucket_id='category-images' and public.has_permission('catalog.manage'));
