-- MODA INFANTIL / FASE 3 — Tienda pública con productos reales.
-- Ejecutar UNA sola vez después de la migración 00600 (Fase 2).
-- No elimina datos previos. No habilita ventas, pagos ni reserva de stock.

-- La tienda pública solo expone campos comerciales. NO incluye cost_price,
-- usuarios, movimientos, datos personales ni operaciones administrativas.
create or replace function public.storefront_data()
returns jsonb
language sql stable security definer set search_path = ''
as $$
  select jsonb_build_object(
    'categories', coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',c.id,'name',c.name,'slug',c.slug,'description',c.description,
        'image_path',c.image_path,'parent_id',c.parent_id
      ) order by c.name)
      from public.categories c where c.is_active
    ),'[]'::jsonb),
    'products', coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',p.id,'category_id',p.category_id,'name',p.name,'slug',p.slug,
        'description',p.description,'sku',p.sku,'sale_price',p.sale_price,
        'previous_price',p.previous_price,'is_featured',p.is_featured,
        'is_new',p.is_new,'created_at',p.created_at
      ) order by p.created_at desc)
      from public.products p left join public.categories c on c.id=p.category_id
      where p.is_active and p.deleted_at is null
        and (p.category_id is null or c.is_active)
    ),'[]'::jsonb),
    'sizes',coalesce((
      select jsonb_agg(jsonb_build_object('id',s.id,'label',s.label,'sort_order',s.sort_order)
        order by s.sort_order,s.label) from public.sizes s
    ),'[]'::jsonb),
    'colors',coalesce((
      select jsonb_agg(jsonb_build_object('id',c.id,'name',c.name,'hex_code',c.hex_code)
        order by c.name) from public.colors c
    ),'[]'::jsonb),
    'variants',coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',v.id,'product_id',v.product_id,'size_id',v.size_id,
        'color_id',v.color_id,'sku',v.sku,'price_override',v.price_override,
        'quantity',coalesce(i.quantity,0)
      ) order by v.created_at)
      from public.product_variants v
      join public.products p on p.id=v.product_id
      left join public.categories c on c.id=p.category_id
      left join public.inventory i on i.variant_id=v.id
      where v.is_active and p.is_active and p.deleted_at is null
        and (p.category_id is null or c.is_active)
    ),'[]'::jsonb),
    'images',coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',im.id,'product_id',im.product_id,'storage_path',im.storage_path,
        'alt_text',im.alt_text,'sort_order',im.sort_order
      ) order by im.sort_order,im.created_at)
      from public.product_images im
      join public.products p on p.id=im.product_id
      left join public.categories c on c.id=p.category_id
      where p.is_active and p.deleted_at is null
        and (p.category_id is null or c.is_active)
    ),'[]'::jsonb),
    'banners',coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',b.id,'title',b.title,'description',b.description,
        'image_path',b.image_path,'button_text',b.button_text,
        'target_url',b.target_url,'sort_order',b.sort_order
      ) order by b.sort_order,b.created_at)
      from public.banners b
      where b.is_active and (b.starts_at is null or b.starts_at<=now())
        and (b.ends_at is null or b.ends_at>now())
    ),'[]'::jsonb),
    'settings',(
      select jsonb_build_object(
        'store_name',s.store_name,'logo_path',s.logo_path,
        'whatsapp',s.whatsapp,'phone',s.phone,'address',s.address,
        'city',s.city,'department',s.department,'opening_hours',s.opening_hours,
        'about_us',s.about_us,'instagram_url',s.instagram_url,
        'facebook_url',s.facebook_url,'shipping_information',s.shipping_information,
        'return_policy',s.return_policy
      ) from public.store_settings s where s.id=1
    )
  );
$$;
revoke all on function public.storefront_data() from public;
grant execute on function public.storefront_data() to anon, authenticated;

-- Gestión de banners SOLO para usuarios con banners.manage.
-- Reutilizamos el bucket promo-banners creado en Fase 1.
create or replace function public.storefront_manage_banners()
returns jsonb language plpgsql stable security definer set search_path = '' as $$
begin
  if not public.has_permission('banners.manage') then
    raise exception 'Sin permiso para administrar banners' using errcode='42501';
  end if;
  return coalesce((
    select jsonb_agg(jsonb_build_object(
      'id',b.id,'title',b.title,'description',b.description,
      'image_path',b.image_path,'button_text',b.button_text,
      'target_url',b.target_url,'sort_order',b.sort_order,
      'is_active',b.is_active,'starts_at',b.starts_at,'ends_at',b.ends_at
    ) order by b.sort_order,b.created_at)
    from public.banners b
  ),'[]'::jsonb);
end;
$$;

create or replace function public.storefront_save_banner(
  p_id uuid,p_title text,p_description text,p_image_path text,
  p_button_text text,p_target_url text,p_sort_order integer,p_is_active boolean,
  p_starts_at timestamptz,p_ends_at timestamptz
)
returns uuid language plpgsql security definer set search_path = '' as $$
declare out_id uuid;
begin
  if not public.has_permission('banners.manage') then
    raise exception 'Sin permiso para administrar banners' using errcode='42501';
  end if;
  if length(btrim(coalesce(p_title,''))) not between 2 and 160 then
    raise exception 'Escribe un título válido (2–160 caracteres)';
  end if;
  if p_image_path is null or left(p_image_path,8)<>'banners/' or
      not exists (select 1 from storage.objects o where o.bucket_id='promo-banners' and o.name=p_image_path) then
    raise exception 'Sube primero una imagen válida al bucket de banners';
  end if;
  if nullif(btrim(coalesce(p_target_url,'')),'') is not null and not (
    (p_target_url ~ '^/[^/]' and p_target_url !~ '[[:space:]]') or
    p_target_url ~ '^https?://[^[:space:]]+$'
  ) then raise exception 'Enlace no permitido: usa una ruta interna o https://'; end if;
  if p_ends_at is not null and p_starts_at is not null and p_ends_at<=p_starts_at then
    raise exception 'La fecha final debe ser posterior a la inicial';
  end if;
  if p_id is null then
    insert into public.banners(title,description,image_path,button_text,target_url,
      sort_order,is_active,starts_at,ends_at)
    values(btrim(p_title),nullif(btrim(coalesce(p_description,'')),''),p_image_path,
      nullif(btrim(coalesce(p_button_text,'')),''),nullif(btrim(coalesce(p_target_url,'')),''),
      coalesce(p_sort_order,0),coalesce(p_is_active,false),p_starts_at,p_ends_at)
    returning id into out_id;
  else
    update public.banners set title=btrim(p_title),
      description=nullif(btrim(coalesce(p_description,'')),''),image_path=p_image_path,
      button_text=nullif(btrim(coalesce(p_button_text,'')),''),
      target_url=nullif(btrim(coalesce(p_target_url,'')),''),
      sort_order=coalesce(p_sort_order,0),is_active=coalesce(p_is_active,false),
      starts_at=p_starts_at,ends_at=p_ends_at
    where id=p_id returning id into out_id;
    if out_id is null then raise exception 'Banner no encontrado'; end if;
  end if;
  insert into public.audit_logs(actor_id,action,entity_type,entity_id)
    values(auth.uid(), 'banner.guardar', 'banner',out_id);
  return out_id;
end;
$$;

create or replace function public.storefront_delete_banner(p_id uuid)
returns void language plpgsql security definer set search_path = '' as $$
begin
  if not public.has_permission('banners.manage') then
    raise exception 'Sin permiso para administrar banners' using errcode='42501';
  end if;
  delete from public.banners where id=p_id;
  if not found then raise exception 'Banner no encontrado'; end if;
  insert into public.audit_logs(actor_id,action,entity_type,entity_id)
    values(auth.uid(), 'banner.eliminar','banner',p_id);
end;
$$;

revoke all on function public.storefront_manage_banners() from public,anon;
revoke all on function public.storefront_save_banner(uuid,text,text,text,text,text,integer,boolean,timestamptz,timestamptz) from public,anon;
revoke all on function public.storefront_delete_banner(uuid) from public,anon;
grant execute on function public.storefront_manage_banners() to authenticated;
grant execute on function public.storefront_save_banner(uuid,text,text,text,text,text,integer,boolean,timestamptz,timestamptz) to authenticated;
grant execute on function public.storefront_delete_banner(uuid) to authenticated;

-- Solo personal con permiso banners.manage puede subir/borrar archivos.
-- La lectura de imágenes públicas se permite por la configuración del bucket.
create policy mi_promo_banner_upload on storage.objects
  for insert to authenticated
  with check (bucket_id='promo-banners' and public.has_permission('banners.manage')
    and (storage.foldername(name))[1]='banners');
create policy mi_promo_banner_select on storage.objects
  for select to authenticated
  using (bucket_id='promo-banners' and public.has_permission('banners.manage'));
create policy mi_promo_banner_delete on storage.objects
  for delete to authenticated
  using (bucket_id='promo-banners' and public.has_permission('banners.manage'));

-- Comprobación: select to_regprocedure('public.storefront_data()') is not null as fase3_lista;
