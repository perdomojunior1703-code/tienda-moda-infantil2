-- MODA INFANTIL / FASE 1 / Gestión segura de roles de empleados.
-- Ejecutar DESPUÉS de la migración 00300 porque usa audit_logs.
-- Ningún cliente puede insertar user_roles directamente ni elevar sus privilegios.

create or replace function public.admin_list_staff()
returns jsonb
language plpgsql stable security definer
set search_path = ''
as $$
declare result jsonb;
begin
  if not public.has_permission('roles.manage') then
    raise exception 'No tienes permiso para gestionar personal' using errcode = '42501';
  end if;
  select coalesce(jsonb_agg(jsonb_build_object(
    'user_id', s.user_id,
    'email', s.email,
    'full_name', s.full_name,
    'roles', s.roles
  ) order by s.full_name), '[]'::jsonb) into result
  from (
    select au.id as user_id, au.email, coalesce(p.full_name, '') as full_name,
      jsonb_agg(ur.role_code order by ur.role_code) as roles
    from auth.users au
    join public.user_roles ur on ur.user_id = au.id and ur.role_code <> 'cliente'
    left join public.profiles p on p.id = au.id
    group by au.id, au.email, p.full_name
  ) s;
  return result;
end;
$$;

create or replace function public.admin_assign_role(
  target_email text,
  requested_role text,
  grant_role boolean
)
returns jsonb
language plpgsql volatile security definer
set search_path = ''
as $$
declare
  target_id uuid;
  actor_id uuid;
begin
  actor_id := (select auth.uid());
  if actor_id is null or not public.has_permission('roles.manage') then
    raise exception 'No tienes permiso para gestionar personal' using errcode = '42501';
  end if;
  if requested_role not in ('administrador','supervisor','cajero','inventario') then
    raise exception 'Rol de empleado no permitido' using errcode = '22023';
  end if;
  select id into target_id from auth.users
  where lower(email) = lower(trim(target_email))
  limit 1;
  if target_id is null then
    raise exception 'No se encontró el usuario; debe registrarse primero' using errcode = '22023';
  end if;
  if target_id = actor_id then
    raise exception 'No puedes cambiar tus propios permisos' using errcode = '42501';
  end if;

  if grant_role then
    insert into public.user_roles(user_id, role_code, assigned_by)
    values(target_id, requested_role, actor_id)
    on conflict (user_id, role_code) do nothing;
  else
    delete from public.user_roles
    where user_id = target_id and role_code = requested_role;
  end if;

  insert into public.audit_logs (actor_id, action, entity_type, entity_id, details)
  values (actor_id,
          case when grant_role then 'staff.role_granted' else 'staff.role_revoked' end,
          'user', target_id,
          jsonb_build_object('role', requested_role, 'email', lower(trim(target_email))));
  return jsonb_build_object('success', true, 'email', lower(trim(target_email)),
      'role', requested_role, 'granted', grant_role);
end;
$$;

revoke execute on function public.admin_list_staff() from public, anon;
revoke execute on function public.admin_assign_role(text,text,boolean) from public, anon;
grant execute on function public.admin_list_staff() to authenticated;
grant execute on function public.admin_assign_role(text,text,boolean) to authenticated;
