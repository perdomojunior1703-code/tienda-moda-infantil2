-- MODA INFANTIL / FASE 1 / Esquema del catálogo para la fase 2.
-- Las modificaciones CRUD y los movimientos transaccionales se implementarán
-- en fase 2; hoy se deja preparada la estructura con RLS de denegación.

create table public.categories (
  id uuid primary key default gen_random_uuid(),
  parent_id uuid references public.categories(id) on delete set null,
  name varchar(120) not null,
  slug varchar(140) not null unique,
  description text,
  image_path text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  category_id uuid references public.categories(id) on delete set null,
  name varchar(180) not null,
  slug varchar(200) not null unique,
  description text,
  sku varchar(80) unique,
  sale_price numeric(12,2) not null check (sale_price >= 0),
  previous_price numeric(12,2) check (previous_price >= 0),
  cost_price numeric(12,2) check (cost_price >= 0),
  is_active boolean not null default false,
  is_featured boolean not null default false,
  is_new boolean not null default false,
  deleted_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index products_category_idx on public.products(category_id);

create table public.product_images (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  storage_path text not null,
  alt_text varchar(200),
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);
create index product_images_product_idx on public.product_images(product_id, sort_order);

create table public.sizes (
  id uuid primary key default gen_random_uuid(),
  label varchar(40) not null unique,
  sort_order int not null default 0
);

create table public.colors (
  id uuid primary key default gen_random_uuid(),
  name varchar(70) not null unique,
  hex_code varchar(7) check (hex_code is null or hex_code ~ '^#[0-9A-Fa-f]{6}$')
);

create table public.product_variants (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete restrict,
  size_id uuid not null references public.sizes(id) on delete restrict,
  color_id uuid not null references public.colors(id) on delete restrict,
  sku varchar(80) not null unique,
  barcode varchar(100) unique,
  price_override numeric(12,2) check (price_override >= 0),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  unique (product_id, size_id, color_id)
);
create index variants_product_idx on public.product_variants(product_id);

create table public.inventory (
  variant_id uuid primary key references public.product_variants(id) on delete restrict,
  quantity integer not null default 0 check (quantity >= 0),
  low_stock_threshold integer not null default 3 check (low_stock_threshold >= 0),
  updated_at timestamptz not null default now()
);

create table public.inventory_movements (
  id uuid primary key default gen_random_uuid(),
  variant_id uuid not null references public.product_variants(id) on delete restrict,
  movement_type varchar(20) not null check (movement_type in ('entrada','salida','devolucion','ajuste','reserva','liberacion')),
  quantity_delta integer not null check (quantity_delta <> 0),
  balance_after integer check (balance_after >= 0),
  reason text,
  source_type text,
  source_id uuid,
  actor_id uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);
create index movements_variant_time_idx on public.inventory_movements(variant_id, created_at desc);
create unique index movements_source_idempotency_idx
  on public.inventory_movements (source_type, source_id, variant_id, movement_type)
  where source_type is not null and source_id is not null;

-- Inventario histórico inmutable (una corrección crea un nuevo movimiento).
create or replace function public.prevent_inventory_movement_mutation()
returns trigger language plpgsql set search_path = '' as $$
begin
  raise exception 'Los movimientos del inventario son inmutables';
end;
$$;
create trigger inventory_movements_immutable
before update or delete on public.inventory_movements
for each row execute function public.prevent_inventory_movement_mutation();
revoke execute on function public.prevent_inventory_movement_mutation() from public, anon, authenticated;

create trigger categories_touch_updated_at before update on public.categories
for each row execute function public.touch_updated_at();
create trigger products_touch_updated_at before update on public.products
for each row execute function public.touch_updated_at();
create trigger inventory_touch_updated_at before update on public.inventory
for each row execute function public.touch_updated_at();

insert into public.categories (name, slug, description) values
  ('Ropa para niña', 'ropa-para-nina', 'Prendas infantiles para niñas'),
  ('Ropa para niño', 'ropa-para-nino', 'Prendas infantiles para niños'),
  ('Ropa para bebé', 'ropa-para-bebe', 'Ropa para los más pequeños'),
  ('Conjuntos infantiles', 'conjuntos-infantiles', 'Conjuntos para diferentes ocasiones'),
  ('Vestidos', 'vestidos', 'Vestidos infantiles');

alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.product_images enable row level security;
alter table public.sizes enable row level security;
alter table public.colors enable row level security;
alter table public.product_variants enable row level security;
alter table public.inventory enable row level security;
alter table public.inventory_movements enable row level security;

-- La tienda pública solo puede leer categorías y productos visibles.
create policy categories_public_read on public.categories
  for select to anon, authenticated using (is_active);
create policy products_public_read on public.products
  for select to anon, authenticated using (is_active and deleted_at is null);
create policy product_images_public_read on public.product_images
  for select to anon, authenticated using (
    exists (select 1 from public.products p where p.id = product_id and p.is_active and p.deleted_at is null)
  );
create policy sizes_public_read on public.sizes for select to anon, authenticated using (true);
create policy colors_public_read on public.colors for select to anon, authenticated using (true);
create policy product_variants_public_read on public.product_variants
  for select to anon, authenticated using (
    is_active and exists (select 1 from public.products p where p.id = product_id and p.is_active and p.deleted_at is null)
  );
-- No políticas de escritura de productos/stock hasta implementar servicios
-- transaccionales en fase 2: denegar por defecto es intencional.
revoke all on table public.categories, public.products, public.product_images,
  public.sizes, public.colors, public.product_variants, public.inventory,
  public.inventory_movements from anon, authenticated;
grant select on public.categories, public.product_images,
  public.sizes, public.colors, public.product_variants to anon, authenticated;
-- El costo de adquisición es privado; nunca exponer cost_price al público.
grant select (id, category_id, name, slug, description, sku, sale_price,
  previous_price, is_active, is_featured, is_new, deleted_at, created_at, updated_at)
  on public.products to anon, authenticated;
