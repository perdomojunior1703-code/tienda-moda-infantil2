-- MODA INFANTIL / FASE 1 / Buckets públicos para imágenes comerciales.
-- Usuarios comunes NO pueden subir, editar ni eliminar objetos.
-- La carga de archivos con validación MIME, tamaño y autorización se
-- implementará en la fase 2 (productos) y fase 6 (banners y branding).
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values
  ('product-images', 'product-images', true, 5242880, array['image/jpeg','image/png','image/webp']),
  ('promo-banners', 'promo-banners', true, 5242880, array['image/jpeg','image/png','image/webp']),
  ('store-assets', 'store-assets', true, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;
-- Los buckets públicos admiten lectura pública por URL. No se concede
-- ninguna policy de INSERT/UPDATE/DELETE sobre storage.objects.
