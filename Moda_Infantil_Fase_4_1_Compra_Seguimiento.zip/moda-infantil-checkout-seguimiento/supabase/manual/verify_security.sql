-- CONSULTAS DE VERIFICACIÓN, Supabase > SQL Editor
-- 1) Todas las tablas públicas deben tener RLS activo.
select tablename, rowsecurity
from pg_tables
where schemaname = 'public'
order by tablename;

-- 2) Usuarios asociados a un rol (no se exponen públicamente).
select r.code, count(ur.user_id) as usuarios
from public.roles r
left join public.user_roles ur on ur.role_code = r.code
group by r.code
order by r.code;

-- 3) Ver permisos y políticas que realmente existen.
select tablename, policyname, cmd, roles, qual, with_check
from pg_policies
where schemaname = 'public'
order by tablename, policyname;

-- 4) Comprobar que NO hay acceso de escritura desde roles cliente.
select table_name, privilege_type
from information_schema.role_table_grants
where table_schema = 'public'
  and grantee in ('anon', 'authenticated')
order by table_name, privilege_type;

-- IMPORTANTE: el SQL Editor funciona con privilegios de administrador.
-- Su acceso directo NO demuestra que RLS funcione para usuarios normales.
-- Para validar permisos reales, usa dos cuentas distintas en el navegador
-- y las pruebas descritas en docs/PRUEBAS_FASE1.md.
