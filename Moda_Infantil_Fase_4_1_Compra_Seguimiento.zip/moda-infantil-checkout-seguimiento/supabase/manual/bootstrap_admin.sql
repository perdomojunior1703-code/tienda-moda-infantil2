-- Ejecutar SOLO una vez en Supabase > SQL Editor como propietario del proyecto.
-- PASO 1: regístrate primero en /registrarse, confirma tu correo si se requiere.
-- PASO 2: REEMPLAZA el correo de ejemplo por el tuyo, antes de ejecutar.
-- PASO 3: vuelve al navegador y presiona "Actualizar permisos" en /cuenta.
-- Nunca ejecutar esto desde el navegador ni compartir con clientes.

do $$
declare
  target_user uuid;
begin
  select id into target_user from auth.users
  where lower(email) = lower('CAMBIA_ESTE_CORREO@ejemplo.com')
  limit 1;

  if target_user is null then
    raise exception 'No se encontró ese usuario. Registra la cuenta primero y reemplaza el correo.';
  end if;

  insert into public.user_roles (user_id, role_code, assigned_by)
  values (target_user, 'administrador', target_user)
  on conflict (user_id, role_code) do nothing;

  raise notice 'Cuenta administrativa configurada para el usuario %', target_user;
end;
$$;
