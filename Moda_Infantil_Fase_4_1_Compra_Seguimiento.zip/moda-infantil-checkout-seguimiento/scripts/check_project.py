"""Verificación estructural offline. NO sustituye npm run build ni una base Supabase real."""
from pathlib import Path
root = Path(__file__).resolve().parents[1]
required = [
    'src/main.tsx', 'src/App.tsx', 'src/context/AuthContext.tsx',
    'src/lib/supabase.ts', 'src/pages/LoginPage.tsx',
    'src/pages/RegisterPage.tsx', 'src/pages/AccountPage.tsx',
    '.env.example', 'README.md', 'vercel.json',
]
for part in required:
    assert (root / part).is_file(), f'Falta {part}'

migration_dir = root / 'supabase' / 'migrations'
migrations = sorted(migration_dir.glob('*.sql'))
assert len(migrations) >= 7, f'Deben existir al menos siete migraciones, hay {len(migrations)}'
all_sql = '\n'.join(path.read_text(encoding='utf8').lower() for path in migrations)
for name in ['profiles', 'user_roles', 'roles', 'permissions', 'role_permissions',
             'categories', 'products', 'product_variants', 'inventory',
             'orders', 'payments', 'cash_registers', 'cash_shifts',
             'sales', 'returns', 'audit_logs', 'shipping_rates']:
    assert f'create table public.{name}' in all_sql, f'Falta tabla {name}'
for check in ['on_auth_user_created', 'get_my_access', 'has_permission',
              'admin_assign_role', 'admin_list_staff',
              'enable row level security', 'grant execute on function']:
    assert check in all_sql, f'Falta requisito {check}'
print(f'OK: {len(required)} archivos base, {len(migrations)} migraciones, tablas y funciones previstas.')
print('AVISO: no se probó conexión real, ejecución de SQL, compilación React ni permisos sobre Supabase.')
