"""Comprobaciones offline de archivos y seguridad; NO ejecuta PostgreSQL ni compila TS."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
new=[
 'src/pages/CheckoutPage.tsx','src/pages/MyOrdersPage.tsx',
 'src/pages/OrdersAdminPage.tsx','src/pages/ShippingAdminPage.tsx',
 'src/features/orders/api.ts',
 'supabase/migrations/20261120000800_phase4_orders_shipping.sql',
 'docs/PRUEBAS_FASE4.md'
]
for file in new:assert (root/file).is_file(),f'Falta: {file}'
app=(root/'src/App.tsx').read_text()
for route in ['checkout','mis-pedidos','panel/pedidos','panel/envios']:
 assert f'path="{route}"' in app,route
sql=(root/new[-2]).read_text().lower()
for expected in ['orders_create_whatsapp','orders_change_status','orders_list',
                 'shipping_public_options','shipping_save_rate',
                 'pg_advisory_xact_lock',"status='reservada' and r.expires_at>now()",
                 'payment_status','inventory_movements']:
 assert expected in sql,expected
for forbidden in ['drop table','truncate public.','service_role','grant all on public.orders']:
 assert forbidden not in sql,forbidden
assert not (root/'.env').exists(), 'No incluir credenciales reales en el ZIP'
assert len(list((root/'supabase/migrations').glob('*.sql'))) == 8
print('OK: 8 migraciones, 4 rutas nuevas, seguridad e interfaces de pedidos presentes.')
print('PENDIENTE: npm run build y pruebas de transacciones en tu Supabase de desarrollo.')
