"""Comprobaciones estructurales locales de Fase 3; no sustituyen npm run build ni un SQL Editor real."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
paths=['src/main.tsx','src/App.tsx','src/pages/HomePage.tsx','src/pages/ShopPage.tsx','src/pages/ProductDetailPage.tsx','src/pages/CartPage.tsx','src/pages/FavoritesPage.tsx','src/pages/BannersPage.tsx','src/features/storefront/api.ts','src/features/storefront/cart.tsx','src/pages/ProductEditorPage.tsx','supabase/migrations/20261120000700_phase3_public_storefront.sql']
for path in paths:
    assert (root/path).is_file(),path
assert "const isNew = !id || id === 'nuevo'" in (root/'src/pages/ProductEditorPage.tsx').read_text()
assert len(list((root/'supabase/migrations').glob('*.sql'))) >= 7
assert '.env' not in [p.name for p in root.iterdir()]
sql=(root/'supabase/migrations/20261120000700_phase3_public_storefront.sql').read_text().lower()
for name in ['storefront_data','storefront_manage_banners','storefront_save_banner','storefront_delete_banner','banners.manage']:
    assert name in sql,name
for statement in ['drop table', 'truncate public.', 'delete from public.products']:
    assert statement not in sql,statement
print('OK: archivos de Fase 3, al menos siete migraciones y corrección del editor presentes; sin .env ni borrados de tablas.')
