import { useState } from 'react'
import { Heart, LayoutDashboard, LogIn, Menu, Search, ShoppingBag, UserRound, X, Instagram, Phone, MapPin, ClipboardList } from 'lucide-react'
import { Link, NavLink, Outlet, useNavigate } from 'react-router-dom'
import { Brand } from '../components/Brand'
import { useAuth } from '../context/AuthContext'
import { useStore } from '../features/storefront/hooks'
import { useCart } from '../features/storefront/cart'
import { safeSiteLink, waLink } from '../features/storefront/api'

const nav = [{to:'/',label:'Inicio',end:true},{to:'/catalogo',label:'Colección'},{to:'/catalogo?oferta=1',label:'Ofertas'},{to:'/nosotros',label:'Nosotros'}]
export function PublicLayout() {
  const {user,access} = useAuth()
  const {count,favoriteIds} = useCart()
  const {data} = useStore()
  const settings = data?.settings
  const [menu,setMenu] = useState(false)
  const [search,setSearch] = useState('')
  const navigate = useNavigate()
  function onSearch(e:React.FormEvent) {e.preventDefault();setMenu(false);navigate(`/catalogo?buscar=${encodeURIComponent(search.trim())}`)}
  const whatsapp = waLink(settings?.whatsapp)
  return <div className="min-h-screen bg-[#fffdfb] text-ink">
    <div className="bg-[#26232a] px-4 py-2.5 text-center text-[11px] font-semibold tracking-[.07em] text-white sm:text-xs">Moda para los más pequeños, hecha para grandes momentos <span className="text-red-300">♥</span></div>
    <header className="sticky top-0 z-40 border-b border-[#f5eeed] bg-white/95 backdrop-blur-lg">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-4 sm:px-6">
        <button type="button" className="p-2 lg:hidden" onClick={()=>setMenu(x=>!x)} aria-label={menu?'Cerrar menú':'Abrir menú'} aria-expanded={menu}>{menu?<X size={22}/>:<Menu size={22}/>}</button>
        <div className="flex shrink-0 items-center gap-2"><Brand /></div>
        <nav className="hidden items-center gap-7 text-sm font-semibold lg:flex" aria-label="Navegación de la tienda">{nav.map(n=><NavLink key={n.to} end={n.end} className={({isActive}) => `transition hover:text-brand ${isActive && n.to !== '/catalogo?oferta=1' ? 'text-brand' : 'text-slate-700'}`} to={n.to}>{n.label}</NavLink>)}</nav>
        <form className="hidden max-w-xs flex-1 items-center rounded-full border border-slate-200 bg-slate-50 px-3 xl:flex" onSubmit={onSearch}><Search size={17} className="text-slate-400"/><input className="min-w-0 flex-1 bg-transparent px-3 py-2.5 text-xs outline-none" value={search} onChange={e=>setSearch(e.target.value)} placeholder="¿Qué estás buscando?" aria-label="Buscar prendas"/><button className="text-xs font-bold text-brand" aria-label="Buscar">Buscar</button></form>
        <div className="flex items-center gap-1 sm:gap-2"><Link className="store-icon-btn" to="/favoritos" aria-label={`Favoritos (${favoriteIds.length})`}><Heart size={20}/></Link><Link className="store-icon-btn relative" to="/carrito" aria-label={`Carrito (${count} artículos)`}><ShoppingBag size={20}/>{count>0 && <span className="absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-brand px-1 text-[9px] font-bold text-white">{count>99?'99+':count}</span>}</Link>
          {user && <Link className="store-icon-btn" to="/mis-pedidos" aria-label="Mis pedidos" title="Mis pedidos"><ClipboardList size={20}/></Link>}
          {user ? <Link className="store-icon-btn" to="/cuenta" aria-label="Mi cuenta"><UserRound size={20}/></Link> : <Link className="store-icon-btn" to="/ingresar" aria-label="Iniciar sesión"><LogIn size={20}/></Link>}
          {user && access.permissions.includes('panel.access') && <Link className="hidden items-center gap-1.5 rounded-full bg-brand-pale px-4 py-2.5 text-xs font-bold text-brand lg:inline-flex" to="/panel"><LayoutDashboard size={16}/> Panel</Link>}
        </div>
      </div>
      {menu && <div className="border-t border-slate-100 bg-white px-5 py-4 lg:hidden"><form className="mb-4 flex items-center gap-2 rounded-xl border border-slate-200 px-3" onSubmit={onSearch}><Search size={17}/><input className="w-full py-3 text-sm outline-none" value={search} onChange={e=>setSearch(e.target.value)} placeholder="Buscar producto"/><button className="font-bold text-brand">Ir</button></form>{nav.map(n=><Link key={n.to} to={n.to} className="block border-b border-slate-50 py-3 text-sm font-semibold" onClick={()=>setMenu(false)}>{n.label}</Link>)}{user&&access.permissions.includes('panel.access')&&<Link onClick={()=>setMenu(false)} to="/panel" className="block py-3 text-sm font-semibold text-brand">Panel administrativo</Link>}</div>}
    </header>
    <main id="contenido"><Outlet/></main>
    <footer className="mt-20 bg-[#29262b] text-white"><div className="mx-auto grid max-w-7xl gap-10 px-5 py-14 md:grid-cols-4">
      <div className="md:col-span-1"><p className="font-display text-2xl font-bold">{settings?.store_name || 'Moda Infantil'}<span className="text-red-400">.</span></p><p className="mt-4 text-sm leading-7 text-white/60">Ropita y detalles llenos de cariño para acompañar cada etapa.</p></div>
      <div><h3 className="font-display text-sm font-bold">Explorar</h3><div className="mt-4 flex flex-col gap-3 text-sm text-white/65"><Link to="/catalogo">Todos los productos</Link><Link to="/catalogo?oferta=1">Ofertas</Link><Link to="/favoritos">Mis favoritos</Link><Link to="/carrito">Mi carrito</Link><Link to="/mis-pedidos">Mis pedidos</Link></div></div>
      <div><h3 className="font-display text-sm font-bold">Información</h3><div className="mt-4 flex flex-col gap-3 text-sm text-white/65"><Link to="/nosotros">Quiénes somos</Link>{settings?.shipping_information && <Link to="/nosotros#envios">Envíos y entregas</Link>}{settings?.return_policy && <Link to="/nosotros#cambios">Cambios y devoluciones</Link>}</div></div>
      <div><h3 className="font-display text-sm font-bold">Contáctanos</h3><div className="mt-4 space-y-3 text-sm text-white/65">{settings?.city && <p className="flex items-center gap-2"><MapPin size={16}/>{settings.city}{settings.department ? `, ${settings.department}` : ''}</p>}{settings?.phone && <p className="flex items-center gap-2"><Phone size={16}/>{settings.phone}</p>}{whatsapp && <a className="block hover:text-white" href={whatsapp} target="_blank" rel="noreferrer">WhatsApp de la tienda</a>}{safeSiteLink(settings?.instagram_url) && <a href={safeSiteLink(settings?.instagram_url)!} className="flex items-center gap-2" target="_blank" rel="noreferrer"><Instagram size={16}/> Instagram</a>}</div></div>
    </div><div className="border-t border-white/10 px-5 py-5 text-center text-xs text-white/45">© {new Date().getFullYear()} Moda Infantil · Catálogo conectado a Supabase · Pedidos por WhatsApp · Pago a convenir con el comercio</div></footer>
    {whatsapp && <a href={whatsapp} target="_blank" rel="noreferrer" className="fixed bottom-6 right-6 z-30 rounded-full bg-[#1ca864] px-5 py-3 text-xs font-bold text-white shadow-lg hover:bg-[#168953]" aria-label="Contactar por WhatsApp">WhatsApp</a>}
  </div>
}
