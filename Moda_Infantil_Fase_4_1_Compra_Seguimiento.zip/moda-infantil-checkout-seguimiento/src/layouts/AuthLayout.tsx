import { Outlet } from 'react-router-dom'
import { Brand } from '../components/Brand'

export function AuthLayout() {
  return <div className="flex min-h-screen items-center justify-center bg-[#fafafa] px-4 py-10">
    <div className="w-full max-w-md">
      <div className="mb-7 text-center"><Brand /></div>
      <div className="rounded-3xl border border-slate-100 bg-white p-7 shadow-xl shadow-slate-200/40 sm:p-9"><Outlet /></div>
      <p className="mt-6 text-center text-xs text-slate-400">Tus datos de acceso se gestionan de forma segura mediante Supabase Auth.</p>
    </div>
  </div>
}
