import { useState } from 'react'
import { Link, Outlet, useLocation, useNavigate } from 'react-router-dom'
import { Image, Boxes, LayoutDashboard, LogOut, Menu, Palette, ShieldCheck, Store, Tags, UserRound, UserRoundCog, Warehouse, X, ClipboardList, Truck } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import { Brand } from '../components/Brand'
import { ROLE_NAMES } from '../lib/access'

export function AdminLayout() {
  const { profile, access, signOut } = useAuth()
  const [open, setOpen] = useState(false)
  const navigate = useNavigate()
  const location = useLocation()
  const can = (permission: string) => access.permissions.includes(permission)
  async function exit() { try { await signOut(); navigate('/', { replace: true }) } catch { /* la sesión permanece activa si falla */ } }
  const links = [
    { to: '/panel', text: 'Inicio del panel', icon: LayoutDashboard, visible: true },
    { to: '/panel/productos', text: 'Productos', icon: Boxes, visible: can('catalog.read') },
    { to: '/panel/categorias', text: 'Categorías', icon: Tags, visible: can('catalog.read') },
    { to: '/panel/opciones', text: 'Tallas y colores', icon: Palette, visible: can('catalog.read') },
    { to: '/panel/inventario', text: 'Inventario', icon: Warehouse, visible: can('inventory.read') },
    { to: '/panel/pedidos', text: 'Pedidos', icon: ClipboardList, visible: can('orders.read') },
    { to: '/panel/envios', text: 'Envíos y tarifas', icon: Truck, visible: can('shipping.manage') },
    { to: '/panel/banners', text: 'Banners de tienda', icon: Image, visible: can('banners.manage') },
    { to: '/panel/personal', text: 'Gestión de personal', icon: UserRoundCog, visible: can('roles.manage') },
  ]
  return <div className="min-h-screen bg-[#f8f9fb] md:flex">
    <aside className={`${open ? 'block' : 'hidden'} min-h-screen border-r border-slate-100 bg-white px-5 py-6 md:block md:w-64 md:shrink-0`}>
      <div className="flex items-center justify-between"><Brand /><button className="md:hidden" onClick={() => setOpen(false)} aria-label="Cerrar menú"><X/></button></div>
      <div className="mt-10 text-xs font-bold uppercase tracking-widest text-slate-400">Administración</div>
      <nav aria-label="Menú de administración" className="mt-3 space-y-2 text-sm">
        {links.filter(link => link.visible).map(link => <Link key={link.to} className={`flex items-center gap-3 rounded-xl px-4 py-3 font-semibold ${location.pathname === link.to || (link.to === '/panel/productos' && location.pathname.startsWith('/panel/productos/')) ? 'bg-brand-pale text-brand-dark' : 'text-slate-600 hover:bg-slate-50'}`} to={link.to} onClick={() => setOpen(false)}><link.icon size={18}/>{link.text}</Link>)}
        <div className="mt-4 border-t border-slate-100 pt-4 text-xs font-bold uppercase tracking-widest text-slate-400">Cuenta</div>
        <Link className="flex items-center gap-3 rounded-xl px-4 py-3 text-slate-600 hover:bg-slate-50" to="/cuenta" onClick={() => setOpen(false)}><UserRound size={18}/> Mi cuenta</Link>
        <Link className="flex items-center gap-3 rounded-xl px-4 py-3 text-slate-600 hover:bg-slate-50" to="/" onClick={() => setOpen(false)}><Store size={18}/> Ir a la tienda</Link>
      </nav>
      <div className="mt-12 rounded-xl bg-slate-50 p-4"><p className="text-xs font-bold text-ink">{profile?.full_name || 'Personal autorizado'}</p><p className="mt-1 text-xs text-slate-500">{access.roles.map(role => ROLE_NAMES[role]).join(', ')}</p></div>
      <button className="mt-5 flex items-center gap-3 px-4 py-2 text-sm font-semibold text-slate-500 hover:text-brand" onClick={() => void exit()}><LogOut size={17}/> Cerrar sesión</button>
    </aside>
    <div className="min-w-0 flex-1"><header className="flex items-center gap-3 border-b border-slate-100 bg-white px-5 py-5 md:px-10"><button className="md:hidden" onClick={() => setOpen(true)} aria-label="Abrir menú"><Menu/></button><ShieldCheck className="text-brand" size={19}/><span className="text-sm font-semibold text-slate-700">Panel privado · Datos reales de Supabase</span></header><main className="mx-auto max-w-6xl px-5 py-10 md:px-10"><Outlet/></main></div>
  </div>
}
