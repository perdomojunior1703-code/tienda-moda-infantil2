import { Route, Routes } from 'react-router-dom'
import { ProtectedRoute } from './components/ProtectedRoute'
import { PublicLayout } from './layouts/PublicLayout'
import { AuthLayout } from './layouts/AuthLayout'
import { AdminLayout } from './layouts/AdminLayout'
import { HomePage } from './pages/HomePage'
import { ShopPage } from './pages/ShopPage'
import { ProductDetailPage } from './pages/ProductDetailPage'
import { CartPage } from './pages/CartPage'
import { FavoritesPage } from './pages/FavoritesPage'
import { AboutStorePage } from './pages/AboutStorePage'
import { BannersPage } from './pages/BannersPage'
import { LoginPage } from './pages/LoginPage'
import { RegisterPage } from './pages/RegisterPage'
import { ForgotPasswordPage } from './pages/ForgotPasswordPage'
import { ResetPasswordPage } from './pages/ResetPasswordPage'
import { AccountPage } from './pages/AccountPage'
import { DashboardPage } from './pages/DashboardPage'
import { StaffPage } from './pages/StaffPage'
import { CategoriesPage } from './pages/CategoriesPage'
import { ProductsPage } from './pages/ProductsPage'
import { ProductEditorPage } from './pages/ProductEditorPage'
import { OptionsPage } from './pages/OptionsPage'
import { InventoryPage } from './pages/InventoryPage'
import { AccessDeniedPage } from './pages/AccessDeniedPage'
import { NotFoundPage } from './pages/NotFoundPage'
import { CheckoutPage } from './pages/CheckoutPage'
import { MyOrdersPage } from './pages/MyOrdersPage'
import { OrderTrackingPage } from './pages/OrderTrackingPage'
import { OrdersAdminPage } from './pages/OrdersAdminPage'
import { ShippingAdminPage } from './pages/ShippingAdminPage'

export default function App() {
  return <Routes>
    <Route element={<PublicLayout />}>
      <Route index element={<HomePage />} />
      <Route path="catalogo" element={<ShopPage/>}/>
      <Route path="producto/:slug" element={<ProductDetailPage/>}/>
      <Route path="carrito" element={<CartPage/>}/>
      <Route path="favoritos" element={<FavoritesPage/>}/>
      <Route path="nosotros" element={<AboutStorePage/>}/>
      <Route element={<ProtectedRoute />}><Route path="cuenta" element={<AccountPage />}/><Route path="checkout" element={<CheckoutPage/>}/><Route path="mis-pedidos" element={<MyOrdersPage/>}/><Route path="seguimiento/:number" element={<OrderTrackingPage/>}/></Route>
      <Route path="sin-acceso" element={<AccessDeniedPage/>}/>
    </Route>
    <Route element={<AuthLayout />}>
      <Route path="ingresar" element={<LoginPage/>}/>
      <Route path="registrarse" element={<RegisterPage/>}/>
      <Route path="recuperar" element={<ForgotPasswordPage/>}/>
      <Route path="restablecer" element={<ResetPasswordPage/>}/>
    </Route>
    <Route element={<ProtectedRoute permission="panel.access" />}>
      <Route element={<AdminLayout />}>
        <Route path="panel" element={<DashboardPage/>} />
        <Route element={<ProtectedRoute permission="roles.manage" />}><Route path="panel/personal" element={<StaffPage/>}/></Route>
        <Route element={<ProtectedRoute permission="orders.read" />}><Route path="panel/pedidos" element={<OrdersAdminPage/>}/></Route>
        <Route element={<ProtectedRoute permission="shipping.manage" />}><Route path="panel/envios" element={<ShippingAdminPage/>}/></Route>
        <Route element={<ProtectedRoute permission="banners.manage" />}><Route path="panel/banners" element={<BannersPage/>}/></Route>
        <Route element={<ProtectedRoute permission="catalog.read" />}>
          <Route path="panel/categorias" element={<CategoriesPage/>}/>
          <Route path="panel/productos" element={<ProductsPage/>}/>
          <Route path="panel/opciones" element={<OptionsPage/>}/>
        </Route>
        <Route element={<ProtectedRoute permission="catalog.manage" />}>
          <Route path="panel/productos/nuevo" element={<ProductEditorPage/>}/>
          <Route path="panel/productos/:id" element={<ProductEditorPage/>}/>
        </Route>
        <Route element={<ProtectedRoute permission="inventory.read" />}>
          <Route path="panel/inventario" element={<InventoryPage/>}/>
        </Route>
      </Route>
    </Route>
    <Route path="*" element={<NotFoundPage />} />
  </Routes>
}
