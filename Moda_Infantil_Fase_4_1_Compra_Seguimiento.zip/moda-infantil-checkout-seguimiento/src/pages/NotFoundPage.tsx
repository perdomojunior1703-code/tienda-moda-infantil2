import { Link } from 'react-router-dom'

export function NotFoundPage() {
  return <div className="mx-auto max-w-lg px-5 py-24 text-center"><h1 className="font-display text-5xl font-bold text-brand">404</h1><h2 className="mt-4 font-display text-xl font-semibold">Página no encontrada</h2><Link className="btn-primary mx-auto mt-8 !w-auto" to="/">Volver al inicio</Link></div>
}
