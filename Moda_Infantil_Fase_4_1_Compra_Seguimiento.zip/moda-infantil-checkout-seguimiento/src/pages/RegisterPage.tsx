import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { Link, Navigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { supabase } from '../lib/supabase'

const schema = z.object({
  full_name: z.string().trim().min(2, 'Escribe tu nombre.').max(120, 'Nombre demasiado largo.'),
  email: z.email('Escribe un correo válido.'),
  password: z.string().min(8, 'La contraseña debe tener al menos 8 caracteres.'),
  confirm: z.string(),
}).refine(data => data.password === data.confirm, { message: 'Las contraseñas no coinciden.', path: ['confirm'] })
type Fields = z.infer<typeof schema>

export function RegisterPage() {
  const { user } = useAuth()
  const [status, setStatus] = useState('')
  const [error, setError] = useState('')
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<Fields>({ resolver: zodResolver(schema) })
  if (user) return <Navigate to="/cuenta" replace />

  async function onSubmit(data: Fields) {
    if (!supabase) return setError('Configura Supabase en .env antes de registrarte.')
    setError(''); setStatus('')
    const { error: authError } = await supabase.auth.signUp({
      email: data.email.trim(), password: data.password,
      options: { data: { full_name: data.full_name.trim() }, emailRedirectTo: `${window.location.origin}/cuenta` },
    })
    if (authError) setError(authError.message)
    else setStatus('Solicitud recibida. Si Supabase requiere verificación de correo, revisa tu bandeja de entrada y sigue el enlace para activar la cuenta.')
  }
  return <>
    <h1 className="font-display text-2xl font-bold">Crear una cuenta</h1>
    <p className="mb-7 mt-2 text-sm text-slate-500">Tu cuenta se creará con el rol de cliente.</p>
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <label className="form-label">Nombre completo<input className="form-input" autoComplete="name" {...register('full_name')} /></label>
      {errors.full_name && <p className="-mt-2 text-xs text-red-700">{errors.full_name.message}</p>}
      <label className="form-label">Correo electrónico<input className="form-input" type="email" autoComplete="email" {...register('email')} /></label>
      {errors.email && <p className="-mt-2 text-xs text-red-700">{errors.email.message}</p>}
      <label className="form-label">Contraseña<input className="form-input" type="password" autoComplete="new-password" {...register('password')} /></label>
      {errors.password && <p className="-mt-2 text-xs text-red-700">{errors.password.message}</p>}
      <label className="form-label">Confirmar contraseña<input className="form-input" type="password" autoComplete="new-password" {...register('confirm')} /></label>
      {errors.confirm && <p className="-mt-2 text-xs text-red-700">{errors.confirm.message}</p>}
      {error && <p role="alert" className="rounded-xl bg-red-50 p-3 text-sm text-red-800">{error}</p>}
      {status && <p role="status" className="rounded-xl bg-emerald-50 p-3 text-sm text-emerald-800">{status}</p>}
      <button type="submit" disabled={isSubmitting || !!status} className="btn-primary">{isSubmitting ? 'Registrando...' : 'Crear cuenta'}</button>
    </form>
    <p className="mt-6 text-center text-sm text-slate-500">¿Ya tienes cuenta? <Link className="font-semibold text-brand hover:underline" to="/ingresar">Inicia sesión</Link></p>
  </>
}
