import { useQuery } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { ClipboardList, PackageCheck } from 'lucide-react'
import { OrderTimeline } from '../features/orders/OrderTimeline'
import { getMyOrders, orderLabel, deliveryLabel } from '../features/orders/api'
import { formatCop } from '../features/storefront/api'

export function MyOrdersPage(){
  const {data=[],error,isLoading,refetch}=useQuery({queryKey:['orders-mine'],queryFn:getMyOrders,refetchInterval:60_000})
  return <div className="store-shell py-12"><div className="flex flex-wrap items-center justify-between gap-4"><div><p className="store-pill">Tus compras</p><h1 className="store-section-heading mt-4">Mis pedidos</h1><p className="mt-3 text-sm text-slate-500">Consulta el estado registrado por la tienda. El pago se verifica por separado.</p></div><button onClick={()=>void refetch()} className="store-outline">Actualizar pedidos</button></div>
    {isLoading&&<p className="mt-8">Consultando tus pedidos…</p>}
    {error&&<p role="alert" className="mt-8 rounded-xl bg-red-50 p-5 text-red-800">{error.message}</p>}
    {!isLoading&&!error&&data.length===0&&<div className="mt-9 rounded-3xl bg-white p-12 text-center"><ClipboardList className="mx-auto text-slate-300" size={44}/><h2 className="mt-5 text-xl font-bold">Todavía no hay pedidos</h2><Link className="store-primary mt-5" to="/catalogo">Explorar colección</Link></div>}
    <div className="mt-8 space-y-5">{data.map(o=><article key={o.id} className="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm"><div className="flex flex-wrap items-start justify-between gap-4"><div><h2 className="text-xl font-bold">{o.number}</h2><p className="mt-1 text-xs text-slate-500">{new Date(o.created_at).toLocaleString('es-CO')}</p></div><div className="text-right"><span className="rounded-full bg-red-50 px-3 py-1 text-xs font-bold text-brand">{orderLabel[o.status]}</span><p className="mt-2 text-xs text-slate-500">Pago: {o.payment}</p></div></div>
      <OrderTimeline order={o}/><p className="mt-5 text-sm font-semibold">{deliveryLabel[o.method]} · {formatCop(o.total)}</p>
      <ul className="mt-3 space-y-2 text-sm text-slate-600">{o.items.map((i,k)=><li key={k}>• {i.name} — {i.size} / {i.color} · {i.quantity} unidad(es)</li>)}</ul>
      {o.tracking_number&&<p className="mt-4 flex items-center gap-2 rounded-xl bg-slate-50 p-3 text-sm"><PackageCheck size={18}/> Guía: <strong>{o.tracking_number}</strong> {o.carrier&&`(${o.carrier})`}</p>}
      <Link className="store-outline mt-5" to={`/seguimiento/${encodeURIComponent(o.number)}`}>Ver seguimiento completo</Link>
      <details className="mt-4 text-sm"><summary className="cursor-pointer font-semibold text-brand">Ver historial de seguimiento</summary><ol className="mt-3 space-y-2 text-slate-600">{o.history.map((h,k)=><li key={k}>{new Date(h.at).toLocaleString('es-CO')}: {orderLabel[h.status]}{h.reason?` — ${h.reason}`:''}</li>)}</ol></details>
    </article>)}</div>
  </div>
}
