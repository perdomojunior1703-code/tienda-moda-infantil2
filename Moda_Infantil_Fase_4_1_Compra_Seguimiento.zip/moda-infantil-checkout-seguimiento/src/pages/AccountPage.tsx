import { useEffect, useState } from 'react'
import { zodResolver } from '@hookform/resolvers/zod'
import { useForm } from 'react-hook-form'
import { z } from 'zod'
import { useNavigate, Link } from 'react-router-dom'
import { RefreshCw, ShieldCheck, UserRound } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import { ROLE_NAMES } from '../lib/access'
import { supabase } from '../lib/supabase'

const schema = z.object({
  full_name: z.string().trim().min(2, 'Mínimo dos caracteres.').max(120, 'Nombre demasiado largo.'),
  phone: z.string().trim().max(25, 'Número demasiado largo.'),
})
type Fields = z.infer<typeof schema>

export function AccountPage() {
  const { user, profile, access, refreshAccess, signOut } = useAuth()
  const navigate = useNavigate()
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')
  const { register, handleSubmit, reset, formState: { errors, isSubmitting } } = useForm<Fields>({
    resolver: zodResolver(schema), defaultValues: { full_name: '', phone: '' },
  })
  useEffect(() => { if (profile) reset({ full_name: profile.full_name, phone: profile.phone ?? '' }) }, [profile, reset])

  async function onSubmit(values: Fields) {
    if (!supabase || !user) return
    setError(''); setMessage('')
    const { error: updateError } = await supabase.from('profiles').update({ full_name: values.full_name.trim(), phone: values.phone.trim() || null }).eq('id', user.id)
    if (updateError) setError(updateError.message)
    else { setMessage('Perfil actualizado correctamente.'); await refreshAccess() }
  }
  async function exit() {
    try { await signOut(); navigate('/', { replace: true }) }
    catch { setError('No se pudo cerrar sesión. Intenta nuevamente.') }
  }
  return <div className="mx-auto max-w-4xl px-5 py-12">
    <div className="mb-8 flex flex-wrap items-start justify-between gap-4"><div><p className="text-sm font-semibold text-brand">Tu espacio</p><h1 className="mt-1 font-display text-3xl font-bold">Mi cuenta</h1><p className="mt-2 text-sm text-slate-500">Administra tus datos y consulta tus permisos.</p></div><button onClick={exit} className="btn-ghost">Cerrar sesión</button></div>
    <div className="grid gap-6 md:grid-cols-5">
      <section className="panel-card md:col-span-3">
        <div className="mb-5 flex items-center gap-2 font-display font-semibold"><UserRound className="text-brand" size={20}/> Datos personales</div>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <label className="form-label">Correo electrónico<input disabled className="form-input !bg-slate-50" value={user?.email ?? ''} readOnly /></label>
          <label className="form-label">Nombre completo<input className="form-input" autoComplete="name" {...register('full_name')}/></label>
          {errors.full_name && <p className="text-xs text-red-700">{errors.full_name.message}</p>}
          <label className="form-label">Teléfono<input className="form-input" autoComplete="tel" {...register('phone')}/></label>
          {errors.phone && <p className="text-xs text-red-700">{errors.phone.message}</p>}
          {error && <p role="alert" className="rounded-xl bg-red-50 p-3 text-sm text-red-700">{error}</p>}
          {message && <p role="status" className="rounded-xl bg-emerald-50 p-3 text-sm text-emerald-800">{message}</p>}
          <button disabled={isSubmitting} type="submit" className="btn-primary">{isSubmitting ? 'Guardando...' : 'Guardar cambios'}</button>
        </form>
      </section>
      <aside className="panel-card md:col-span-2">
        <div className="mb-5 flex items-center gap-2 font-display font-semibold"><ShieldCheck className="text-brand" size={20}/> Acceso actual</div>
        <div className="flex flex-wrap gap-2">{access.roles.map(role => <span className="rounded-full bg-brand-pale px-3 py-1 text-xs font-semibold text-brand-dark" key={role}>{ROLE_NAMES[role]}</span>)}</div>
        <p className="mt-5 text-xs leading-6 text-slate-500">Los permisos se consultan desde la base de datos. No puedes cambiar tu propio rol desde tu cuenta.</p>
        <button className="btn-ghost mt-5 w-full" type="button" onClick={() => void refreshAccess()}><RefreshCw size={15}/> Actualizar permisos</button>
        {access.permissions.includes('panel.access') && <Link to="/panel" className="btn-primary mt-4">Ir al panel</Link>}
      </aside>
    </div>
  </div>
}
