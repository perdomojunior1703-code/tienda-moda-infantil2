import { useState, type FormEvent } from 'react'
import { CheckCircle2, ImagePlus, Pencil, Plus, Save, Trash2, X } from 'lucide-react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { supabase } from '../lib/supabase'
import { bannerPhoto, safeSiteLink, type AdminBanner } from '../features/storefront/api'
import { PageHeading, Notice } from '../features/catalog/components'

type BannerForm = { id:string;title:string;description:string;image_path:string;button_text:string;target_url:string;sort_order:string;is_active:boolean;starts_at:string;ends_at:string }
const blank: BannerForm = {id:'',title:'',description:'',image_path:'',button_text:'',target_url:'/catalogo',sort_order:'0',is_active:false,starts_at:'',ends_at:''}

async function loadBanners():Promise<AdminBanner[]> {
  if (!supabase) throw new Error('Supabase no está configurado')
  const {data,error} = await supabase.rpc('storefront_manage_banners')
  if (error) throw new Error(error.message)
  if (!Array.isArray(data)) throw new Error('Respuesta de banners incorrecta')
  return data as AdminBanner[]
}
function formatDateForInput(s:string|null) {
  if (!s) return ''
  const date=new Date(s)
  const local = new Date(date.getTime() - date.getTimezoneOffset()*60_000)
  return local.toISOString().slice(0,16)
}
export function BannersPage() {
  const [form,setForm] = useState<BannerForm>(blank)
  const [file,setFile] = useState<File|null>(null)
  const [busy,setBusy] = useState(false)
  const [error,setError] = useState('')
  const [success,setSuccess] = useState('')
  const qc = useQueryClient()
  const {data=[],isLoading,error:queryError} = useQuery({queryKey:['admin-banners'],queryFn:loadBanners})
  function edit(b:AdminBanner) {setForm({id:b.id,title:b.title,description:b.description??'',image_path:b.image_path,button_text:b.button_text??'',target_url:b.target_url??'',sort_order:String(b.sort_order),is_active:b.is_active,starts_at:formatDateForInput(b.starts_at),ends_at:formatDateForInput(b.ends_at)});setFile(null);setError('');setSuccess('')}
  function clear(){setForm(blank);setFile(null);setError('')}
  async function save(event:FormEvent) {
    event.preventDefault()
    if (!supabase) return
    setBusy(true);setError('');setSuccess('')
    let uploadedPath:string|null=null
    try {
      if (form.title.trim().length<2) throw new Error('Escribe un título de al menos 2 caracteres.')
      if (form.target_url && !safeSiteLink(form.target_url.trim())) throw new Error('Enlace no válido. Usa /catalogo o una URL https://')
      if (!file && !form.image_path) throw new Error('Primero selecciona una imagen para el banner.')
      if (file) {
        if (!['image/jpeg','image/png','image/webp'].includes(file.type)) throw new Error('La imagen debe ser JPG, PNG o WebP.')
        if (file.size>5*1024*1024) throw new Error('La imagen supera 5 MB.')
        const ext=file.type==='image/jpeg'?'jpg':file.type==='image/png'?'png':'webp'
        uploadedPath=`banners/${crypto.randomUUID()}.${ext}`
        const {error:upError}=await supabase.storage.from('promo-banners').upload(uploadedPath,file,{contentType:file.type,upsert:false})
        if (upError) throw new Error(`Error subiendo imagen: ${upError.message}`)
      }
      const {error:rpcError}=await supabase.rpc('storefront_save_banner',{
        p_id:form.id||null,p_title:form.title.trim(),p_description:form.description.trim()||null,
        p_image_path:uploadedPath??form.image_path,p_button_text:form.button_text.trim()||null,
        p_target_url:form.target_url.trim()||null,p_sort_order:Number(form.sort_order),p_is_active:form.is_active,
        p_starts_at:form.starts_at?new Date(form.starts_at).toISOString():null,
        p_ends_at:form.ends_at?new Date(form.ends_at).toISOString():null,
      })
      if (rpcError) throw new Error(rpcError.message)
      if (uploadedPath && form.image_path) {await supabase.storage.from('promo-banners').remove([form.image_path])}
      clear();setSuccess('Banner guardado. Si está activo y dentro de la vigencia, aparecerá en la tienda.')
      await Promise.all([qc.invalidateQueries({queryKey:['admin-banners']}),qc.invalidateQueries({queryKey:['storefront']})])
    } catch(e) {
      if (uploadedPath) await supabase.storage.from('promo-banners').remove([uploadedPath])
      setError(e instanceof Error?e.message:'No se pudo guardar el banner.')
    } finally {setBusy(false)}
  }
  async function remove(b:AdminBanner) {
    if (!supabase||!window.confirm(`¿Eliminar el banner «${b.title}»?`)) return
    setBusy(true);setError('');setSuccess('')
    try {const {error:rpcError}=await supabase.rpc('storefront_delete_banner',{p_id:b.id});if(rpcError)throw rpcError
      const {error:storageError}=await supabase.storage.from('promo-banners').remove([b.image_path]);
      setSuccess(storageError ? 'Banner eliminado. No se pudo retirar el archivo antiguo de Storage.' : 'Banner eliminado correctamente.')
      if(form.id===b.id) clear()
      await Promise.all([qc.invalidateQueries({queryKey:['admin-banners']}),qc.invalidateQueries({queryKey:['storefront']})])
    }catch(e){setError(e instanceof Error?e.message:'No se pudo eliminar el banner.')}finally{setBusy(false)}
  }
  return <><PageHeading eyebrow="Tienda pública · Fase 3" title="Banners y promociones" description="Administra las imágenes y mensajes que aparecen en la portada. Estos cambios se publican desde Supabase." action={<button type="button" className="btn-primary !w-auto" onClick={clear}><Plus size={16}/> Nuevo banner</button>}/>
    <Notice error={error|| (queryError?queryError.message:undefined)} success={success}/>
    <section className="panel-card"><h2 className="font-display text-lg font-bold">{form.id?'Editar banner':'Crear banner'}</h2><p className="mt-2 text-sm text-slate-500">JPG, PNG o WebP hasta 5 MB. La imagen es obligatoria para crear un banner.</p><form className="mt-6 grid gap-4 lg:grid-cols-2" onSubmit={e=>void save(e)}>
      <label className="form-label">Título *<input className="form-input" required maxLength={160} value={form.title} onChange={e=>setForm(f=>({...f,title:e.target.value}))} placeholder="Ej. Pequeños estilos, grandes sonrisas"/></label>
      <label className="form-label">Texto del botón<input className="form-input" maxLength={70} value={form.button_text} onChange={e=>setForm(f=>({...f,button_text:e.target.value}))} placeholder="Ver colección"/></label>
      <label className="form-label lg:col-span-2">Descripción<textarea className="form-input" rows={2} maxLength={1000} value={form.description} onChange={e=>setForm(f=>({...f,description:e.target.value}))}/></label>
      <label className="form-label">Destino del botón<input className="form-input" value={form.target_url} onChange={e=>setForm(f=>({...f,target_url:e.target.value}))} placeholder="/catalogo"/></label>
      <label className="form-label">Orden<input type="number" className="form-input" value={form.sort_order} onChange={e=>setForm(f=>({...f,sort_order:e.target.value}))}/></label>
      <label className="form-label">Inicio de vigencia (opcional)<input type="datetime-local" className="form-input" value={form.starts_at} onChange={e=>setForm(f=>({...f,starts_at:e.target.value}))}/></label>
      <label className="form-label">Fin de vigencia (opcional)<input type="datetime-local" className="form-input" value={form.ends_at} onChange={e=>setForm(f=>({...f,ends_at:e.target.value}))}/></label>
      <label className="form-label lg:col-span-2">Imagen del banner<input type="file" accept="image/jpeg,image/png,image/webp" className="form-input" onChange={e=>setFile(e.target.files?.[0]??null)}/></label>
      <label className="flex items-center gap-2 text-sm font-semibold"><input type="checkbox" checked={form.is_active} onChange={e=>setForm(f=>({...f,is_active:e.target.checked}))}/> Mostrar en la portada</label>
      <div className="flex gap-3 lg:col-span-2"><button disabled={busy} className="btn-primary !w-auto"><Save size={17}/>{busy?'Guardando…':'Guardar banner'}</button>{form.id&&<button type="button" onClick={clear} className="btn-ghost"><X size={17}/> Cancelar edición</button>}</div>
    </form></section>
    <section className="mt-7"><h2 className="mb-4 font-display text-xl font-bold">Banners registrados</h2>{isLoading?<p>Cargando banners…</p>:data.length?<div className="grid gap-5 md:grid-cols-2">{data.map(b=><div key={b.id} className="overflow-hidden rounded-2xl border border-slate-100 bg-white shadow-sm"><div className="aspect-[16/7] bg-red-50"><img src={bannerPhoto(b.image_path)} alt={b.title} className="h-full w-full object-cover"/></div><div className="p-5"><p className="flex items-center gap-2 text-xs font-bold text-slate-500">{b.is_active?<><CheckCircle2 className="text-emerald-600" size={17}/> Activo</>:'Inactivo'} · Orden {b.sort_order}</p><h3 className="mt-3 font-display text-lg font-bold">{b.title}</h3><p className="mt-2 line-clamp-2 text-sm text-slate-500">{b.description}</p><div className="mt-4 flex flex-wrap gap-2"><button type="button" className="btn-ghost" disabled={busy} onClick={()=>edit(b)}><Pencil size={15}/> Editar</button><button className="btn-ghost text-red-600" disabled={busy} onClick={()=>void remove(b)}><Trash2 size={15}/> Eliminar</button></div></div></div>)}</div>:<div className="panel-card flex items-center gap-3 text-sm text-slate-500"><ImagePlus size={24}/> No hay banners configurados. La portada mostrará su diseño de bienvenida.</div>}</section>
  </>
}
