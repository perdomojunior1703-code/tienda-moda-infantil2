import { useState, type FormEvent } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { useAuth } from '../context/AuthContext'
import { deliveryLabel, getShippingAdmin, orderRpc, type DeliveryMethod, type ShippingRate } from '../features/orders/api'
import { formatCop } from '../features/storefront/api'

export function ShippingAdminPage(){
  const {access}=useAuth()
  const {data,error,isLoading}=useQuery({queryKey:['shipping-admin'],queryFn:getShippingAdmin})
  const qc=useQueryClient()
  const [editId,setEditId]=useState<string|null>(null)
  const [name,setName]=useState('')
  const [method,setMethod]=useState<'domicilio_local'|'envio_nacional'>('domicilio_local')
  const [price,setPrice]=useState('')
  const [city,setCity]=useState('')
  const [department,setDepartment]=useState('')
  const [active,setActive]=useState(true)
  const [wa,setWa]=useState<string|undefined>(undefined)
  const [carrierName,setCarrierName]=useState('')
  const [busy,setBusy]=useState(false)
  const [notice,setNotice]=useState('')
  const [problem,setProblem]=useState('')
  async function refresh(){await Promise.all([qc.invalidateQueries({queryKey:['shipping-admin']}),qc.invalidateQueries({queryKey:['shipping-public']}),qc.invalidateQueries({queryKey:['storefront']})])}
  function edit(r:ShippingRate){setEditId(r.id);setName(r.zone_name);setMethod(r.method==='envio_nacional'?'envio_nacional':'domicilio_local');setPrice(String(r.price));setCity(r.city||'');setDepartment(r.department||'');setActive(r.active??true)}
  function reset(){setEditId(null);setName('');setPrice('');setCity('');setDepartment('');setActive(true)}
  async function submitRate(e:FormEvent){e.preventDefault();setBusy(true);setProblem('');setNotice('')
    try{await orderRpc('shipping_save_rate',{p_id:editId,p_name:name.trim(),p_method:method,p_price:Number(price),p_city:city.trim(),p_department:department.trim(),p_active:active});await refresh();reset();setNotice('Tarifa guardada correctamente.')}
    catch(err){setProblem(err instanceof Error?err.message:'No se guardó la tarifa')}
    finally{setBusy(false)}
  }
  async function saveContact(){setBusy(true);setProblem('');try{await orderRpc('shipping_save_whatsapp',{p_whatsapp:wa===undefined?data?.whatsapp||null:wa});await refresh();setNotice('WhatsApp actualizado.')}
    catch(e){setProblem(e instanceof Error?e.message:'Error al actualizar WhatsApp')}finally{setBusy(false)}}
  async function addCarrier(e:FormEvent){e.preventDefault();setBusy(true);setProblem('');try{await orderRpc('shipping_save_carrier',{p_id:null,p_name:carrierName.trim(),p_website:null,p_active:true});await refresh();setCarrierName('');setNotice('Transportadora registrada.')}
    catch(e){setProblem(e instanceof Error?e.message:'No se guardó la transportadora')}finally{setBusy(false)}}
  return <><p className="text-sm font-bold text-brand">Logística · Fase 4</p><h1 className="mt-2 font-display text-3xl font-bold">Envíos y entregas</h1><p className="mt-3 text-sm text-slate-500">Define tarifas reales antes de activar domicilios o envíos. La recogida en tienda no tiene tarifa.</p>
  {isLoading&&<p className="mt-5">Cargando configuración...</p>}{error&&<p className="mt-5 text-red-700">{error.message}</p>}
  {problem&&<p role="alert" className="mt-5 rounded-xl bg-red-50 p-4 text-sm text-red-800">{problem}</p>}{notice&&<p className="mt-5 rounded-xl bg-emerald-50 p-4 text-sm text-emerald-800">{notice}</p>}
  {data&&<><section className="panel-card mt-7"><h2 className="font-display text-xl font-bold">WhatsApp del negocio</h2><p className="mt-2 text-xs text-slate-500">Incluye el indicativo, por ejemplo +57 para Colombia. Se utilizará al enviar pedidos.</p><div className="mt-4 flex flex-wrap items-end gap-3"><label className="form-label flex-1">Número<input type="tel" className="form-input" value={wa??data.whatsapp??''} disabled={!access.permissions.includes('store.configure')} onChange={e=>setWa(e.target.value)} placeholder="+57XXXXXXXXXX"/></label>{access.permissions.includes('store.configure')&&<button className="btn-primary !w-auto" disabled={busy} onClick={()=>void saveContact()}>Guardar WhatsApp</button>}</div></section>
    <section className="panel-card mt-7"><h2 className="font-display text-xl font-bold">Tarifas configuradas</h2><div className="mt-5 grid gap-3">{data.rates.map(r=><div key={r.id} className="flex flex-wrap items-center justify-between gap-4 rounded-xl border p-4"><div><p className="font-semibold">{r.zone_name} · {deliveryLabel[r.method as DeliveryMethod]}</p><p className="mt-1 text-xs text-slate-500">{r.city||'Todas las ciudades'}, {r.department||'Todos los departamentos'} · {formatCop(r.price)} · {r.active?'Activa':'Inactiva'}</p></div><button className="btn-ghost" onClick={()=>edit(r)}>Editar</button></div>)}{!data.rates.length&&<p className="text-sm text-slate-500">Todavía no hay zonas ni tarifas.</p>}</div></section>
    <form className="panel-card mt-7" onSubmit={e=>void submitRate(e)}><h2 className="font-display text-xl font-bold">{editId?'Editar tarifa':'Agregar una zona y su tarifa'}</h2><div className="mt-5 grid gap-4 sm:grid-cols-2"><label className="form-label">Nombre de la zona<input className="form-input" required minLength={3} maxLength={120} placeholder="Ej. Casco urbano" value={name} onChange={e=>setName(e.target.value)}/></label><label className="form-label">Modalidad<select className="form-input" value={method} onChange={e=>setMethod(e.target.value as typeof method)}><option value="domicilio_local">Domicilio local</option><option value="envio_nacional">Envío nacional</option></select></label><label className="form-label">Ciudad {method==='domicilio_local'&&'(obligatoria)'}<input className="form-input" required={method==='domicilio_local'} value={city} maxLength={100} onChange={e=>setCity(e.target.value)} placeholder="Ej. Neiva"/></label><label className="form-label">Departamento {method==='domicilio_local'&&'(obligatorio)'}<input className="form-input" required={method==='domicilio_local'} value={department} maxLength={100} onChange={e=>setDepartment(e.target.value)} placeholder="Ej. Huila"/></label><label className="form-label">Precio COP<input type="number" min={0} max={10000000} step={100} required className="form-input" value={price} onChange={e=>setPrice(e.target.value)}/></label><label className="form-label flex items-center gap-3 pt-7"><input type="checkbox" checked={active} onChange={e=>setActive(e.target.checked)}/>Tarifa activa</label></div><div className="mt-5 flex flex-wrap gap-3"><button className="btn-primary !w-auto" disabled={busy}>Guardar tarifa</button>{editId&&<button type="button" className="btn-ghost" onClick={reset}>Cancelar edición</button>}</div></form>
    <section className="panel-card mt-7"><h2 className="font-display text-xl font-bold">Transportadoras</h2><div className="mt-4 flex flex-wrap gap-3">{data.carriers.map(c=><span className="rounded-full bg-slate-100 px-3 py-2 text-xs" key={c.id}>{c.name}</span>)}</div><form className="mt-4 flex flex-wrap gap-3" onSubmit={e=>void addCarrier(e)}><input className="form-input !mt-0 flex-1" required minLength={3} maxLength={140} value={carrierName} onChange={e=>setCarrierName(e.target.value)} placeholder="Nombre de la transportadora"/><button className="btn-primary !w-auto" disabled={busy}>Agregar</button></form><p className="mt-3 text-xs text-slate-500">El registro permite escribir manualmente la guía. No existe conexión automática con transportadoras.</p></section>
  </>}</>
}
