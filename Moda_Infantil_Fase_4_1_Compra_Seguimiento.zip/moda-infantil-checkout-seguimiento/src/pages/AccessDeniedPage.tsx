import { Link } from 'react-router-dom'
import { ShieldAlert } from 'lucide-react'

export function AccessDeniedPage() {
  return <div className="mx-auto max-w-xl px-5 py-24 text-center"><ShieldAlert className="mx-auto text-brand" size={52}/><h1 className="mt-6 font-display text-3xl font-bold">Acceso restringido</h1><p className="mt-4 text-slate-600">Tu cuenta está autenticada, pero no cuenta con permisos para este módulo. Si crees que es un error, solicita acceso al administrador.</p><Link className="btn-primary mx-auto mt-8 !w-auto" to="/cuenta">Volver a mi cuenta</Link></div>
}
