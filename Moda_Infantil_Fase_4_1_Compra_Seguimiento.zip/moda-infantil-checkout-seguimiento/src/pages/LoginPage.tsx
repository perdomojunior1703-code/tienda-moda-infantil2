import { useState, type FormEvent } from 'react'
import { Link, Navigate, useLocation, useNavigate } from 'react-router-dom'
import { ArrowRight } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import { supabase } from '../lib/supabase'

export function LoginPage() {
  const { user } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const from = (location.state as { from?: string } | null)?.from || '/cuenta'
  if (user) return <Navigate to={from} replace />

  async function handleLogin(event: FormEvent) {
    event.preventDefault()
    if (!supabase) return setError('Primero configura Supabase en el archivo .env.')
    setBusy(true); setError('')
    const { error: authError } = await supabase.auth.signInWithPassword({ email: email.trim(), password })
    setBusy(false)
    if (authError) setError('No se pudo ingresar. Revisa el correo, contraseña y la verificación de tu cuenta.')
    else navigate(from, { replace: true })
  }
  async function handleGoogle() {
    if (!supabase) return setError('Primero configura Supabase en el archivo .env.')
    setBusy(true); setError('')
    const { error: authError } = await supabase.auth.signInWithOAuth({ provider: 'google', options: { redirectTo: `${window.location.origin}/cuenta` } })
    if (authError) { setError(authError.message); setBusy(false) }
  }
  return <>
    <h1 className="font-display text-2xl font-bold">Bienvenido de nuevo</h1>
    <p className="mb-7 mt-2 text-sm text-slate-500">Ingresa para continuar en Moda Infantil.</p>
    <form onSubmit={handleLogin} className="space-y-5">
      <label className="form-label">Correo electrónico<input className="form-input" type="email" autoComplete="email" required value={email} onChange={e => setEmail(e.target.value)} placeholder="correo@ejemplo.com" /></label>
      <label className="form-label">Contraseña<input className="form-input" type="password" autoComplete="current-password" required value={password} onChange={e => setPassword(e.target.value)} minLength={6} /></label>
      <div className="text-right"><Link className="text-xs font-semibold text-brand hover:underline" to="/recuperar">¿Olvidaste tu contraseña?</Link></div>
      {error && <p role="alert" className="rounded-xl bg-red-50 p-3 text-sm text-red-800">{error}</p>}
      <button className="btn-primary" type="submit" disabled={busy}>{busy ? 'Ingresando...' : 'Ingresar'} <ArrowRight size={16}/></button>
    </form>
    <div className="my-6 flex items-center gap-3 text-xs text-slate-400"><div className="h-px flex-1 bg-slate-200"/> o continúa con <div className="h-px flex-1 bg-slate-200"/></div>
    <button type="button" className="btn-ghost w-full" disabled={busy} onClick={handleGoogle}>Continuar con Google</button>
    <p className="mt-7 text-center text-sm text-slate-500">¿Todavía no tienes cuenta? <Link className="font-semibold text-brand hover:underline" to="/registrarse">Regístrate</Link></p>
  </>
}
