import { useState } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { ClipboardList, RefreshCcw } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import { deliveryLabel, getStaffOrders, getShippingAdmin, nextStatus, orderLabel, orderRpc, type OrderInfo, type OrderStatus } from '../features/orders/api'
import { formatCop } from '../features/storefront/api'

function OrderAdminCard({o,canManage,onChange,carriers}:{o:OrderInfo;canManage:boolean;onChange:()=>Promise<void>;carriers:{id:string;name:string;active:boolean}[]}){
  const [status,setStatus]=useState('')
  const [reason,setReason]=useState('')
  const [carrier,setCarrier]=useState('')
  const [tracking,setTracking]=useState('')
  const [busy,setBusy]=useState(false)
  const [error,setError]=useState('')
  async function send(){
    if(!status||busy)return
    if(!window.confirm(`¿Cambiar el pedido ${o.number} a "${orderLabel[status as OrderStatus]}"?`))return
    setBusy(true);setError('')
    try{
      await orderRpc('orders_change_status',{p_order_id:o.id,p_status:status,p_reason:reason||null,
        p_carrier_id:status==='enviado'?(carrier||null):null,
        p_tracking_number:status==='enviado'?(tracking||null):null})
      setStatus('');setReason('');setCarrier('');setTracking('');await onChange()
    }catch(e){setError(e instanceof Error?e.message:'Error actualizando pedido')}
    finally{setBusy(false)}
  }
  const options=nextStatus[o.status].filter(s=>s!=='enviado'||o.method!=='recogida')
  return <article className="panel-card"><div className="flex flex-wrap items-start justify-between gap-3"><div><h2 className="font-display text-lg font-bold">{o.number}</h2><p className="mt-1 text-xs text-slate-500">{new Date(o.created_at).toLocaleString('es-CO')} · {o.channel}</p></div><div><span className="rounded-full bg-red-50 px-3 py-1 text-xs font-bold text-brand">{orderLabel[o.status]}</span><p className="mt-2 text-xs">Pago: <strong>{o.payment}</strong></p></div></div>
  <div className="mt-4 grid gap-4 sm:grid-cols-2"><div><p className="text-xs font-bold uppercase tracking-wide text-slate-500">Comprador</p><p className="mt-1 text-sm">{o.name} · {o.phone}</p><p className="mt-2 text-sm">{deliveryLabel[o.method]}</p>{o.address&&<p className="mt-1 text-sm text-slate-500">{o.address.address}, {o.address.city}, {o.address.department}</p>}</div><div><p className="text-xs font-bold uppercase tracking-wide text-slate-500">Productos y valores</p>{o.items.map((item,k)=><p className="mt-1 text-sm" key={k}>{item.quantity} × {item.name} ({item.size}/{item.color})</p>)}<p className="mt-2 font-bold text-brand">{formatCop(o.total)} <span className="text-xs font-normal text-slate-500">(incluye {formatCop(o.shipping)} de entrega)</span></p></div></div>
    {o.notes&&<p className="mt-3 rounded-lg bg-slate-50 p-3 text-xs text-slate-600">Nota: {o.notes}</p>}
    {o.tracking_number&&<p className="mt-3 text-sm">Transportadora: {o.carrier||'Por definir'} · Guía: {o.tracking_number}</p>}
    {canManage&&options.length>0&&<div className="mt-5 border-t pt-4"><div className="grid gap-3 sm:grid-cols-2"><label className="form-label">Cambiar estado<select className="form-input" value={status} onChange={e=>setStatus(e.target.value)}><option value="">Selecciona...</option>{options.map(s=><option key={s} value={s}>{orderLabel[s]}</option>)}</select></label><label className="form-label">Motivo / observación<input className="form-input" value={reason} maxLength={500} onChange={e=>setReason(e.target.value)} placeholder={status==='cancelado'?'Obligatorio al cancelar':'Opcional'}/></label>{status==='enviado'&&<><label className="form-label">Transportadora<select className="form-input" value={carrier} onChange={e=>setCarrier(e.target.value)}><option value="">Sin asignar</option>{carriers.filter(c=>c.active).map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select></label><label className="form-label">Número de guía<input className="form-input" value={tracking} onChange={e=>setTracking(e.target.value)} maxLength={100}/></label></>}</div><button className="btn-primary !w-auto mt-4" disabled={busy||!status||(status==='cancelado'&&reason.trim().length<5)} onClick={()=>void send()}>{busy?'Guardando...':'Actualizar estado'}</button></div>}
    {error&&<p role="alert" className="mt-3 text-sm text-red-700">{error}</p>}
    <details className="mt-4 border-t pt-3"><summary className="cursor-pointer text-xs font-bold text-slate-500">Historial de cambios</summary>{o.history.map((h,k)=><p className="mt-2 text-xs text-slate-500" key={k}>{new Date(h.at).toLocaleString('es-CO')} · {orderLabel[h.status]}{h.reason?` — ${h.reason}`:''}</p>)}</details>
  </article>
}
export function OrdersAdminPage(){
  const {access}=useAuth()
  const canManage=access.permissions.includes('orders.manage')
  const qc=useQueryClient()
  const {data=[],error,isLoading,refetch}=useQuery({queryKey:['orders-staff'],queryFn:getStaffOrders})
  const {data:shipping}=useQuery({queryKey:['shipping-admin'],queryFn:getShippingAdmin,enabled:access.permissions.includes('shipping.manage')})
  const [filter,setFilter]=useState('todos')
  const filtered=data.filter(o=>filter==='todos'||o.status===filter)
  async function refresh(){await Promise.all([qc.invalidateQueries({queryKey:['orders-staff']}),qc.invalidateQueries({queryKey:['storefront']})])}
  return <><div className="flex flex-wrap items-end justify-between gap-4"><div><p className="text-sm font-bold text-brand">Pedidos · Fase 4</p><h1 className="mt-1 font-display text-3xl font-bold">Seguimiento de pedidos</h1><p className="mt-3 text-sm text-slate-500">Confirmar un pedido descuenta inventario. Marcarlo pagado NO está disponible sin verificación de pago.</p></div><button className="btn-ghost" onClick={()=>void refetch()}><RefreshCcw size={17}/> Actualizar</button></div>
  <div className="panel-card my-7 flex flex-wrap items-center gap-4"><ClipboardList size={21} className="text-brand"/><span className="text-sm font-bold">{data.length} pedidos</span><label className="form-label ml-auto">Filtrar estado<select className="form-input" value={filter} onChange={e=>setFilter(e.target.value)}><option value="todos">Todos</option>{Object.entries(orderLabel).map(([k,v])=><option key={k} value={k}>{v}</option>)}</select></label></div>
  {isLoading&&<p>Cargando pedidos...</p>}{error&&<p role="alert" className="text-red-700">{error.message}</p>}
  {!isLoading&&!error&&!filtered.length&&<p className="panel-card text-sm text-slate-500">No hay pedidos con este filtro.</p>}
  <div className="grid gap-5">{filtered.map(o=><OrderAdminCard key={o.id} o={o} canManage={canManage} onChange={refresh} carriers={shipping?.carriers||[]}/>)}</div></>
}
