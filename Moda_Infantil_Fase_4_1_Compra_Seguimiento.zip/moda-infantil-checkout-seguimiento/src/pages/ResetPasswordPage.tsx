import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'

const schema = z.object({ password: z.string().min(8, 'Mínimo 8 caracteres.'), confirm: z.string() })
  .refine(data => data.password === data.confirm, { message: 'Las contraseñas no coinciden.', path: ['confirm'] })
type Fields = z.infer<typeof schema>

export function ResetPasswordPage() {
  const [error, setError] = useState('')
  const [saved, setSaved] = useState(false)
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<Fields>({ resolver: zodResolver(schema) })
  async function onSubmit(data: Fields) {
    if (!supabase) return setError('Supabase no está configurado.')
    setError('')
    const { error: authError } = await supabase.auth.updateUser({ password: data.password })
    if (authError) setError('No se pudo cambiar la contraseña. Comprueba que abriste un enlace de recuperación válido y vigente.')
    else setSaved(true)
  }
  return <>
    <h1 className="font-display text-2xl font-bold">Nueva contraseña</h1>
    {saved ? <><p className="mt-3 rounded-xl bg-emerald-50 p-4 text-sm text-emerald-800">Tu contraseña fue actualizada.</p><Link className="btn-primary mt-5" to="/cuenta">Ir a mi cuenta</Link></> :
      <form className="mt-6 space-y-4" onSubmit={handleSubmit(onSubmit)}>
        <label className="form-label">Contraseña nueva<input className="form-input" type="password" autoComplete="new-password" {...register('password')} /></label>
        {errors.password && <p className="text-xs text-red-700">{errors.password.message}</p>}
        <label className="form-label">Repetir contraseña<input className="form-input" type="password" autoComplete="new-password" {...register('confirm')} /></label>
        {errors.confirm && <p className="text-xs text-red-700">{errors.confirm.message}</p>}
        {error && <p className="rounded-xl bg-red-50 p-3 text-sm text-red-700" role="alert">{error}</p>}
        <button className="btn-primary" type="submit" disabled={isSubmitting}>{isSubmitting ? 'Guardando...' : 'Cambiar contraseña'}</button>
      </form>}
  </>
}
