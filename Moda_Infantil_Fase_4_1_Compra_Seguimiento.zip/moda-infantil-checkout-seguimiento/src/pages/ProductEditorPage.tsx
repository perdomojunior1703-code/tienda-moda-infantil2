import { useEffect, useRef, useState, type FormEvent } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { Archive, ArrowDownRight, ArrowLeft, ArrowUpRight, ImagePlus, Pencil, Plus, Save, Trash2, X } from 'lucide-react'
import { z } from 'zod'
import { formatCop, mutateCatalog, productImageUrl, removeProductImage, slugify, uploadProductImages, type Variant } from '../features/catalog/api'
import { useCatalog, useRefreshCatalog } from '../features/catalog/hooks'
import { useAuth } from '../context/AuthContext'
import { CatalogStatus, Field, Notice, PageHeading } from '../features/catalog/components'

interface ProductForm {
  name: string; slug: string; description: string; sku: string; category_id: string;
  sale_price: string; previous_price: string; cost_price: string;
  is_active: boolean; is_featured: boolean; is_new: boolean
}
const blankProduct: ProductForm = {
  name: '', slug: '', description: '', sku: '', category_id: '', sale_price: '', previous_price: '', cost_price: '',
  is_active: false, is_featured: false, is_new: false,
}
const productSchema = z.object({
  name: z.string().trim().min(2, 'Escribe el nombre del producto.').max(180),
  slug: z.string().regex(/^[a-z0-9]+(-[a-z0-9]+)*$/, 'Identificador inválido.'),
  description: z.string().max(5000),
  sale_price: z.number().nonnegative().max(9999999999),
  previous_price: z.number().nonnegative().nullable(),
  cost_price: z.number().nonnegative().nullable(),
}).refine(item => item.previous_price === null || item.previous_price > item.sale_price, { message: 'El precio anterior debe ser mayor al precio de venta.' })
interface VariantForm { size_id: string; color_id: string; sku: string; barcode: string; price_override: string; low_stock_threshold: string; is_active: boolean }
const blankVariant: VariantForm = { size_id: '', color_id: '', sku: '', barcode: '', price_override: '', low_stock_threshold: '3', is_active: true }

export function ProductEditorPage() {
  const { id } = useParams()
  const isNew = !id || id === 'nuevo'
  const navigate = useNavigate()
  const { data, isLoading, error } = useCatalog()
  const refresh = useRefreshCatalog()
  const { access } = useAuth()
  const canAdjustStock = access.permissions.includes('inventory.adjust')
  const product = !isNew ? data?.products.find(p => p.id === id) : undefined
  const loadedId = useRef<string | null>(null)
  const fileInput = useRef<HTMLInputElement>(null)
  const [form, setForm] = useState<ProductForm>(blankProduct)
  const [busy, setBusy] = useState(false)
  const [problem, setProblem] = useState('')
  const [message, setMessage] = useState('')
  const [variantForm, setVariantForm] = useState<VariantForm>(blankVariant)
  const [editVariant, setEditVariant] = useState<Variant | null>(null)
  const [variantOpen, setVariantOpen] = useState(false)
  const [stockVariant, setStockVariant] = useState<Variant | null>(null)
  const [stockKind, setStockKind] = useState<'entrada' | 'salida'>('entrada')
  const [stockQuantity, setStockQuantity] = useState('1')
  const [stockReason, setStockReason] = useState('')
  const [stockRequestId, setStockRequestId] = useState<string | null>(null)

  useEffect(() => {
    if (isNew && loadedId.current !== 'nuevo') { setForm(blankProduct); loadedId.current='nuevo' }
    if (product && loadedId.current !== product.id) {
      setForm({ name: product.name, slug: product.slug, description: product.description ?? '', sku: product.sku ?? '', category_id: product.category_id ?? '',
        sale_price: String(product.sale_price), previous_price: product.previous_price === null ? '' : String(product.previous_price),
        cost_price: product.cost_price === null ? '' : String(product.cost_price),
        is_active: product.is_active, is_featured: product.is_featured, is_new: product.is_new })
      loadedId.current = product.id
    }
  }, [isNew, product])

  async function saveProduct(event: FormEvent) {
    event.preventDefault()
    const parsed = productSchema.safeParse({ name: form.name, slug: form.slug, description: form.description,
      sale_price: Number(form.sale_price), previous_price: form.previous_price === '' ? null : Number(form.previous_price),
      cost_price: form.cost_price === '' ? null : Number(form.cost_price) })
    if (!parsed.success || form.sale_price.trim() === '') { setProblem(parsed.success ? 'Indica el precio de venta.' : parsed.error.issues[0].message); return }
    setBusy(true); setProblem(''); setMessage('')
    try {
      const savedId = await mutateCatalog<string>('catalog_save_product', {
        p_id: isNew ? null : id, p_category_id: form.category_id || null, p_name: parsed.data.name,
        p_slug: parsed.data.slug, p_description: parsed.data.description, p_sku: form.sku,
        p_sale_price: parsed.data.sale_price, p_previous_price: parsed.data.previous_price,
        p_cost_price: parsed.data.cost_price, p_is_active: form.is_active, p_is_featured: form.is_featured, p_is_new: form.is_new,
      })
      await refresh()
      if (isNew) navigate(`/panel/productos/${savedId}`, { replace: true })
      setMessage(isNew ? 'Producto creado. Ahora agrega sus tallas, colores, existencias e imágenes.' : 'Producto actualizado correctamente.')
    } catch (err) { setProblem(err instanceof Error ? err.message : 'No se pudo guardar el producto.') }
    finally { setBusy(false) }
  }

  async function archive() {
    if (!product || !window.confirm(`¿Archivar «${product.name}»? No se eliminarán las ventas ni los movimientos históricos.`)) return
    setBusy(true); setProblem('')
    try { await mutateCatalog('catalog_archive_product', { p_id: product.id }); await refresh(); navigate('/panel/productos') }
    catch (err) { setProblem(err instanceof Error ? err.message : 'No se pudo archivar.') }
    finally { setBusy(false) }
  }

  function openVariant(variant?: Variant) {
    setStockVariant(null); setStockRequestId(null)
    setEditVariant(variant ?? null); setVariantOpen(true); setProblem(''); setMessage('')
    const stock = data?.inventory.find(stockItem => stockItem.variant_id === variant?.id)
    setVariantForm(variant ? { size_id: variant.size_id, color_id: variant.color_id, sku: variant.sku,
      barcode: variant.barcode ?? '', price_override: variant.price_override === null ? '' : String(variant.price_override),
      low_stock_threshold: String(stock?.low_stock_threshold ?? 3), is_active: variant.is_active } : blankVariant)
  }

  async function saveVariant(event: FormEvent) {
    event.preventDefault()
    if (!product) return
    if (!variantForm.size_id || !variantForm.color_id || !variantForm.sku.trim() ||
      !Number.isInteger(Number(variantForm.low_stock_threshold)) || Number(variantForm.low_stock_threshold)<0 ||
      (variantForm.price_override !== '' && (Number.isNaN(Number(variantForm.price_override)) || Number(variantForm.price_override)<0))) {
      setProblem('Completa talla, color, SKU, precio y umbral con valores válidos.'); return
    }
    setBusy(true); setProblem(''); setMessage('')
    try {
      await mutateCatalog('catalog_save_variant', { p_id: editVariant?.id ?? null, p_product_id: product.id,
        p_size_id: variantForm.size_id, p_color_id: variantForm.color_id, p_sku: variantForm.sku.trim(),
        p_barcode: variantForm.barcode, p_price_override: variantForm.price_override === '' ? null : Number(variantForm.price_override),
        p_is_active: variantForm.is_active, p_low_stock_threshold: Number(variantForm.low_stock_threshold) })
      await refresh(); setVariantOpen(false); setMessage(editVariant ? 'Variante actualizada.' : 'Variante creada con existencias iniciales de cero. Ajusta el inventario desde su módulo.')
    } catch (err) { setProblem(err instanceof Error ? err.message : 'No se pudo guardar la variante.') }
    finally { setBusy(false) }
  }

  function openStockEditor(variant: Variant) {
    setVariantOpen(false)
    setStockVariant(variant)
    setStockKind('entrada')
    setStockQuantity('1')
    setStockReason('')
    setStockRequestId(null)
    setProblem('')
    setMessage('')
  }

  useEffect(() => {
    if (stockVariant) document.getElementById('ajuste-existencias')?.scrollIntoView({ behavior: 'smooth', block: 'center' })
  }, [stockVariant])

  async function saveStock(event: FormEvent) {
    event.preventDefault()
    if (!stockVariant || !canAdjustStock || busy) return
    const units = Number(stockQuantity)
    const currentUnits = data?.inventory.find(item => item.variant_id === stockVariant.id)?.quantity ?? 0
    if (!Number.isSafeInteger(units) || units < 1 || units > 1_000_000) {
      setProblem('Escribe una cantidad entera entre 1 y 1.000.000.'); return
    }
    if (stockReason.trim().length < 5 || stockReason.trim().length > 500) {
      setProblem('Escribe un motivo de 5 a 500 caracteres.'); return
    }
    if (stockKind === 'salida' && units > currentUnits) {
      setProblem(`No puedes retirar ${units} unidades: el inventario muestra ${currentUnits}.`); return
    }
    const delta = stockKind === 'entrada' ? units : -units
    if (!window.confirm(`¿Confirmas ${stockKind === 'entrada' ? 'sumar' : 'retirar'} ${units} unidad(es) de ${stockVariant.sku}? Quedará registrado en el historial.`)) return
    const requestId = stockRequestId ?? crypto.randomUUID()
    setStockRequestId(requestId) // Reutilizar tras errores de red para impedir movimientos duplicados.
    setBusy(true); setProblem(''); setMessage('')
    try {
      const result = await mutateCatalog<{ balance_after: number; repeated: boolean }>('catalog_adjust_stock', {
        p_variant_id: stockVariant.id, p_delta: delta, p_reason: stockReason.trim(), p_request_id: requestId,
      })
      await refresh()
      setStockVariant(null)
      setStockRequestId(null)
      setMessage(result.repeated
        ? `Este movimiento ya estaba registrado. Existencias: ${result.balance_after}.`
        : `Inventario actualizado: ${result.balance_after} unidad(es). El movimiento quedó registrado.`)
    } catch (err) {
      setProblem(err instanceof Error ? err.message : 'No se pudieron modificar las unidades.')
    } finally { setBusy(false) }
  }

  async function upload(files: FileList | null) {
    if (!product || !files?.length) return
    setBusy(true); setProblem(''); setMessage('')
    try { await uploadProductImages(product.id, Array.from(files), data?.images.filter(image => image.product_id === product.id).length ?? 0)
      await refresh(); setMessage('Fotografías guardadas correctamente.') }
    catch (err) { await refresh(); setProblem(err instanceof Error ? err.message : 'No se pudieron subir las fotografías.') }
    finally { setBusy(false); if (fileInput.current) fileInput.current.value='' }
  }
  async function removeImage(imageId: string) {
    const image = data?.images.find(item => item.id === imageId)
    if (!image || !window.confirm('¿Eliminar esta fotografía?')) return
    setBusy(true); setProblem(''); setMessage('')
    try { await removeProductImage(image); await refresh(); setMessage('Fotografía eliminada.') }
    catch (err) { setProblem(err instanceof Error ? err.message : 'No se pudo eliminar.') }
    finally { setBusy(false) }
  }

  const variants = data?.variants.filter(v => v.product_id === product?.id) ?? []
  const images = data?.images.filter(img => img.product_id === product?.id) ?? []
  return <>
    <PageHeading eyebrow="Catálogo · Fase 2" title={isNew ? 'Nuevo producto' : 'Editar producto'} description="Guarda primero los datos generales; después agrega variantes y fotografías." action={<Link to="/panel/productos" className="btn-ghost"><ArrowLeft size={17}/> Volver a productos</Link>}/>
    <Notice error={problem} success={message}/>
    <CatalogStatus loading={isLoading} error={error}>
      {!isNew && !product ? <div className="panel-card">Producto no encontrado.</div> : product?.deleted_at ? <div className="panel-card">Este producto está archivado y no admite modificaciones.</div> : <>
        <section className="panel-card"><h2 className="mb-6 font-display text-xl font-bold">Datos generales</h2>
          <form className="grid gap-5 md:grid-cols-2" onSubmit={e => void saveProduct(e)}>
            <Field label="Nombre del producto *"><input required maxLength={180} className="form-input" value={form.name} onChange={e => setForm(f => ({...f,name:e.target.value,slug:isNew ? slugify(e.target.value) : f.slug}))} placeholder="Ej. Conjunto infantil de algodón" /></Field>
            <Field label="Identificador URL *"><input required className="form-input" value={form.slug} onChange={e => setForm(f => ({...f,slug:slugify(e.target.value)}))}/></Field>
            <Field label="Categoría"><select className="form-input" value={form.category_id} onChange={e => setForm(f => ({...f,category_id:e.target.value}))}><option value="">Sin categoría</option>{data?.categories.map(c => <option key={c.id} value={c.id}>{c.name}{!c.is_active ? ' (oculta)' : ''}</option>)}</select></Field>
            <Field label="Referencia del producto"><input className="form-input" maxLength={80} value={form.sku} onChange={e => setForm(f => ({...f,sku:e.target.value}))} placeholder="Ej. CONJ-001"/></Field>
            <div className="md:col-span-2"><Field label="Descripción"><textarea className="form-input min-h-28" maxLength={5000} value={form.description} onChange={e => setForm(f => ({...f,description:e.target.value}))} placeholder="Tejido, cuidados, detalles…" /></Field></div>
            <Field label="Precio de venta (COP) *"><input type="number" min="0" step="0.01" required className="form-input" value={form.sale_price} onChange={e => setForm(f => ({...f,sale_price:e.target.value}))}/></Field>
            <Field label="Precio anterior (COP)"><input type="number" min="0" step="0.01" className="form-input" value={form.previous_price} onChange={e => setForm(f => ({...f,previous_price:e.target.value}))} placeholder="Opcional; mayor al actual"/></Field>
            <Field label="Costo de adquisición (COP)"><input type="number" min="0" step="0.01" className="form-input" value={form.cost_price} onChange={e => setForm(f => ({...f,cost_price:e.target.value}))} placeholder="Privado; solo personal autorizado"/></Field>
            <div className="rounded-xl bg-slate-50 p-4 text-xs leading-6 text-slate-600">El costo no se expone al cliente. Los descuentos automáticos y el cálculo de ganancias se completarán en fases posteriores.</div>
            <div className="md:col-span-2 flex flex-wrap gap-5 text-sm"><label className="flex items-center gap-2"><input type="checkbox" checked={form.is_active} onChange={e => setForm(f => ({...f,is_active:e.target.checked}))}/> Mostrar en tienda</label><label className="flex items-center gap-2"><input type="checkbox" checked={form.is_featured} onChange={e => setForm(f => ({...f,is_featured:e.target.checked}))}/> Destacado</label><label className="flex items-center gap-2"><input type="checkbox" checked={form.is_new} onChange={e => setForm(f => ({...f,is_new:e.target.checked}))}/> Novedad</label></div>
            <div className="md:col-span-2 flex flex-wrap gap-3"><button className="btn-primary !w-auto" disabled={busy}><Save size={17}/>{busy ? 'Guardando…' : 'Guardar producto'}</button>{product && <button type="button" className="btn-ghost text-red-700" disabled={busy} onClick={() => void archive()}><Archive size={16}/> Archivar producto</button>}</div>
          </form>
        </section>
        {product && <>
          <section className="panel-card mt-7" id="variantes">
            <div className="mb-5 flex flex-wrap items-center justify-between gap-3"><div><h2 className="font-display text-xl font-bold">Variantes: talla y color</h2><p className="mt-2 text-sm text-slate-500">Cada combinación tiene SKU y existencias independientes.</p></div><button className="btn-ghost" onClick={() => openVariant()}><Plus size={17}/> Agregar variante</button></div>
            {variantOpen && <form className="mb-5 grid gap-4 rounded-2xl border border-red-100 bg-red-50/40 p-5 md:grid-cols-2" onSubmit={e => void saveVariant(e)}>
              <div className="md:col-span-2 flex justify-between"><h3 className="font-bold">{editVariant ? 'Editar datos de la variante' : 'Nueva variante'}</h3><button type="button" onClick={() => setVariantOpen(false)} aria-label="Cerrar"><X size={18}/></button></div>
              <Field label="Talla *"><select required className="form-input" value={variantForm.size_id} onChange={e => setVariantForm(f => ({...f,size_id:e.target.value}))}><option value="">Selecciona una talla</option>{data?.sizes.map(s => <option value={s.id} key={s.id}>{s.label}</option>)}</select></Field>
              <Field label="Color *"><select required className="form-input" value={variantForm.color_id} onChange={e => setVariantForm(f => ({...f,color_id:e.target.value}))}><option value="">Selecciona un color</option>{data?.colors.map(c => <option value={c.id} key={c.id}>{c.name}</option>)}</select></Field>
              <Field label="SKU de variante *"><input required maxLength={80} className="form-input" value={variantForm.sku} onChange={e => setVariantForm(f => ({...f,sku:e.target.value}))} placeholder="CONJ-001-T4-ROJO" /></Field>
              <Field label="Código de barras (opcional)"><input maxLength={100} className="form-input" value={variantForm.barcode} onChange={e => setVariantForm(f => ({...f,barcode:e.target.value}))}/></Field>
              <Field label="Precio especial (COP)"><input type="number" step="0.01" min="0" className="form-input" value={variantForm.price_override} onChange={e => setVariantForm(f => ({...f,price_override:e.target.value}))} placeholder="Vacío = precio general"/></Field>
              <Field label="Alerta al quedar N unidades"><input type="number" min="0" step="1" required className="form-input" value={variantForm.low_stock_threshold} onChange={e => setVariantForm(f => ({...f,low_stock_threshold:e.target.value}))}/></Field>
              {editVariant && <p className="md:col-span-2 text-sm text-slate-600">Para cambiar las unidades, cierra este formulario y pulsa «Cambiar unidades» junto a la variante. Así el movimiento queda en el historial de inventario.</p>}
              <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={variantForm.is_active} onChange={e => setVariantForm(f => ({...f,is_active:e.target.checked}))}/> Variante disponible para venta</label>
              <div className="md:col-span-2"><button disabled={busy} className="btn-primary !w-auto"><Save size={17}/>{busy ? 'Guardando…' : 'Guardar variante'}</button></div>
            </form>}
            {variants.length ? <div className="overflow-x-auto"><table className="w-full min-w-[650px] text-left text-sm"><thead className="border-b border-slate-100 text-xs uppercase text-slate-500"><tr><th className="py-3">Talla / Color</th><th>Referencia</th><th>Precio</th><th>Existencias</th><th>Acción</th></tr></thead><tbody>{variants.map(v => {
              const stock = data?.inventory.find(i => i.variant_id === v.id)
              return <tr key={v.id} className="border-b border-slate-100"><td className="py-3">{data?.sizes.find(s => s.id === v.size_id)?.label} / {data?.colors.find(c => c.id === v.color_id)?.name}{!v.is_active && <span className="ml-2 text-xs text-slate-400">(oculta)</span>}</td><td>{v.sku}</td><td>{formatCop(v.price_override ?? product.sale_price)}</td><td className={(stock?.quantity ?? 0) <= (stock?.low_stock_threshold ?? 3) ? 'font-bold text-red-700' : 'font-semibold'}>{stock?.quantity ?? 0}</td><td><div className="flex flex-wrap gap-2"><button type="button" className="btn-ghost !py-2" disabled={busy} onClick={() => openVariant(v)}><Pencil size={15}/> Editar datos</button>{canAdjustStock && <button type="button" className="btn-ghost !py-2" disabled={busy} onClick={() => openStockEditor(v)}><Plus size={15}/> Cambiar unidades</button>}</div></td></tr>
            })}</tbody></table></div> : <p className="text-sm text-slate-500">Aún no hay variantes. Agrega la primera para comenzar a registrar existencias.</p>}
            {stockVariant && canAdjustStock && <div id="ajuste-existencias" className="mt-6 rounded-2xl border border-red-200 bg-red-50/40 p-5">
              <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
                <div><h3 className="font-display text-lg font-bold">Cambiar unidades · {stockVariant.sku}</h3><p className="mt-1 text-sm text-slate-600">Existencias actuales: <strong>{data?.inventory.find(i => i.variant_id === stockVariant.id)?.quantity ?? 0}</strong>. Aquí agregas o retiras unidades; no creas otra variante.</p></div>
                <button type="button" disabled={busy} className="btn-ghost !py-2" onClick={() => {setStockVariant(null);setStockRequestId(null)}}><X size={16}/> Cerrar</button>
              </div>
              <form className="grid gap-4 md:grid-cols-3" onSubmit={e => void saveStock(e)}>
                <Field label="Movimiento"><select className="form-input" value={stockKind} disabled={busy} onChange={e => {setStockKind(e.target.value as 'entrada' | 'salida');setStockRequestId(null)}}><option value="entrada">Agregar unidades (+)</option><option value="salida">Quitar unidades (−)</option></select></Field>
                <Field label="Cantidad de unidades *"><input className="form-input" required type="number" min="1" max="1000000" step="1" value={stockQuantity} disabled={busy} onChange={e => {setStockQuantity(e.target.value);setStockRequestId(null)}} /></Field>
                <Field label="Motivo del cambio *"><input className="form-input" required minLength={5} maxLength={500} value={stockReason} placeholder="Ej. Llegaron unidades nuevas" disabled={busy} onChange={e => {setStockReason(e.target.value);setStockRequestId(null)}} /></Field>
                <div className="md:col-span-3 flex flex-wrap items-center gap-4">
                  <button type="submit" disabled={busy} className="btn-primary !w-auto">{stockKind === 'entrada' ? <ArrowUpRight size={17}/> : <ArrowDownRight size={17}/>} {busy ? 'Guardando…' : 'Guardar cambio de unidades'}</button>
                  <span className="text-sm text-slate-600">El cambio quedará registrado con fecha, responsable y motivo.</span>
                </div>
              </form>
            </div>}
            <p className="mt-4 text-sm text-slate-500">También puedes revisar existencias y movimientos anteriores desde <Link className="font-semibold text-brand underline" to="/panel/inventario">Inventario</Link>.</p>
          </section>
          <section className="panel-card mt-7"><div className="flex flex-wrap items-center justify-between gap-3"><div><h2 className="font-display text-xl font-bold">Fotografías</h2><p className="mt-2 text-sm text-slate-500">JPG, PNG o WebP; máximo 5 MB por imagen.</p></div><label className={`btn-ghost ${busy ? 'pointer-events-none opacity-50' : ''}`}><ImagePlus size={17}/> Subir imágenes<input className="sr-only" type="file" ref={fileInput} accept="image/jpeg,image/png,image/webp" multiple disabled={busy} onChange={e => void upload(e.target.files)}/></label></div>
            <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-4">{images.map(image => <div key={image.id} className="relative overflow-hidden rounded-xl border border-slate-100 bg-slate-50"><img className="aspect-square w-full object-cover" src={productImageUrl(image.storage_path)} alt={image.alt_text ?? product.name}/><button type="button" disabled={busy} onClick={() => void removeImage(image.id)} className="absolute right-2 top-2 rounded-lg bg-white p-2 text-red-700 shadow" aria-label="Eliminar imagen"><Trash2 size={16}/></button></div>)}</div>
            {!images.length && <p className="mt-5 text-sm text-slate-500">Todavía no hay fotografías para este producto.</p>}
          </section>
        </>}
      </>}
    </CatalogStatus>
  </>
}
