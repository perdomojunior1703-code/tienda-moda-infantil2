import { useState, type FormEvent } from 'react'
import { ImagePlus, Pencil, Plus, Trash2, X } from 'lucide-react'
import { z } from 'zod'
import { useAuth } from '../context/AuthContext'
import { categoryImageUrl, mutateCatalog, slugify, uploadCategoryImage, type Category } from '../features/catalog/api'
import { useCatalog, useRefreshCatalog } from '../features/catalog/hooks'
import { CatalogStatus, Field, Notice, PageHeading } from '../features/catalog/components'

const schema = z.object({ name: z.string().trim().min(2, 'Escribe al menos 2 caracteres').max(120), slug: z.string().regex(/^[a-z0-9]+(-[a-z0-9]+)*$/, 'Utiliza letras minúsculas y guiones'), description: z.string().max(2000), is_active: z.boolean() })
type Form = z.infer<typeof schema>
const empty: Form = { name: '', slug: '', description: '', is_active: true }

export function CategoriesPage() {
  const { access } = useAuth()
  const canEdit = access.permissions.includes('catalog.manage')
  const { data, isLoading, error } = useCatalog()
  const refresh = useRefreshCatalog()
  const [active, setActive] = useState<Category | null>(null)
  const [editing, setEditing] = useState(false)
  const [form, setForm] = useState<Form>(empty)
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState('')
  const [problem, setProblem] = useState('')
  const [filter, setFilter] = useState('')

  function openEditor(category?: Category) {
    setActive(category ?? null); setEditing(true); setProblem(''); setMessage('')
    setForm(category ? { name: category.name, slug: category.slug, description: category.description ?? '', is_active: category.is_active } : empty)
  }
  async function save(event: FormEvent) {
    event.preventDefault()
    const checked = schema.safeParse(form)
    if (!checked.success) { setProblem(checked.error.issues[0].message); return }
    setBusy(true); setProblem(''); setMessage('')
    try {
      await mutateCatalog('catalog_save_category', { p_id: active?.id ?? null,
        p_name: checked.data.name, p_slug: checked.data.slug, p_description: checked.data.description,
        p_is_active: checked.data.is_active, p_parent_id: active?.parent_id ?? null, p_image_path: active?.image_path ?? null })
      await refresh(); setEditing(false); setMessage(active ? 'Categoría actualizada.' : 'Categoría creada.')
    } catch (err) { setProblem(err instanceof Error ? err.message : 'Error al guardar') }
    finally { setBusy(false) }
  }
  async function uploadPhoto(category: Category, file: File | undefined) {
    if (!file) return
    setBusy(true); setProblem(''); setMessage('')
    try { await uploadCategoryImage(category,file); await refresh(); setMessage('Imagen de la categoría actualizada.') }
    catch (err) { setProblem(err instanceof Error ? err.message : 'No se pudo subir la imagen.') }
    finally { setBusy(false) }
  }
  async function remove(category: Category) {
    if (!window.confirm(`¿Eliminar "${category.name}"? Solo se permite si no tiene productos ni subcategorías.`)) return
    setBusy(true); setProblem(''); setMessage('')
    try { await mutateCatalog('catalog_delete_category', { p_id: category.id }); await refresh(); setMessage('Categoría eliminada.') }
    catch (err) { setProblem(err instanceof Error ? err.message : 'No se pudo eliminar') }
    finally { setBusy(false) }
  }
  const categories = (data?.categories ?? []).filter(c => `${c.name} ${c.slug}`.toLowerCase().includes(filter.toLowerCase()))
  return <>
    <PageHeading eyebrow="Catálogo · Fase 2" title="Categorías" description="Organiza las prendas por colección. Puedes desactivar categorías que ya tienen productos." action={canEdit && <button className="btn-primary !w-auto" onClick={() => openEditor()}><Plus size={18}/> Nueva categoría</button>}/>
    <Notice error={problem} success={message}/>
    <CatalogStatus loading={isLoading} error={error}>
      <div className="panel-card mb-5"><label className="form-label">Buscar categorías<input className="form-input" value={filter} onChange={e => setFilter(e.target.value)} placeholder="Nombre o identificador…" /></label></div>
      {editing && canEdit && <section className="panel-card mb-6" aria-label="Editor de categoría">
        <div className="mb-4 flex items-center justify-between"><h2 className="font-display text-lg font-bold">{active ? 'Editar categoría' : 'Crear categoría'}</h2><button className="btn-ghost" type="button" onClick={() => setEditing(false)}><X size={16}/> Cerrar</button></div>
        <form onSubmit={e => void save(e)} className="grid gap-4 md:grid-cols-2">
          <Field label="Nombre"><input required maxLength={120} className="form-input" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value, slug: active ? f.slug : slugify(e.target.value) }))} /></Field>
          <Field label="Identificador (slug)"><input required className="form-input" value={form.slug} onChange={e => setForm(f => ({ ...f, slug: slugify(e.target.value) }))} /></Field>
          <div className="md:col-span-2"><Field label="Descripción"><textarea className="form-input min-h-24" maxLength={2000} value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))}/></Field></div>
          <label className="flex items-center gap-2 text-sm font-medium"><input type="checkbox" checked={form.is_active} onChange={e => setForm(f => ({ ...f, is_active: e.target.checked }))}/> Visible en la tienda</label>
          <div className="md:col-span-2"><button className="btn-primary !w-auto" disabled={busy} type="submit">{busy ? 'Guardando…' : 'Guardar categoría'}</button></div>
        </form>
      </section>}
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{categories.map(category => {
        const count = data?.products.filter(p => p.category_id === category.id && !p.deleted_at).length ?? 0
        return <div key={category.id} className="panel-card">
          {category.image_path && <img className="mb-4 h-40 w-full rounded-xl bg-slate-50 object-cover" src={categoryImageUrl(category.image_path)} alt={category.name}/>}
          <div className="mb-3 flex items-start justify-between gap-3"><h2 className="font-display font-bold">{category.name}</h2><span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${category.is_active ? 'bg-emerald-50 text-emerald-800' : 'bg-slate-100 text-slate-500'}`}>{category.is_active ? 'Activa' : 'Oculta'}</span></div>
          <p className="min-h-12 text-sm leading-6 text-slate-500">{category.description || 'Sin descripción'}</p>
          <p className="mt-3 text-xs font-semibold text-slate-500">{count} productos · /{category.slug}</p>
          {canEdit && <div className="mt-5 flex flex-wrap gap-2"><button className="btn-ghost" onClick={() => openEditor(category)}><Pencil size={15}/> Editar</button><label className={`btn-ghost ${busy ? 'pointer-events-none opacity-60' : ''}`}><ImagePlus size={15}/> Imagen<input className="sr-only" type="file" accept="image/jpeg,image/png,image/webp" disabled={busy} onChange={e => {void uploadPhoto(category,e.target.files?.[0]); e.target.value=''}}/></label><button disabled={busy} className="btn-ghost text-red-600" onClick={() => void remove(category)}><Trash2 size={15}/> Eliminar</button></div>}
        </div>
      })}</div>
      {categories.length === 0 && <div className="panel-card text-sm text-slate-500">No encontramos categorías con ese filtro.</div>}
    </CatalogStatus>
  </>
}
