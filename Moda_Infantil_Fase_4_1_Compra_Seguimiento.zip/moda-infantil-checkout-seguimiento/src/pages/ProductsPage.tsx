import { useState } from 'react'
import { Link } from 'react-router-dom'
import { ImageIcon, Pencil, Plus, Search, SlidersHorizontal } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import { productImageUrl, formatCop } from '../features/catalog/api'
import { useCatalog } from '../features/catalog/hooks'
import { CatalogStatus, PageHeading } from '../features/catalog/components'

export function ProductsPage() {
  const { access } = useAuth()
  const { data, error, isLoading } = useCatalog()
  const [query, setQuery] = useState('')
  const [category, setCategory] = useState('all')
  const [status, setStatus] = useState('active')
  const canEdit = access.permissions.includes('catalog.manage')
  const products = (data?.products ?? []).filter(product => {
    if (status === 'active' && (product.deleted_at || !product.is_active)) return false
    if (status === 'inactive' && !product.deleted_at && product.is_active) return false
    if (category !== 'all' && product.category_id !== category) return false
    return `${product.name} ${product.sku ?? ''} ${product.slug}`.toLowerCase().includes(query.toLowerCase())
  })
  return <>
    <PageHeading eyebrow="Catálogo · Fase 2" title="Productos" description="Registra prendas reales, controla sus precios y administra sus tallas, colores e imágenes." action={canEdit && <Link className="btn-primary !w-auto" to="/panel/productos/nuevo"><Plus size={18}/> Nuevo producto</Link>}/>
    <CatalogStatus loading={isLoading} error={error}>
      <section className="panel-card mb-6 grid items-end gap-3 md:grid-cols-[1fr_200px_190px]">
        <label className="form-label"><span className="flex items-center gap-2"><Search size={17}/> Buscar producto</span><input className="form-input" value={query} onChange={e => setQuery(e.target.value)} placeholder="Nombre, referencia o código…"/></label>
        <label className="form-label"><span className="flex items-center gap-2"><SlidersHorizontal size={17}/> Categoría</span><select className="form-input" value={category} onChange={e => setCategory(e.target.value)}><option value="all">Todas</option>{data?.categories.map(item => <option key={item.id} value={item.id}>{item.name}</option>)}</select></label>
        <label className="form-label">Estado<select className="form-input" value={status} onChange={e => setStatus(e.target.value)}><option value="active">Visibles</option><option value="inactive">Ocultos / archivados</option><option value="all">Todos</option></select></label>
      </section>
      <div className="mb-4 text-sm text-slate-500">{products.length} productos encontrados</div>
      {products.length ? <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">{products.map(p => {
        const mainImage = data?.images.find(image => image.product_id === p.id)
        const variants = data?.variants.filter(item => item.product_id === p.id) ?? []
        const available = variants.reduce((sum, item) => sum + (data?.inventory.find(stock => stock.variant_id === item.id)?.quantity ?? 0), 0)
        return <article key={p.id} className="overflow-hidden rounded-2xl border border-slate-100 bg-white shadow-sm">
          <div className="flex h-48 items-center justify-center overflow-hidden bg-[#f7f8fa]">{mainImage ? <img src={productImageUrl(mainImage.storage_path)} alt={mainImage.alt_text || p.name} className="h-full w-full object-cover" loading="lazy"/> : <ImageIcon className="text-slate-300" size={46}/>}</div>
          <div className="p-5">
            <div className="mb-3 flex flex-wrap gap-2 text-xs font-semibold"><span className="rounded-full bg-slate-100 px-2 py-1 text-slate-600">{data?.categories.find(c => c.id === p.category_id)?.name ?? 'Sin categoría'}</span><span className={`rounded-full px-2 py-1 ${p.is_active && !p.deleted_at ? 'bg-emerald-50 text-emerald-800' : 'bg-red-50 text-red-700'}`}>{p.deleted_at ? 'Archivado' : p.is_active ? 'Visible' : 'Oculto'}</span></div>
            <h2 className="font-display text-lg font-bold">{p.name}</h2><div className="mt-2 flex items-baseline gap-2"><span className="font-bold text-brand-dark">{formatCop(p.sale_price)}</span>{p.previous_price !== null && <span className="text-xs text-slate-400 line-through">{formatCop(p.previous_price)}</span>}</div>
            <p className="mt-3 text-xs text-slate-500">{variants.length} variantes · {available} unidades · SKU: {p.sku || 'Sin referencia'}</p>
            {canEdit && !p.deleted_at && <Link to={`/panel/productos/${p.id}`} className="btn-ghost mt-5 inline-flex"><Pencil size={15}/> Editar y gestionar</Link>}
          </div>
        </article>
      })}</div> : <div className="panel-card text-center text-sm text-slate-500">No hay productos para estos filtros. {canEdit && 'Crea uno con el botón «Nuevo producto».'}</div>}
    </CatalogStatus>
  </>
}
