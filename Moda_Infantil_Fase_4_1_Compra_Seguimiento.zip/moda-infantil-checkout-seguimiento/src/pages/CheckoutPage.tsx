import { useMemo, useState, type FormEvent } from 'react'
import { ArrowLeft, CheckCircle2, MessageCircle, ShieldCheck } from 'lucide-react'
import { Link } from 'react-router-dom'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { useAuth } from '../context/AuthContext'
import { useCart, resolveCart } from '../features/storefront/cart'
import { useStore } from '../features/storefront/hooks'
import { formatCop } from '../features/storefront/api'
import { deliveryLabel, getShipping, orderRpc, whatsappOrderUrl, type DeliveryMethod, type OrderReceipt } from '../features/orders/api'
import { StoreState } from '../features/storefront/ui'

const REQUEST_KEY='moda-infantil:order-draft-id:v4'
function getRequestId(){try{const id=window.localStorage.getItem(REQUEST_KEY);if(id&&/^[0-9a-f-]{36}$/i.test(id))return id}catch{}return crypto.randomUUID()}

export function CheckoutPage(){
  const {user,profile}=useAuth()
  const {data,isLoading,error}=useStore()
  const {lines,clearCart}=useCart()
  const {data:shipping,isLoading:loadingRates,error:rateError}=useQuery({queryKey:['shipping-public'],queryFn:getShipping})
  const qc=useQueryClient()
  const [name,setName]=useState(profile?.full_name||'')
  const [phone,setPhone]=useState(profile?.phone||'')
  const [method,setMethod]=useState<DeliveryMethod>('recogida')
  const [rateId,setRateId]=useState('')
  const [address,setAddress]=useState('')
  const [city,setCity]=useState('')
  const [department,setDepartment]=useState('')
  const [notes,setNotes]=useState('')
  const [busy,setBusy]=useState(false)
  const [problem,setProblem]=useState('')
  const [receipt,setReceipt]=useState<OrderReceipt|null>(null)
  const [whatsapp,setWhatsapp]=useState<string|null>(null)
  const [reqId,setReqId]=useState(getRequestId)
  const resolved=useMemo(()=>data?resolveCart(data,lines):[],[data,lines])
  const rates=shipping?.rates.filter(r=>r.method===method &&
    (!r.city || city.trim().toLowerCase()===r.city.trim().toLowerCase()) &&
    (!r.department || department.trim().toLowerCase()===r.department.trim().toLowerCase()))||[]
  const rate=rates.find(r=>r.id===rateId)
  const subtotal=resolved.reduce((a,b)=>a+b.unitPrice*b.line.quantity,0)
  const invalid=lines.length===0||resolved.length!==lines.length||resolved.some(x=>x.line.quantity>x.available||x.line.quantity<1)
  const shippingCost=method==='recogida'?0:Number(rate?.price||0)
  async function submit(e:FormEvent){
    e.preventDefault()
    if(!user||!data||invalid||busy)return
    if(!shipping?.whatsapp){setProblem('El negocio debe configurar su número de WhatsApp en Panel → Envíos.');return}
    if(method!=='recogida'&&!rate){setProblem('Selecciona una tarifa de entrega disponible para tu zona.');return}
    setBusy(true);setProblem('')
    try{
      try{window.localStorage.setItem(REQUEST_KEY,reqId)}catch{}
      const created=await orderRpc<OrderReceipt>('orders_create_whatsapp',{
        p_request_id:reqId,p_items:lines.map(x=>({variant_id:x.variantId,quantity:x.quantity})),
        p_contact_name:name.trim(),p_contact_phone:phone.trim(),p_shipping_method:method,
        p_shipping_rate_id:method==='recogida'?null:rateId,p_address:address.trim(),
        p_city:city.trim(),p_department:department.trim(),p_notes:notes.trim()
      })
      const messageLines=[...resolved.map(x=>`${x.product.name} (${x.variant.sku}), ${x.line.quantity} und. × ${formatCop(x.unitPrice)}`),
        `Modalidad: ${deliveryLabel[method]}`, `Subtotal: ${formatCop(subtotal)}`,
        `Envío: ${formatCop(shippingCost)}`, `Total estimado: ${formatCop(subtotal+shippingCost)}`]
      const link=whatsappOrderUrl(shipping.whatsapp,created,name,messageLines)
      setReceipt(created);setWhatsapp(link);clearCart()
      const newId=crypto.randomUUID();setReqId(newId)
      try{window.localStorage.removeItem(REQUEST_KEY)}catch{}
      void qc.invalidateQueries({queryKey:['storefront']});void qc.invalidateQueries({queryKey:['orders-mine']})
    }catch(err){setProblem(err instanceof Error?err.message:'No se pudo registrar el pedido.')}
    finally{setBusy(false)}
  }
  if(!user)return <div className="store-shell py-16"><h1 className="store-section-heading">Identifícate para pedir</h1><p className="my-5 text-slate-600">En esta versión los pedidos se registran con una cuenta. El pedido como invitado se habilitará cuando esté lista la protección antispam.</p><Link className="store-primary" to="/ingresar">Iniciar sesión</Link></div>
  if(receipt)return <div className="store-shell py-16"><div className="mx-auto max-w-2xl rounded-3xl border border-emerald-100 bg-white p-9 text-center shadow-sm"><CheckCircle2 size={54} className="mx-auto text-emerald-600"/><h1 className="mt-5 font-display text-3xl font-bold">Pedido registrado</h1><p className="mt-3 text-lg font-semibold">Referencia {receipt.number}</p><p className="mt-4 text-sm leading-7 text-slate-600">Tu pedido está <strong>pendiente</strong>. No se ha cobrado ni confirmado. La reserva de existencias dura 60 minutos; después, la disponibilidad se comprobará nuevamente cuando la tienda confirme el pedido.</p>{whatsapp?<a href={whatsapp} target="_blank" rel="noopener noreferrer" className="store-primary mt-6"><MessageCircle size={19}/> Abrir WhatsApp y enviar resumen</a>:<p className="mt-5 text-red-700">El comercio todavía no tiene un número de WhatsApp válido.</p>}<div className="mt-6 flex flex-col items-center gap-3"><Link to={`/seguimiento/${encodeURIComponent(receipt.number)}`} className="store-outline">Seguir este pedido</Link><Link to="/mis-pedidos" className="font-semibold text-brand underline">Ver todos mis pedidos</Link></div></div></div>
  return <div className="store-shell py-12"><Link className="inline-flex items-center gap-2 text-sm text-slate-500" to="/carrito"><ArrowLeft size={17}/> Volver al carrito</Link><h1 className="store-section-heading mt-5">Finalizar pedido por WhatsApp</h1><p className="mt-3 text-sm text-slate-500">Registro de pedido por WhatsApp. La tienda confirmará los detalles antes del pago.</p>
    <StoreState loading={isLoading||loadingRates} error={error||rateError}>{data && shipping && <div className="mt-8 grid items-start gap-8 lg:grid-cols-[1fr_360px]"><form onSubmit={e=>void submit(e)} className="space-y-6"><section className="rounded-2xl border bg-white p-6"><h2 className="font-display text-xl font-bold">Datos de contacto</h2><div className="mt-5 grid gap-4 md:grid-cols-2"><label className="form-label">Nombre completo<input className="form-input" required minLength={3} maxLength={140} value={name} onChange={e=>setName(e.target.value)}/></label><label className="form-label">Teléfono / WhatsApp<input className="form-input" required type="tel" minLength={10} maxLength={18} value={phone} onChange={e=>setPhone(e.target.value)}/></label></div></section>
    <section className="rounded-2xl border bg-white p-6"><h2 className="font-display text-xl font-bold">Entrega</h2><div className="mt-4 grid gap-3 sm:grid-cols-3">{(['recogida','domicilio_local','envio_nacional'] as DeliveryMethod[]).map(x=><label key={x} className={`cursor-pointer rounded-xl border p-3 text-sm font-semibold ${method===x?'border-brand bg-red-50':'border-slate-200'}`}><input type="radio" className="mr-2" checked={method===x} onChange={()=>{setMethod(x);setRateId('')}}/>{deliveryLabel[x]}</label>)}</div>
      {method!=='recogida'&&<div className="mt-5 grid gap-4 md:grid-cols-2"><label className="form-label md:col-span-2">Dirección de entrega<input className="form-input" required minLength={5} maxLength={300} value={address} onChange={e=>setAddress(e.target.value)}/></label><label className="form-label">Ciudad<input className="form-input" required value={city} maxLength={100} onChange={e=>{setCity(e.target.value);setRateId('')}}/></label><label className="form-label">Departamento<input className="form-input" required value={department} maxLength={100} onChange={e=>{setDepartment(e.target.value);setRateId('')}}/></label><label className="form-label md:col-span-2">Tarifa configurada<select className="form-input" required value={rateId} onChange={e=>setRateId(e.target.value)}><option value="">Selecciona una tarifa...</option>{rates.map(r=><option key={r.id} value={r.id}>{r.zone_name} · {formatCop(r.price)}</option>)}</select></label>{!rates.length&&<p className="md:col-span-2 text-sm text-amber-800">No hay tarifas disponibles para esta modalidad o ubicación. Consulta con la tienda.</p>}</div>}
      {method==='recogida'&&<p className="mt-4 text-sm text-emerald-700">Recogida en tienda: sin costo de envío. La tienda acordará contigo el horario.</p>}
      <label className="form-label mt-5 block">Observaciones (opcional)<textarea className="form-input" rows={3} maxLength={1000} value={notes} onChange={e=>setNotes(e.target.value)} placeholder="Ej. Horario preferido"/></label></section>
    <p className="flex items-start gap-2 rounded-xl bg-amber-50 p-4 text-sm text-amber-900"><ShieldCheck size={19} className="shrink-0"/> Este paso no procesa pagos. La confirmación y coordinación se realizan con la tienda por WhatsApp.</p>{problem&&<p role="alert" className="rounded-xl bg-red-50 p-4 text-sm text-red-800">{problem}</p>}<button disabled={busy||invalid||!shipping.whatsapp||(method!=='recogida'&&!rate)} className="store-primary w-full disabled:cursor-not-allowed disabled:opacity-50">{busy?'Registrando pedido...':'Registrar pedido y continuar a WhatsApp'}</button></form>
    <aside className="rounded-2xl border bg-white p-6 lg:sticky lg:top-28"><h2 className="font-display text-xl font-bold">Tu pedido</h2><div className="mt-5 space-y-3">{resolved.map(x=><div key={x.variant.id} className="flex justify-between gap-4 border-b border-slate-100 pb-3 text-sm"><span>{x.product.name}<span className="block text-xs text-slate-500">SKU {x.variant.sku} · {x.line.quantity} und.</span></span><strong>{formatCop(x.unitPrice*x.line.quantity)}</strong></div>)}</div><div className="mt-5 space-y-3 text-sm"><div className="flex justify-between"><span>Subtotal</span><span>{formatCop(subtotal)}</span></div><div className="flex justify-between"><span>Envío</span><span>{method==='recogida'?formatCop(0):rate?formatCop(shippingCost):'Pendiente'}</span></div><div className="flex justify-between border-t pt-4 font-bold"><span>Total estimado</span><span className="text-brand">{formatCop(subtotal+shippingCost)}</span></div></div>{invalid&&<p role="alert" className="mt-4 text-xs font-semibold text-red-700">Hay artículos faltantes, agotados o cantidades superiores al inventario. Vuelve al carrito.</p>}</aside></div>}</StoreState>
  </div>
}
