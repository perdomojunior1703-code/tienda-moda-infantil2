import { useMemo } from 'react'
import { ArrowRight, Filter, Search, SlidersHorizontal, X } from 'lucide-react'
import { Link, useSearchParams } from 'react-router-dom'
import { useStore } from '../features/storefront/hooks'
import { ProductCard, StoreState, EmptyProducts } from '../features/storefront/ui'
import { hasDiscount, productVariants } from '../features/storefront/api'
import type { StoreProduct } from '../features/storefront/api'

export function ShopPage() {
  const {data,isLoading,error} = useStore()
  const [params,setParams] = useSearchParams()
  const query = params.get('buscar') || ''
  const category = params.get('categoria') || ''
  const size = params.get('talla') || ''
  const color = params.get('color') || ''
  const order = params.get('orden') || 'recientes'
  const onSale = params.get('oferta') === '1'
  const newOnly = params.get('nuevo') === '1'
  function update(name:string,value:string) {const next = new URLSearchParams(params); value ? next.set(name,value) : next.delete(name); setParams(next)}
  const shown = useMemo(() => {
    if (!data) return []
    const text = query.trim().toLocaleLowerCase('es-CO')
    let products = data.products.filter(p => {
      if (text && ![p.name,p.description ?? '',p.sku ?? ''].some(v=>v.toLocaleLowerCase('es-CO').includes(text))) return false
      if (category && p.category_id !== category) return false
      if (onSale && !hasDiscount(p)) return false
      if (newOnly && !p.is_new) return false
      if ((size || color) && !productVariants(data,p.id).some(v=>(!size||v.size_id===size)&&(!color||v.color_id===color))) return false
      return true
    })
    if (order==='precio-asc') products = [...products].sort((a,b)=>Number(a.sale_price)-Number(b.sale_price))
    if (order==='precio-desc') products = [...products].sort((a,b)=>Number(b.sale_price)-Number(a.sale_price))
    if (order==='nombre') products = [...products].sort((a,b)=>a.name.localeCompare(b.name,'es'))
    return products
  },[data,query,category,size,color,onSale,newOnly,order])
  return <div className="store-shell py-10"><div className="mb-9 rounded-[2rem] bg-[#fff0eb] px-7 py-11 md:px-12"><p className="store-pill">Nuestro catálogo</p><h1 className="mt-4 font-display text-4xl font-extrabold tracking-tight sm:text-5xl">Prendas para cada aventura<span className="text-brand">.</span></h1><p className="mt-3 text-sm leading-7 text-slate-600">Explora las prendas disponibles, sus tallas, colores y precios reales.</p></div>
    <StoreState loading={isLoading} error={error}>{data && <div className="grid gap-8 lg:grid-cols-[255px_1fr]">
      <aside className="h-fit rounded-2xl border border-slate-100 bg-white p-5 lg:sticky lg:top-28"><div className="flex items-center justify-between"><h2 className="flex items-center gap-2 font-display text-base font-bold"><SlidersHorizontal size={18}/> Filtros</h2><button className="text-xs font-bold text-brand hover:underline" onClick={()=>setParams(new URLSearchParams())}>Limpiar</button></div>
        <div className="mt-5 space-y-5"><label className="block text-xs font-bold">Buscar<div className="mt-2 flex items-center gap-2 rounded-xl border border-slate-200 px-3"><Search size={17} className="text-slate-400"/><input className="w-full py-3 text-sm font-normal outline-none" value={query} onChange={e=>update('buscar',e.target.value)} placeholder="Nombre o referencia" /></div></label>
        <FilterSelect label="Categoría" value={category} onChange={v=>update('categoria',v)} options={data.categories.map(c=>({value:c.id,label:c.name}))}/>
        <FilterSelect label="Talla" value={size} onChange={v=>update('talla',v)} options={data.sizes.map(s=>({value:s.id,label:s.label}))}/>
        <FilterSelect label="Color" value={color} onChange={v=>update('color',v)} options={data.colors.map(c=>({value:c.id,label:c.name}))}/>
        <label className="flex items-center gap-3 text-sm"><input type="checkbox" checked={onSale} onChange={e=>update('oferta',e.target.checked?'1':'')} className="accent-[#E53935]"/> Solo ofertas</label>
        <label className="flex items-center gap-3 text-sm"><input type="checkbox" checked={newOnly} onChange={e=>update('nuevo',e.target.checked?'1':'')} className="accent-[#E53935]"/> Novedades</label></div>
      </aside>
      <div className="min-w-0"><div className="mb-6 flex flex-wrap items-center justify-between gap-4"><p className="text-sm text-slate-500"><b className="text-slate-800">{shown.length}</b> {shown.length===1?'producto':'productos'}</p><div className="flex items-center gap-3"><Filter size={16} className="text-slate-400"/><label className="text-xs font-bold" htmlFor="order">Ordenar</label><select id="order" className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm" value={order} onChange={e=>update('orden',e.target.value)}><option value="recientes">Más recientes</option><option value="precio-asc">Menor precio</option><option value="precio-desc">Mayor precio</option><option value="nombre">Nombre A–Z</option></select></div></div>
      {shown.length ? <div className="grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-3">{shown.map((p:StoreProduct)=><ProductCard key={p.id} data={data} product={p}/>)}</div> : <EmptyProducts title="No encontramos prendas con esos filtros" detail="Prueba otra talla, color o categoría. Si aún no hay prendas, puedes registrarlas desde el panel."/>}
      {(category||size||color||query||onSale||newOnly) && <button className="mt-6 inline-flex items-center gap-2 text-sm font-bold text-brand" onClick={()=>setParams(new URLSearchParams())}><X size={17}/> Quitar filtros</button>}
      <div className="mt-14 rounded-2xl border border-[#f8e8e5] bg-[#fffaf8] px-6 py-8 text-center"><p className="font-display text-lg font-bold">¿Quieres ver más opciones?</p><p className="mt-2 text-sm text-slate-500">El catálogo se actualiza cuando agregas productos desde el panel.</p><Link to="/" className="mt-4 inline-flex items-center gap-2 text-sm font-bold text-brand">Volver al inicio <ArrowRight size={16}/></Link></div>
      </div>
    </div>}</StoreState>
  </div>
}
function FilterSelect({label,value,onChange,options}:{label:string;value:string;onChange:(v:string)=>void;options:{value:string;label:string}[]}) {return <label className="block text-xs font-bold">{label}<select className="mt-2 w-full rounded-xl border border-slate-200 bg-white px-3 py-3 text-sm font-normal" value={value} onChange={e=>onChange(e.target.value)}><option value="">Todas</option>{options.map(o=><option key={o.value} value={o.value}>{o.label}</option>)}</select></label>}
