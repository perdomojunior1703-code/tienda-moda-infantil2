import { useState, type FormEvent } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'

export function ForgotPasswordPage() {
  const [email, setEmail] = useState('')
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')
  async function handleSubmit(event: FormEvent) {
    event.preventDefault()
    if (!supabase) return setError('Primero configura Supabase en .env.')
    setBusy(true); setError('')
    const { error: authError } = await supabase.auth.resetPasswordForEmail(email.trim(), { redirectTo: `${window.location.origin}/restablecer` })
    setBusy(false)
    if (authError) setError(authError.message)
    else setMessage('Si existe una cuenta con ese correo, recibirá las instrucciones de recuperación.')
  }
  return <>
    <h1 className="font-display text-2xl font-bold">Recuperar contraseña</h1>
    <p className="mb-7 mt-2 text-sm text-slate-500">Te enviaremos un enlace para crear una nueva contraseña.</p>
    <form onSubmit={handleSubmit} className="space-y-5">
      <label className="form-label">Correo electrónico<input className="form-input" type="email" autoComplete="email" required value={email} onChange={e => setEmail(e.target.value)} /></label>
      {error && <p className="rounded-xl bg-red-50 p-3 text-sm text-red-700" role="alert">{error}</p>}
      {message && <p className="rounded-xl bg-emerald-50 p-3 text-sm text-emerald-800" role="status">{message}</p>}
      <button className="btn-primary" disabled={busy}> {busy ? 'Enviando...' : 'Enviar instrucciones'} </button>
    </form>
    <p className="mt-6 text-center text-sm"><Link to="/ingresar" className="text-brand hover:underline">Volver al inicio de sesión</Link></p>
  </>
}
