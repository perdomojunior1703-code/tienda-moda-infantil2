import { Heart } from 'lucide-react'
import { Link } from 'react-router-dom'
import { useStore } from '../features/storefront/hooks'
import { useCart } from '../features/storefront/cart'
import { ProductCard, StoreState } from '../features/storefront/ui'
export function FavoritesPage() {
  const {data,isLoading,error} = useStore()
  const {favoriteIds} = useCart()
  const products = data?.products.filter(p=>favoriteIds.includes(p.id))??[]
  return <div className="store-shell py-12"><span className="store-pill">Mis favoritos</span><h1 className="store-section-heading mt-4">Prendas que te encantan</h1><p className="mt-3 text-sm text-slate-500">Tus favoritos se guardan en este navegador.</p><StoreState loading={isLoading} error={error}>{data && (products.length ? <div className="mt-9 grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">{products.map(p=><ProductCard key={p.id} data={data} product={p}/>)}</div>:<div className="mt-10 rounded-3xl border border-dashed border-slate-200 bg-white px-6 py-20 text-center"><Heart size={46} className="mx-auto text-slate-300"/><h2 className="mt-4 font-display text-xl font-bold">Todavía no tienes favoritos</h2><p className="mt-2 text-sm text-slate-500">Presiona el corazón de cualquier producto que te guste.</p><Link to="/catalogo" className="store-primary mt-6">Explorar prendas</Link></div>)}</StoreState></div>
}
