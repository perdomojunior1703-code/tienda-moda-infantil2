import { useEffect, useState } from 'react'
import { ShieldCheck, UserRoundCog } from 'lucide-react'
import { supabase } from '../lib/supabase'
import { ROLE_NAMES, type RoleCode } from '../lib/access'

type Staff = { user_id: string, email: string, full_name: string, roles: RoleCode[] }
type StaffRole = Exclude<RoleCode, 'cliente'>
const ROLES: StaffRole[] = ['administrador','supervisor','cajero','inventario']

export function StaffPage() {
  const [email, setEmail] = useState('')
  const [role, setRole] = useState<StaffRole>('cajero')
  const [staff, setStaff] = useState<Staff[]>([])
  const [busy, setBusy] = useState(false)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [message, setMessage] = useState('')

  async function loadStaff() {
    if (!supabase) return
    setLoading(true)
    const { data, error: readError } = await supabase.rpc('admin_list_staff')
    setLoading(false)
    if (readError) setError(readError.message)
    else setStaff(Array.isArray(data) ? data as Staff[] : [])
  }
  useEffect(() => { void loadStaff() }, [])

  async function changeRole(grant_role: boolean) {
    if (!supabase || !email.trim()) return
    setBusy(true); setError(''); setMessage('')
    const { error: writeError } = await supabase.rpc('admin_assign_role', {
      target_email: email.trim(), requested_role: role, grant_role,
    })
    if (writeError) setError(writeError.message)
    else {
      setMessage(grant_role ? 'Rol asignado correctamente.' : 'Rol retirado correctamente.')
      await loadStaff()
    }
    setBusy(false)
  }

  return <>
    <p className="text-sm font-semibold text-brand">Seguridad · Fase 1</p>
    <h1 className="mt-1 font-display text-3xl font-bold">Roles de empleados</h1>
    <p className="mt-3 max-w-2xl text-sm leading-7 text-slate-500">Asigna o retira permisos de personal que ya tenga cuenta. Todo cambio se valida en PostgreSQL y se registra en auditoría. Los usuarios conservan su rol base de cliente.</p>
    <section className="panel-card mt-8 max-w-2xl">
      <div className="mb-5 flex items-center gap-2 font-display text-lg font-bold"><UserRoundCog className="text-brand" size={22}/> Configurar rol</div>
      <form onSubmit={event => { event.preventDefault(); void changeRole(true) }} className="space-y-4">
        <label className="form-label">Correo del empleado registrado<input type="email" className="form-input" value={email} required placeholder="empleado@ejemplo.com" onChange={event => setEmail(event.target.value)}/></label>
        <label className="form-label">Rol<select className="form-input" value={role} onChange={event => setRole(event.target.value as StaffRole)}>
          {ROLES.map(value => <option key={value} value={value}>{ROLE_NAMES[value]}</option>)}
        </select></label>
        {error && <div role="alert" className="rounded-xl bg-red-50 p-3 text-sm text-red-700">{error}</div>}
        {message && <div role="status" className="rounded-xl bg-emerald-50 p-3 text-sm text-emerald-800">{message}</div>}
        <div className="flex flex-wrap gap-3"><button disabled={busy} type="submit" className="btn-primary !w-auto">{busy ? 'Procesando...' : 'Asignar rol'}</button>
          <button disabled={busy} type="button" className="btn-ghost" onClick={() => void changeRole(false)}>Retirar rol</button></div>
      </form>
      <p className="mt-4 text-xs leading-6 text-slate-500">No puedes modificar tus propios roles. El empleado debe actualizar sus permisos en «Mi cuenta» para ver el cambio inmediatamente.</p>
    </section>
    <section className="mt-9"><h2 className="mb-4 font-display text-xl font-bold">Personal con roles asignados</h2>
      {loading ? <p className="text-sm text-slate-500">Consultando empleados...</p> : staff.length === 0 ? <div className="panel-card text-sm text-slate-500">No hay empleados con roles adicionales.</div> :
        <div className="overflow-x-auto rounded-2xl border border-slate-100 bg-white shadow-sm"><table className="w-full min-w-xl text-left text-sm"><thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500"><tr><th className="px-5 py-4">Empleado</th><th className="px-5 py-4">Correo</th><th className="px-5 py-4">Roles</th></tr></thead><tbody>{staff.map(person => <tr key={person.user_id} className="border-t border-slate-100"><td className="px-5 py-4 font-semibold">{person.full_name || 'Sin nombre'}</td><td className="px-5 py-4 text-slate-600">{person.email}</td><td className="px-5 py-4"><div className="flex flex-wrap gap-2">{person.roles.map(staffRole => <span key={staffRole} className="rounded-full bg-brand-pale px-2 py-1 text-xs font-semibold text-brand-dark"><ShieldCheck size={12} className="mr-1 inline"/>{ROLE_NAMES[staffRole]}</span>)}</div></td></tr>)}</tbody></table></div>}
    </section>
  </>
}
