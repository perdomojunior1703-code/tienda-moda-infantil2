import { useQuery } from '@tanstack/react-query'
import { ArrowLeft, ClipboardList, MapPin, PackageCheck, RefreshCcw } from 'lucide-react'
import { Link, useParams } from 'react-router-dom'
import { OrderTimeline } from '../features/orders/OrderTimeline'
import { deliveryLabel, getMyOrders, orderLabel } from '../features/orders/api'
import { formatCop } from '../features/storefront/api'

/** Orders are obtained exclusively through orders_list('mine') - no direct table access. */
export function OrderTrackingPage() {
  const { number } = useParams<{ number: string }>()
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ['orders-mine'], queryFn: getMyOrders,
    refetchInterval: 60_000,
  })
  const order = data?.find(o => o.number === number)

  return <div className="store-shell py-12">
    <Link to="/mis-pedidos" className="inline-flex items-center gap-2 text-sm font-semibold text-slate-600 hover:text-brand"><ArrowLeft size={17}/> Mis pedidos</Link>
    <div className="mt-6 flex flex-wrap items-end justify-between gap-3">
      <div><span className="store-pill">Seguimiento de compra</span><h1 className="store-section-heading mt-3">Estado de tu pedido</h1></div>
      <button type="button" className="store-outline" onClick={() => void refetch()}><RefreshCcw size={17}/> Actualizar estado</button>
    </div>
    {isLoading && <p className="mt-8" role="status">Consultando tu pedido…</p>}
    {error && <p className="mt-8 rounded-xl bg-red-50 p-5 text-red-700" role="alert">{error.message}</p>}
    {!isLoading && !error && !order && <div className="mt-8 rounded-2xl border bg-white p-8"><ClipboardList size={38} className="text-slate-300"/><h2 className="mt-3 text-lg font-bold">Pedido no encontrado</h2><p className="mt-2 text-sm text-slate-600">Comprueba la referencia y que hayas iniciado sesión con la cuenta que realizó el pedido.</p><Link className="store-primary mt-5" to="/mis-pedidos">Ver mis pedidos</Link></div>}
    {order && <div className="mt-8 space-y-6">
      <section className="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm">
        <div className="flex flex-wrap items-start justify-between gap-3"><div><h2 className="font-display text-2xl font-bold">{order.number}</h2><p className="mt-1 text-sm text-slate-500">Registrado el {new Date(order.created_at).toLocaleString('es-CO')}</p></div><div className="text-right"><p className="font-bold text-brand">{orderLabel[order.status]}</p><p className="mt-1 text-xs text-slate-500">Pago: {order.payment}</p></div></div>
        <OrderTimeline order={order}/>
      </section>
      <div className="grid gap-6 md:grid-cols-2">
        <section className="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm"><h3 className="flex items-center gap-2 font-display text-xl font-bold"><PackageCheck size={20}/> Resumen de compra</h3>
          <ul className="mt-5 space-y-3">{order.items.map((item,index) => <li key={`${item.sku || index}-${index}`} className="flex justify-between gap-3 border-b border-slate-100 pb-3 text-sm"><span><strong>{item.name}</strong><span className="mt-1 block text-xs text-slate-500">{item.size} / {item.color} · {item.quantity} und.</span></span><span className="font-semibold">{formatCop(item.total)}</span></li>)}</ul>
          <dl className="mt-4 space-y-2 text-sm"><div className="flex justify-between"><dt>Subtotal</dt><dd>{formatCop(order.subtotal)}</dd></div><div className="flex justify-between"><dt>Envío</dt><dd>{formatCop(order.shipping)}</dd></div><div className="flex justify-between border-t pt-3 font-bold"><dt>Total del pedido</dt><dd className="text-brand">{formatCop(order.total)}</dd></div></dl>
        </section>
        <section className="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm"><h3 className="flex items-center gap-2 font-display text-xl font-bold"><MapPin size={20}/> Entrega y guía</h3><p className="mt-4 font-semibold">{deliveryLabel[order.method]}</p>{order.address&&<p className="mt-2 text-sm text-slate-600">{order.address.address}, {order.address.city}, {order.address.department}</p>}
          {order.tracking_number ? <p className="mt-4 rounded-xl bg-emerald-50 p-4 text-sm text-emerald-800"><strong>Guía:</strong> {order.tracking_number} {order.carrier && `· ${order.carrier}`}</p> : <p className="mt-4 rounded-xl bg-slate-50 p-4 text-sm text-slate-600">{order.method === 'recogida' ? 'La tienda te informará cuándo puedes recoger el pedido.' : 'La tienda añadirá la transportadora y la guía cuando realice el envío.'}</p>}
          {order.notes && <p className="mt-4 text-xs text-slate-500">Observaciones: {order.notes}</p>}
        </section>
      </div>
      <section className="rounded-2xl border border-slate-100 bg-white p-6 shadow-sm"><h3 className="font-display text-xl font-bold">Historial de seguimiento</h3>
        {order.history.length ? <ol className="mt-5 space-y-4 border-l-2 border-red-100 pl-5">{order.history.map((item,index) => <li key={index} className="relative"><span className="absolute -left-[27px] top-1 size-3 rounded-full bg-brand"/><p className="font-semibold">{orderLabel[item.status]}</p><p className="mt-1 text-xs text-slate-500">{new Date(item.at).toLocaleString('es-CO')}</p>{item.reason&&<p className="mt-1 text-sm text-slate-600">{item.reason}</p>}</li>)}</ol> : <p className="mt-4 text-sm text-slate-500">Sin cambios registrados.</p>}
      </section>
    </div>}
  </div>
}
