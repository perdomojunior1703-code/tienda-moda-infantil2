import { useEffect, useMemo, useState } from 'react'
import { ArrowLeft, Check, ChevronLeft, ChevronRight, Heart, Minus, Plus, ShoppingBag, Truck } from 'lucide-react'
import { Link, useParams } from 'react-router-dom'
import { useStore } from '../features/storefront/hooks'
import { StoreState, ProductVisual, ProductCard } from '../features/storefront/ui'
import { formatCop, hasDiscount, productPhoto, productPhotos, productVariants } from '../features/storefront/api'
import { useCart } from '../features/storefront/cart'

export function ProductDetailPage() {
  const {slug} = useParams()
  const {data,isLoading,error} = useStore()
  const {addLine,toggleFavorite,favoriteIds} = useCart()
  const [sizeId,setSizeId] = useState('')
  const [colorId,setColorId] = useState('')
  const [qty,setQty] = useState(1)
  const [imageIndex,setImageIndex] = useState(0)
  const [added,setAdded] = useState(false)
  useEffect(()=>{setSizeId('');setColorId('');setQty(1);setImageIndex(0);setAdded(false)},[slug])
  const product = data?.products.find(p=>p.slug===slug)
  const photos = data && product ? productPhotos(data,product.id):[]
  const variants = data && product ? productVariants(data,product.id):[]
  const availableSizes = useMemo(()=> data?.sizes.filter(s=>variants.some(v=>v.size_id===s.id)) ?? [],[data,variants])
  const availableColors = useMemo(()=> data?.colors.filter(c=>variants.some(v=>v.size_id===sizeId && v.color_id===c.id)) ?? [],[data,variants,sizeId])
  const variant = variants.find(v=>v.size_id===sizeId && v.color_id===colorId)
  const price = Number(variant?.price_override ?? product?.sale_price ?? 0)
  const liked = product ? favoriteIds.includes(product.id) : false
  const remaining = Math.max(0,variant?.quantity ?? 0)
  const related = data?.products.filter(p=>p.id!==product?.id && p.category_id===product?.category_id).slice(0,4)??[]
  function add() {if (!variant || qty > remaining || remaining <= 0) return;addLine(variant,qty);setAdded(true)}
  return <StoreState loading={isLoading} error={error}>{data && product ? <div className="store-shell py-8">
    <div className="mb-8 flex flex-wrap items-center gap-2 text-xs text-slate-500"><Link to="/" className="hover:text-brand">Inicio</Link><ChevronRight size={14}/><Link to="/catalogo" className="hover:text-brand">Catálogo</Link><ChevronRight size={14}/><span className="font-bold text-ink">{product.name}</span></div>
    <div className="grid gap-10 lg:grid-cols-2 lg:gap-16"><div><div className="group relative aspect-[4/4.5] overflow-hidden rounded-[2rem] bg-[#fff1ef]">{photos.length ? <img className="h-full w-full object-cover" src={productPhoto(photos[imageIndex]?.storage_path ?? photos[0].storage_path)} alt={photos[imageIndex]?.alt_text ?? product.name}/> : <ProductVisual data={data} product={product} large/>}{photos.length>1 && <><button type="button" aria-label="Imagen anterior" onClick={()=>setImageIndex(i=>(i+photos.length-1)%photos.length)} className="absolute left-3 top-1/2 rounded-full bg-white p-3 shadow-md"><ChevronLeft/></button><button type="button" aria-label="Imagen siguiente" onClick={()=>setImageIndex(i=>(i+1)%photos.length)} className="absolute right-3 top-1/2 rounded-full bg-white p-3 shadow-md"><ChevronRight/></button></>}</div>{photos.length>1 && <div className="mt-4 flex gap-3 overflow-x-auto">{photos.map((img,i)=><button key={img.id} type="button" onClick={()=>setImageIndex(i)} className={`h-20 w-20 shrink-0 overflow-hidden rounded-xl border-2 ${i===imageIndex?'border-brand':'border-transparent'}`} aria-label={`Ver imagen ${i+1}`}><img src={productPhoto(img.storage_path)} className="h-full w-full object-cover" alt={img.alt_text ?? product.name}/></button>)}</div>}</div>
      <div className="py-3"><Link className="text-sm font-bold text-brand hover:underline" to={product.category_id?`/catalogo?categoria=${product.category_id}`:'/catalogo'}>{data.categories.find(c=>c.id===product.category_id)?.name ?? 'Moda Infantil'}</Link><h1 className="mt-4 font-display text-3xl font-extrabold leading-tight sm:text-4xl">{product.name}</h1><div className="mt-4 flex flex-wrap items-center gap-3">{hasDiscount(product) && <span className="rounded-full bg-brand-pale px-3 py-1.5 text-xs font-bold text-brand">Precio especial</span>}{product.is_new && <span className="rounded-full bg-amber-100 px-3 py-1.5 text-xs font-bold text-amber-900">Novedad</span>}</div>
        <div className="mt-6 flex items-end gap-4"><strong className="font-display text-3xl text-brand">{formatCop(price)}</strong>{hasDiscount(product) && !variant?.price_override && <s className="pb-1 text-base text-slate-400">{formatCop(product.previous_price)}</s>}</div>
        <p className="mt-6 whitespace-pre-line text-sm leading-8 text-slate-600">{product.description || 'Una prenda especial para acompañar sus días con estilo y comodidad.'}</p>
        <div className="my-8 h-px bg-slate-100"/>
        {variants.length ? <><div><p className="mb-3 text-sm font-bold">Selecciona la talla</p><div className="flex flex-wrap gap-2">{availableSizes.map(s=><button type="button" key={s.id} onClick={()=>{setSizeId(s.id);setColorId('');setQty(1);setAdded(false)}} className={`min-w-14 rounded-xl border px-4 py-3 text-sm font-bold transition ${sizeId===s.id?'border-brand bg-brand text-white':'border-slate-200 bg-white hover:border-brand'}`}>{s.label}</button>)}</div></div>
        <div className="mt-6"><p className="mb-3 text-sm font-bold">Selecciona el color</p><div className="flex flex-wrap gap-2">{availableColors.length?availableColors.map(c=><button type="button" key={c.id} onClick={()=>{setColorId(c.id);setQty(1);setAdded(false)}} className={`flex items-center gap-2 rounded-xl border px-4 py-2.5 text-sm font-semibold transition ${colorId===c.id?'border-brand bg-red-50 text-brand':'border-slate-200 bg-white hover:border-brand'}`}><span style={{background:c.hex_code??'#ccc'}} className="h-4 w-4 rounded-full border border-slate-200"/>{c.name}</button>):<p className="text-sm text-slate-400">Selecciona primero una talla.</p>}</div></div>
        <div className="mt-6 text-sm">{variant ? remaining>0 ? <p className="font-semibold text-emerald-700"><Check size={16} className="inline"/> Disponible: {remaining} {remaining===1?'unidad':'unidades'}</p> : <p className="font-semibold text-red-700">Esta combinación está agotada.</p> : <p className="text-slate-500">Elige talla y color para verificar existencias.</p>}</div>
        <div className="mt-6 flex flex-wrap gap-3"><div className="flex items-center rounded-full border border-slate-200 bg-white"><button type="button" disabled={qty<=1} className="p-3 disabled:opacity-40" onClick={()=>setQty(n=>Math.max(1,n-1))} aria-label="Disminuir cantidad"><Minus size={18}/></button><span className="min-w-8 text-center text-sm font-bold">{qty}</span><button type="button" className="p-3 disabled:opacity-40" disabled={!variant||qty>=Math.min(100,remaining)} onClick={()=>setQty(n=>n+1)} aria-label="Aumentar cantidad"><Plus size={18}/></button></div><button type="button" disabled={!variant||remaining<=0||qty>remaining} onClick={add} className="store-primary flex-1 disabled:cursor-not-allowed disabled:opacity-50"><ShoppingBag size={19}/>{added?'Añadido al carrito':'Agregar al carrito'}</button><button type="button" onClick={()=>toggleFavorite(product.id)} aria-label={liked?'Quitar de favoritos':'Añadir a favoritos'} className={`rounded-full border px-4 ${liked?'border-red-200 bg-red-50 text-brand':'border-slate-200'}`}><Heart fill={liked?'currentColor':'none'} size={20}/></button></div>
        {added && <p role="status" className="mt-3 text-sm font-semibold text-emerald-700">Producto agregado. <Link className="underline" to="/carrito">Ver mi carrito</Link></p>}
        </> : <div className="rounded-2xl border border-amber-100 bg-amber-50 p-4 text-sm text-amber-900">Este producto aún no tiene variantes disponibles. El administrador puede configurar tallas y colores desde el panel.</div>}
        <div className="mt-8 flex gap-3 rounded-2xl bg-slate-50 p-4 text-xs leading-6 text-slate-600"><Truck size={22} className="shrink-0 text-brand"/><span>Consulta las modalidades y tarifas de envío con la tienda. Los pedidos y pagos en línea se habilitarán en una fase posterior.</span></div>
      </div></div>
    {related.length>0 && <section className="mt-20"><h2 className="store-section-heading">También te puede gustar</h2><div className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-4">{related.map(p=><ProductCard key={p.id} product={p} data={data}/>)}</div></section>}
  </div> : <div className="store-shell py-24 text-center"><h1 className="font-display text-2xl font-bold">Producto no disponible</h1><p className="mt-3 text-sm text-slate-500">Puede estar oculto, archivado o no existir.</p><Link to="/catalogo" className="store-primary mt-6"><ArrowLeft size={17}/> Volver al catálogo</Link></div>}</StoreState>
}
