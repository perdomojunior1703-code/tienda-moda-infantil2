import { useState, type FormEvent } from 'react'
import { Palette, Ruler } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import { mutateCatalog } from '../features/catalog/api'
import { useCatalog, useRefreshCatalog } from '../features/catalog/hooks'
import { CatalogStatus, Notice, PageHeading } from '../features/catalog/components'

export function OptionsPage() {
  const { access } = useAuth()
  const canEdit = access.permissions.includes('catalog.manage')
  const { data, isLoading, error } = useCatalog()
  const refresh = useRefreshCatalog()
  const [size, setSize] = useState('')
  const [color, setColor] = useState('')
  const [hex, setHex] = useState('#E53935')
  const [busy, setBusy] = useState(false)
  const [problem, setProblem] = useState('')
  const [message, setMessage] = useState('')
  async function save(event: FormEvent, kind: 'size' | 'color') {
    event.preventDefault(); setBusy(true); setProblem(''); setMessage('')
    try {
      if (kind === 'size') {
        await mutateCatalog('catalog_save_size', { p_id: null, p_label: size, p_sort_order: data?.sizes.length ?? 0 }); setSize('')
      } else {
        await mutateCatalog('catalog_save_color', { p_id: null, p_name: color, p_hex_code: hex }); setColor('')
      }
      await refresh(); setMessage(kind === 'size' ? 'Talla registrada.' : 'Color registrado.')
    } catch (err) { setProblem(err instanceof Error ? err.message : 'Error al guardar') }
    finally { setBusy(false) }
  }
  return <>
    <PageHeading eyebrow="Catálogo · Fase 2" title="Tallas y colores" description="Las opciones se comparten entre todos los productos. Ya se incluyen tallas y colores habituales; puedes agregar otros."/>
    <Notice error={problem} success={message}/>
    <CatalogStatus loading={isLoading} error={error}>
      <div className="grid gap-6 lg:grid-cols-2">
        <section className="panel-card"><h2 className="mb-5 flex items-center gap-2 font-display text-xl font-bold"><Ruler className="text-brand"/> Tallas</h2>
          <div className="flex flex-wrap gap-2">{data?.sizes.map(item => <span key={item.id} className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-2 text-sm font-semibold">{item.label}</span>)}</div>
          {canEdit && <form className="mt-6 flex flex-wrap items-end gap-2" onSubmit={e => void save(e,'size')}><label className="form-label flex-1">Nueva talla<input className="form-input" maxLength={40} required value={size} onChange={e => setSize(e.target.value)} placeholder="Ej. 18M"/></label><button className="btn-primary !w-auto" disabled={busy}>Agregar</button></form>}
        </section>
        <section className="panel-card"><h2 className="mb-5 flex items-center gap-2 font-display text-xl font-bold"><Palette className="text-brand"/> Colores</h2>
          <div className="flex flex-wrap gap-2">{data?.colors.map(item => <span key={item.id} className="flex items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm font-semibold"><span className="h-4 w-4 rounded-full border border-slate-200" style={{ backgroundColor: item.hex_code ?? '#fff' }}/>{item.name}</span>)}</div>
          {canEdit && <form className="mt-6 flex flex-wrap items-end gap-2" onSubmit={e => void save(e,'color')}><label className="form-label flex-1">Nuevo color<input className="form-input" required maxLength={70} value={color} onChange={e => setColor(e.target.value)} placeholder="Ej. Lila"/></label><label className="form-label">Muestra<input type="color" className="form-input h-[46px] w-20 p-2" value={hex} onChange={e => setHex(e.target.value)}/></label><button className="btn-primary !w-auto" disabled={busy}>Agregar</button></form>}
        </section>
      </div>
    </CatalogStatus>
  </>
}
