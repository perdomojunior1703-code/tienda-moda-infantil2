import { ArrowRight, Baby, Heart, Package, ShieldCheck, ShoppingBag, Sparkles, Truck } from 'lucide-react'
import { Link } from 'react-router-dom'
import { useStore } from '../features/storefront/hooks'
import { StoreState, ProductCard, EmptyProducts } from '../features/storefront/ui'
import { bannerPhoto, categoryPhoto, hasDiscount, productPhoto, productPhotos, safeSiteLink } from '../features/storefront/api'
import type { StoreData, StoreProduct } from '../features/storefront/api'

export function HomePage() {
  const {data,isLoading,error} = useStore()
  return <StoreState loading={isLoading} error={error}>{data && <HomeContent data={data}/>}</StoreState>
}
function HomeContent({data}:{data:StoreData}) {
  const banner = data.banners[0]
  const featured = data.products.filter(p => p.is_featured).slice(0,4)
  const latest = data.products.filter(p => p.is_new).slice(0,4)
  const discounts = data.products.filter(hasDiscount).slice(0,4)
  const bestAvailable = featured.length ? featured : data.products.slice(0,4)
  const heroProduct = data.products.find(p => productPhotos(data,p.id).length > 0)
  const heroPic = heroProduct ? productPhoto(productPhotos(data,heroProduct.id)[0].storage_path) : ''
  const heroLink = safeSiteLink(banner?.target_url) ?? '/catalogo'
  const bannerImg = banner ? bannerPhoto(banner.image_path) : ''
  return <>
    <section className="store-shell py-5 sm:py-7">
      <div className="relative grid min-h-[470px] overflow-hidden rounded-[2.3rem] bg-[#fceae7] lg:grid-cols-[1.05fr_.95fr]">
        <div className="relative z-10 flex flex-col items-start justify-center px-7 py-12 sm:px-12 lg:py-20 xl:px-20">
          <span className="store-pill"><Sparkles size={16}/> La alegría de vestirlos</span>
          <h1 className="mt-7 max-w-xl font-display text-4xl font-extrabold leading-[1.17] tracking-tight text-[#2d2527] sm:text-5xl xl:text-[3.65rem]">{banner?.title || <>Pequeños estilos,<br/><span className="text-brand">grandes sonrisas.</span></>}</h1>
          <p className="mt-6 max-w-md text-[15px] leading-8 text-[#685e62]">{banner?.description || 'Prendas suaves, cómodas y llenas de encanto para acompañar sus mejores aventuras.'}</p>
          {heroLink.startsWith('/') ? <Link to={heroLink} className="store-primary mt-8">{banner?.button_text || 'Descubrir colección'}<ArrowRight size={18}/></Link> : <a className="store-primary mt-8" href={heroLink} target="_blank" rel="noopener noreferrer">{banner?.button_text || 'Ver colección'}<ArrowRight size={18}/></a>}
          <div className="mt-10 flex flex-wrap gap-5 text-xs font-semibold text-[#706466]"><span className="flex items-center gap-2"><Heart size={16} className="text-brand"/> Pensado para su comodidad</span><span className="flex items-center gap-2"><ShieldCheck size={16} className="text-brand"/> Compra con atención personalizada</span></div>
        </div>
        <div className="relative flex min-h-[300px] items-center justify-center overflow-hidden bg-[#f6c9c2] lg:min-h-0">
          {bannerImg ? <img src={bannerImg} alt={banner?.title ?? 'Promoción de la tienda'} className="absolute inset-0 h-full w-full object-cover"/> : heroPic ? <img src={heroPic} alt={`Colección: ${heroProduct?.name}`} className="absolute inset-0 h-full w-full object-cover"/> : <div className="absolute inset-0 bg-[radial-gradient(circle_at_60%_40%,#ffefe5_0%,#ffd8cf_45%,#f2b6b1_100%)]"/>}
          {!bannerImg && !heroPic && <div className="relative flex h-64 w-64 items-center justify-center rounded-[45%] border-[12px] border-white/50 bg-white/40 shadow-2xl sm:h-80 sm:w-80"><Baby size={142} strokeWidth={.85} className="text-[#bc685c]"/><div className="absolute -right-6 -top-6 rotate-12 rounded-3xl bg-white px-5 py-3 font-display text-xl font-extrabold text-brand shadow-lg">♥</div><div className="absolute -bottom-5 -left-12 rotate-[-10deg] rounded-2xl bg-white px-5 py-3 text-sm font-bold text-[#8b4e49] shadow-lg">Mini moda</div></div>}
        </div>
      </div>
    </section>
    {data.banners.length>1 && <section className="store-shell mt-3 grid gap-4 md:grid-cols-2">{data.banners.slice(1,3).map(b=>{
      const link = safeSiteLink(b.target_url) ?? '/catalogo'
      const content = <><img className="absolute inset-0 h-full w-full object-cover" src={bannerPhoto(b.image_path)} alt="" loading="lazy"/><div className="absolute inset-0 bg-gradient-to-r from-black/75 via-black/45 to-transparent"/><div className="relative z-10 max-w-xs"><h2 className="font-display text-2xl font-bold">{b.title}</h2>{b.description && <p className="mt-2 line-clamp-2 text-sm text-white/85">{b.description}</p>}<span className="mt-4 inline-flex items-center gap-2 text-sm font-bold">{b.button_text||'Ver más'} <ArrowRight size={16}/></span></div></>
      return link.startsWith('/') ? <Link key={b.id} to={link} className="relative flex min-h-48 items-center overflow-hidden rounded-[1.5rem] p-8 text-white">{content}</Link> : <a key={b.id} href={link} target="_blank" rel="noreferrer" className="relative flex min-h-48 items-center overflow-hidden rounded-[1.5rem] p-8 text-white">{content}</a>
    })}</section>}
    <section className="store-shell py-8"><div className="grid gap-4 md:grid-cols-3"><Benefit icon={Package} title="Variedad de tallas" text="Encuentra la talla y el color de cada prenda."/><Benefit icon={Heart} title="Hecho con cariño" text="Moda pensada para cada etapa de la infancia."/><Benefit icon={Truck} title="Entrega a tu medida" text={data.settings?.shipping_information || 'Consulta en tienda las opciones de entrega disponibles.'}/></div></section>
    <section className="store-shell py-12"><div className="mb-8 flex flex-wrap items-end justify-between gap-4"><div><span className="store-pill">Explora a tu manera</span><h2 className="store-section-heading mt-3">Un mundo para cada peque</h2><p className="mt-3 text-sm text-slate-500">Descubre nuestras categorías de ropa infantil.</p></div><Link to="/catalogo" className="font-bold text-brand hover:underline">Ver colección <ArrowRight className="inline" size={17}/></Link></div>
      {data.categories.length ? <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-5">{data.categories.slice(0,5).map((cat,i)=><Link key={cat.id} to={`/catalogo?categoria=${cat.id}`} className="group overflow-hidden rounded-[1.6rem] border border-slate-100 bg-white p-2 text-center shadow-sm transition hover:-translate-y-1 hover:shadow-md"><div className={`flex aspect-[4/3.8] items-center justify-center overflow-hidden rounded-[1.2rem] ${i%3===0?'bg-[#ffe7e0]':i%3===1?'bg-[#fff0dd]':'bg-[#e7eef5]'}`}>{cat.image_path?<img className="h-full w-full object-cover transition group-hover:scale-105" src={categoryPhoto(cat.image_path)} alt={cat.name} loading="lazy"/>:<ShoppingBag size={64} strokeWidth={1.1} className="text-[#a58381]"/>}</div><h3 className="px-2 py-4 font-display text-sm font-bold group-hover:text-brand">{cat.name}</h3></Link>)}</div> : <EmptyProducts title="Pronto habrá categorías"/>}
    </section>
    <ProductSection title="Elegidos con cariño" subtitle="Productos destacados" data={data} products={bestAvailable}/>
    {discounts.length>0 && <section className="my-12 bg-[#fff2ef] py-16"><ProductSection title="Ofertas bonitas" subtitle="Precios especiales" data={data} products={discounts} compact /></section>}
    {latest.length>0 && <ProductSection title="Recién llegados" subtitle="Novedades" data={data} products={latest}/>}
    <section className="store-shell mt-12"><div className="relative flex flex-col items-start justify-between gap-7 overflow-hidden rounded-[2rem] bg-[#322e32] px-9 py-12 text-white md:flex-row md:items-center md:px-16"><div><p className="text-xs font-bold uppercase tracking-[.25em] text-[#f9c9c1]">Tu tienda infantil</p><h2 className="mt-4 max-w-xl font-display text-3xl font-bold sm:text-4xl">Ropa linda para vivir grandes aventuras.</h2><p className="mt-3 max-w-lg text-sm leading-7 text-white/70">Descubre todas las prendas disponibles, sus colores y tallas.</p></div><Link to="/catalogo" className="store-primary shrink-0">Explorar el catálogo <ArrowRight size={19}/></Link><span className="pointer-events-none absolute -bottom-20 right-1/4 text-[16rem] text-white/5">♥</span></div></section>
  </>
}
function Benefit({icon:Icon,title,text}:{icon:typeof Package;title:string;text:string}) {return <div className="flex items-center gap-4 rounded-2xl border border-[#f2e8e5] bg-white p-5"><span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-[#fff0ed] text-brand"><Icon size={23}/></span><div><h3 className="font-display text-sm font-bold">{title}</h3><p className="mt-1 text-xs leading-5 text-slate-500">{text}</p></div></div>}
function ProductSection({title,subtitle,products,data,compact=false}:{title:string;subtitle:string;products:StoreProduct[];data:StoreData;compact?:boolean}) {return <section className={`store-shell ${compact?'':'py-12'}`}><div className="mb-8 flex flex-wrap items-end justify-between gap-4"><div><span className="store-pill">{subtitle}</span><h2 className="store-section-heading mt-3">{title}</h2></div><Link to="/catalogo" className="text-sm font-bold text-brand hover:underline">Ver todos <ArrowRight size={17} className="inline"/></Link></div>{products.length ? <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">{products.map(p=><ProductCard key={p.id} data={data} product={p}/>)}</div> : <EmptyProducts/>}</section>}
