import { Link } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { loadCatalog } from '../features/catalog/api'
import { Boxes, ClipboardCheck, Image, LockKeyhole, ShoppingCart, Tags, UsersRound, Warehouse } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import { ROLE_NAMES } from '../lib/access'

const modules = [
  { title: 'Productos', permission: 'catalog.read', icon: Boxes, phase: 2, link: '/panel/productos' },
  { title: 'Categorías', permission: 'catalog.read', icon: Tags, phase: 2, link: '/panel/categorias' },
  { title: 'Inventario', permission: 'inventory.read', icon: Warehouse, phase: 2, link: '/panel/inventario' },
  { title: 'Banners de tienda', permission: 'banners.manage', icon: Image, phase: 3, link: '/panel/banners' },
  { title: 'Pedidos', permission: 'orders.read', icon: ClipboardCheck, phase: 4, link: '/panel/pedidos' },
  { title: 'Punto de venta', permission: 'pos.sell', icon: ShoppingCart, phase: 5 },
  { title: 'Clientes y reportes', permission: 'customers.read', icon: UsersRound, phase: 6 },
]
export function DashboardPage() {
  const { profile, access } = useAuth()
  const allowed = modules.filter(m => access.permissions.includes(m.permission))
  const canRead = access.permissions.includes('catalog.read')
  const { data, isLoading, error } = useCatalogIfAllowed(canRead)
  const count = data?.products.filter(p => !p.deleted_at).length ?? 0
  const lowCount = data?.inventory.filter(s => s.quantity <= s.low_stock_threshold).length ?? 0
  return <>
    <p className="text-sm font-semibold text-brand">Panel administrativo</p>
    <h1 className="mt-1 font-display text-3xl font-bold">Hola, {profile?.full_name?.split(' ')[0] || 'bienvenido'} 👋</h1>
    <p className="mt-2 text-sm text-slate-500">Has iniciado sesión como {access.roles.map(role => ROLE_NAMES[role]).join(' / ')}.</p>
    <div className="mt-9 rounded-2xl border border-emerald-100 bg-emerald-50 p-6"><div className="flex items-center gap-2 font-semibold text-emerald-900"><LockKeyhole size={19}/> Fases 1 a 4: catálogo, tienda y pedidos integrados</div><p className="mt-2 text-sm leading-7 text-emerald-900/80">Las cuentas, los permisos, el catálogo, el inventario y la tienda pública están integrados. Puedes administrar banners, mostrar productos y preparar un carrito local. Los pedidos por WhatsApp y su seguimiento están preparados. No se cobran pagos en línea. El POS y la caja se incorporarán en la fase 5.</p></div>
    {canRead && <section className="mt-7 grid gap-4 sm:grid-cols-3">
      <div className="panel-card"><p className="text-xs font-semibold uppercase tracking-wide text-slate-500">Productos registrados</p><p className="mt-2 text-3xl font-bold">{isLoading ? '…' : count}</p></div>
      <div className="panel-card"><p className="text-xs font-semibold uppercase tracking-wide text-slate-500">Categorías</p><p className="mt-2 text-3xl font-bold">{isLoading ? '…' : data?.categories.length ?? 0}</p></div>
      <div className="panel-card"><p className="text-xs font-semibold uppercase tracking-wide text-slate-500">Variantes con stock bajo</p><p className="mt-2 text-3xl font-bold">{isLoading ? '…' : lowCount}</p></div>
      {error && <p className="text-sm text-red-700 sm:col-span-3">No se pudieron consultar los indicadores: {error.message}</p>}
    </section>}
    <h2 className="mb-4 mt-10 font-display text-xl font-bold">Módulos asignados a tu rol</h2>
    {allowed.length ? <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">{allowed.map(m => <div key={m.title} className="panel-card"><div className="mb-5 flex h-11 w-11 items-center justify-center rounded-xl bg-brand-pale text-brand"><m.icon size={22}/></div><h3 className="font-semibold">{m.title}</h3><p className="mt-2 text-sm text-slate-500">{m.phase<=4 ? 'Módulo conectado a Supabase y protegido con permisos.' : `Se implementará en la fase ${m.phase}.`}</p>{m.phase<=4 && m.link ? <Link className="btn-ghost mt-4 inline-flex" to={m.link}>Abrir módulo</Link> : <span className="mt-4 inline-flex rounded-full bg-slate-100 px-3 py-1 text-xs font-medium text-slate-500">Pendiente</span>}</div>)}</div> : <div className="panel-card text-sm text-slate-500">No hay módulos asignados a este usuario.</div>}
  </>
}

// Hooks siempre se invocan; la consulta queda desactivada para roles sin catálogo.
function useCatalogIfAllowed(enabled: boolean) {
  return useQuery({ queryKey: ['catalog-management'], queryFn: loadCatalog, enabled, staleTime: 10_000 })
}
