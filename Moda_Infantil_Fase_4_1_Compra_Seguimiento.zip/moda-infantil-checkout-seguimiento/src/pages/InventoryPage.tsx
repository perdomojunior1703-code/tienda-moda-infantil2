import { useState, type FormEvent } from 'react'
import { ArrowDownRight, ArrowUpRight, ClipboardList, Plus, Search, Warehouse } from 'lucide-react'
import { useAuth } from '../context/AuthContext'
import { mutateCatalog, type Variant } from '../features/catalog/api'
import { useCatalog, useRefreshCatalog } from '../features/catalog/hooks'
import { CatalogStatus, Field, Notice, PageHeading } from '../features/catalog/components'

export function InventoryPage() {
  const { access } = useAuth()
  const canAdjust = access.permissions.includes('inventory.adjust')
  const { data, error, isLoading } = useCatalog()
  const refresh = useRefreshCatalog()
  const [filter, setFilter] = useState('')
  const [lowOnly, setLowOnly] = useState(false)
  const [selected, setSelected] = useState<Variant | null>(null)
  const [quantity, setQuantity] = useState('1')
  const [kind, setKind] = useState<'entrada' | 'salida'>('entrada')
  const [reason, setReason] = useState('')
  const [requestId, setRequestId] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const [problem, setProblem] = useState('')
  const [message, setMessage] = useState('')
  const [showHistory, setShowHistory] = useState(true)
  const variants = (data?.variants ?? []).filter(v => {
    const p = data?.products.find(item => item.id === v.product_id)
    const size = data?.sizes.find(s => s.id === v.size_id)
    const color = data?.colors.find(c => c.id === v.color_id)
    const stock = data?.inventory.find(i => i.variant_id === v.id)
    if (lowOnly && (stock?.quantity ?? 0) > (stock?.low_stock_threshold ?? 3)) return false
    return `${p?.name ?? ''} ${v.sku} ${size?.label ?? ''} ${color?.name ?? ''}`.toLowerCase().includes(filter.toLowerCase())
  })
  const totalUnits = data?.inventory.reduce((sum, item) => sum + item.quantity, 0) ?? 0
  const lowCount = data?.inventory.filter(item => item.quantity <= item.low_stock_threshold).length ?? 0

  function selectVariant(variant: Variant) {
    setSelected(variant); setRequestId(null); setProblem(''); setMessage(''); setQuantity('1'); setKind('entrada'); setReason('')
  }
  async function submit(event: FormEvent) {
    event.preventDefault()
    if (!selected || !canAdjust) return
    const n = Number(quantity)
    if (!Number.isSafeInteger(n) || n <= 0 || n > 1_000_000 || reason.trim().length < 5) {
      setProblem('Escribe una cantidad entera positiva y un motivo de mínimo 5 caracteres.'); return
    }
    const delta = kind === 'entrada' ? n : -n
    if (!window.confirm(`¿Confirmar ${kind} de ${n} unidad(es)? Esta acción quedará en el historial.`)) return
    setBusy(true); setProblem(''); setMessage('')
    const currentRequestId = requestId ?? crypto.randomUUID()
    setRequestId(currentRequestId) // Mantener la misma solicitud si la red falla y se reintenta.
    try {
      const result = await mutateCatalog<{ balance_after: number; repeated: boolean }>('catalog_adjust_stock', {
        p_variant_id: selected.id, p_delta: delta, p_reason: reason.trim(), p_request_id: currentRequestId,
      })
      await refresh()
      setMessage(result.repeated ? `La solicitud ya estaba aplicada. Existencia: ${result.balance_after}.` : `Movimiento registrado. Existencia actual: ${result.balance_after}.`)
      setSelected(null); setRequestId(null); setQuantity('1'); setReason('')
    } catch (err) { setProblem(err instanceof Error ? err.message : 'No se pudo modificar el inventario.') }
    finally { setBusy(false) }
  }
  return <>
    <PageHeading eyebrow="Inventario · Fase 2" title="Existencias por variante" description="Entradas y salidas manuales quedan registradas con responsable, fecha y motivo. No se permite stock negativo."/>
    <Notice error={problem} success={message}/>
    <CatalogStatus loading={isLoading} error={error}>
      <div className="mb-6 grid gap-4 sm:grid-cols-3">
        <div className="panel-card"><Warehouse className="mb-3 text-brand" size={23}/><p className="text-xs font-semibold uppercase tracking-wide text-slate-500">Unidades totales</p><p className="mt-2 text-3xl font-bold">{totalUnits}</p></div>
        <div className="panel-card"><ClipboardList className="mb-3 text-brand" size={23}/><p className="text-xs font-semibold uppercase tracking-wide text-slate-500">Variantes</p><p className="mt-2 text-3xl font-bold">{data?.variants.length ?? 0}</p></div>
        <div className="panel-card"><ArrowDownRight className="mb-3 text-red-600" size={23}/><p className="text-xs font-semibold uppercase tracking-wide text-slate-500">Con pocas existencias</p><p className="mt-2 text-3xl font-bold">{lowCount}</p></div>
      </div>
      <div className="panel-card mb-6 flex flex-wrap items-end gap-4"><label className="form-label min-w-[220px] flex-1"><span className="flex items-center gap-2"><Search size={17}/> Buscar por producto o SKU</span><input className="form-input" value={filter} onChange={e => setFilter(e.target.value)} placeholder="Ej. Camiseta talla 4"/></label><label className="flex items-center gap-2 pb-3 text-sm font-semibold"><input type="checkbox" checked={lowOnly} onChange={e => setLowOnly(e.target.checked)}/> Solo existencias bajas</label></div>
      <div className="overflow-x-auto rounded-2xl border border-slate-100 bg-white shadow-sm"><table className="w-full min-w-[700px] text-left text-sm"><thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500"><tr><th className="px-5 py-4">Producto</th><th className="px-5 py-4">Talla / Color</th><th className="px-5 py-4">SKU</th><th className="px-5 py-4">Existencias</th><th className="px-5 py-4">Acción</th></tr></thead><tbody>{variants.map(v => {
        const p = data?.products.find(item => item.id === v.product_id)
        const stock = data?.inventory.find(item => item.variant_id === v.id)
        const isLow = (stock?.quantity ?? 0) <= (stock?.low_stock_threshold ?? 3)
        return <tr key={v.id} className="border-t border-slate-100"><td className="px-5 py-4 font-semibold">{p?.name ?? 'Producto desconocido'}</td><td className="px-5 py-4">{data?.sizes.find(s => s.id===v.size_id)?.label} / {data?.colors.find(c => c.id===v.color_id)?.name}</td><td className="px-5 py-4 text-slate-500">{v.sku}</td><td className="px-5 py-4"><span className={`rounded-full px-3 py-1 text-xs font-bold ${isLow ? 'bg-red-50 text-red-700' : 'bg-emerald-50 text-emerald-800'}`}>{stock?.quantity ?? 0} unid.</span></td><td className="px-5 py-4">{canAdjust ? <button className="btn-ghost !py-2" onClick={() => selectVariant(v)}><Plus size={15}/> Ajustar</button> : <span className="text-xs text-slate-400">Solo lectura</span>}</td></tr>
      })}</tbody></table>{variants.length===0 && <p className="p-6 text-sm text-slate-500">No hay variantes para este filtro. Crea variantes dentro de un producto.</p>}</div>
      {selected && canAdjust && <section className="panel-card mt-6" aria-label="Formulario para ajustar inventario"><div className="mb-5 flex flex-wrap items-center justify-between gap-3"><h2 className="font-display text-xl font-bold">Movimiento manual · {selected.sku}</h2><button className="btn-ghost" onClick={() => {setSelected(null);setRequestId(null)}} disabled={busy}>Cancelar</button></div><p className="mb-4 text-sm text-slate-500">Existencias actuales: <strong>{data?.inventory.find(i => i.variant_id===selected.id)?.quantity ?? 0}</strong>. Nunca ajustes la cantidad modificando una tabla directamente.</p>
        <form className="grid gap-4 md:grid-cols-3" onSubmit={e => void submit(e)}>
          <Field label="Tipo de movimiento"><select className="form-input" value={kind} disabled={busy} onChange={e => {setKind(e.target.value as 'entrada'|'salida');setRequestId(null)}}><option value="entrada">Entrada (sumar)</option><option value="salida">Salida (restar)</option></select></Field>
          <Field label="Cantidad"><input required className="form-input" type="number" min="1" max="1000000" step="1" value={quantity} disabled={busy} onChange={e => {setQuantity(e.target.value);setRequestId(null)}}/></Field>
          <Field label="Motivo"><input required minLength={5} maxLength={500} className="form-input" placeholder="Ej. Compra al proveedor" value={reason} disabled={busy} onChange={e => {setReason(e.target.value);setRequestId(null)}}/></Field>
          <div className="md:col-span-3"><button className="btn-primary !w-auto" disabled={busy}>{kind==='entrada' ? <ArrowUpRight size={17}/> : <ArrowDownRight size={17}/>} {busy ? 'Procesando…' : 'Confirmar movimiento'}</button></div>
        </form>
      </section>}
      <section className="panel-card mt-7"><div className="flex flex-wrap items-center justify-between gap-2"><h2 className="font-display text-xl font-bold">Historial de movimientos</h2><button className="btn-ghost" onClick={() => setShowHistory(s => !s)}>{showHistory ? 'Ocultar' : 'Mostrar'}</button></div>
        {showHistory && <><p className="my-3 text-xs text-slate-500">Últimos 200 movimientos registrados.</p><div className="overflow-x-auto"><table className="w-full min-w-[650px] text-left text-sm"><thead className="border-b text-xs uppercase text-slate-500"><tr><th className="py-3">Fecha</th><th>SKU</th><th>Tipo</th><th>Cambio</th><th>Saldo</th><th>Motivo</th></tr></thead><tbody>{data?.movements.map(m => <tr key={m.id} className="border-b border-slate-100"><td className="py-3">{new Date(m.created_at).toLocaleString('es-CO')}</td><td>{data.variants.find(v => v.id===m.variant_id)?.sku ?? '—'}</td><td>{m.movement_type}</td><td className={m.quantity_delta>0 ? 'font-semibold text-emerald-800' : 'font-semibold text-red-700'}>{m.quantity_delta>0 ? '+' : ''}{m.quantity_delta}</td><td>{m.balance_after}</td><td>{m.reason || '—'}</td></tr>)}</tbody></table>{!data?.movements.length && <p className="py-5 text-sm text-slate-500">Todavía no hay movimientos.</p>}</div></>}
      </section>
    </CatalogStatus>
  </>
}
