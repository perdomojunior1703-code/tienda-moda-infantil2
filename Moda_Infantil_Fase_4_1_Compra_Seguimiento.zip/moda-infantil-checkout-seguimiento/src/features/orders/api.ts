import { supabase } from '../../lib/supabase'

export type DeliveryMethod = 'recogida'|'domicilio_local'|'envio_nacional'
export type OrderStatus = 'pendiente'|'confirmado'|'en_preparacion'|'enviado'|'entregado'|'cancelado'
export interface ShippingRate { id: string; zone_id?: string; zone_name: string; method: DeliveryMethod; price: number; city: string|null; department: string|null; active?: boolean }
export interface Carrier { id: string; name: string; website: string|null; active: boolean }
export interface ShippingOptions { rates: ShippingRate[]; whatsapp: string|null }
export interface ShippingAdmin extends ShippingOptions { carriers: Carrier[] }
export interface OrderItem { name: string; sku: string|null; size: string; color: string; quantity: number; price: number; total: number }
export interface OrderHistory { status: OrderStatus; at: string; reason: string|null }
export interface OrderInfo {
  id: string; number: string; status: OrderStatus; payment: string; channel: string;
  subtotal: number; shipping: number; total: number; method: DeliveryMethod;
  address: {address:string;city:string;department:string}|null;
  notes: string|null; created_at: string; name: string; phone: string;
  tracking_number: string|null; carrier: string|null; items: OrderItem[]; history: OrderHistory[]
}
export interface OrderReceipt { id: string; number: string; repeated: boolean; subtotal: number; shipping: number; total: number }

export async function orderRpc<T>(fn:string, params:Record<string,unknown> = {}):Promise<T> {
  if (!supabase) throw new Error('Configura el archivo .env con las credenciales públicas de Supabase.')
  const {data,error}=await supabase.rpc(fn,params)
  if (error) throw new Error(error.message)
  return data as T
}
export const getShipping=()=>orderRpc<ShippingOptions>('shipping_public_options')
export const getShippingAdmin=()=>orderRpc<ShippingAdmin>('shipping_admin_data')
export const getMyOrders=()=>orderRpc<OrderInfo[]>('orders_list',{p_scope:'mine'})
export const getStaffOrders=()=>orderRpc<OrderInfo[]>('orders_list',{p_scope:'staff'})
export const deliveryLabel:Record<DeliveryMethod,string> = {
  recogida:'Recoger en tienda',domicilio_local:'Domicilio local',envio_nacional:'Envío nacional'
}
export const orderLabel:Record<OrderStatus,string> = {
  pendiente:'Pendiente',confirmado:'Confirmado',en_preparacion:'En preparación',
  enviado:'Enviado',entregado:'Entregado',cancelado:'Cancelado'
}
export const nextStatus:Record<OrderStatus,OrderStatus[]> = {
  pendiente:['confirmado','cancelado'],confirmado:['en_preparacion','cancelado'],
  en_preparacion:['enviado','entregado','cancelado'],enviado:['entregado'],entregado:[],cancelado:[]
}
export function whatsappOrderUrl(phone:string|null,order:OrderReceipt, name:string, lines:string[]):string|null {
  const digits=(phone||'').replace(/\D/g,'')
  if(digits.length<10||digits.length>15) return null
  const msg=[`Hola, soy ${name}. Quisiera consultar el pedido ${order.number}.`,...lines,
    'El pedido está pendiente de confirmación y de pago. ¿Podemos coordinar la entrega?'].join('\n')
  return `https://wa.me/${digits}?text=${encodeURIComponent(msg)}`
}
