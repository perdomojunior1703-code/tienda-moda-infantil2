import { Check, Clock3, PackageCheck, Truck, XCircle } from 'lucide-react'
import { orderLabel, type OrderInfo, type OrderStatus } from './api'

/** Read-only visual summary. The actual status always comes from the secured orders_list RPC. */
export function OrderTimeline({ order }: { order: OrderInfo }) {
  const steps: OrderStatus[] = order.method === 'recogida'
    ? ['pendiente', 'confirmado', 'en_preparacion', 'entregado']
    : ['pendiente', 'confirmado', 'en_preparacion', 'enviado', 'entregado']
  const cancelled = order.status === 'cancelado'
  const currentStep = steps.indexOf(order.status)

  if (cancelled) return <div role="status" className="mt-5 flex items-start gap-3 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-800">
    <XCircle size={21} className="shrink-0" /> <span><strong>Pedido cancelado.</strong> Consulta el historial para conocer el motivo registrado por la tienda.</span>
  </div>

  return <div className="mt-5" aria-label="Progreso de tu pedido">
    <ol className="grid gap-2 sm:grid-cols-4 lg:grid-cols-5">
      {steps.map((step, idx) => {
        const done = idx < currentStep
        const active = idx === currentStep
        return <li key={step} aria-current={active ? 'step' : undefined} className={`flex items-center gap-2 rounded-xl border px-3 py-3 text-xs font-semibold ${done ? 'border-emerald-200 bg-emerald-50 text-emerald-800' : active ? 'border-red-200 bg-red-50 text-red-800' : 'border-slate-200 bg-slate-50 text-slate-400'}`}>
          <span className="shrink-0">{done ? <Check size={17} aria-hidden="true"/> : active ? <Clock3 size={17} aria-hidden="true"/> : step === 'enviado' ? <Truck size={17} aria-hidden="true"/> : <PackageCheck size={17} aria-hidden="true"/>}</span>
          {orderLabel[step]}
        </li>
      })}
    </ol>
    <p className="mt-3 text-xs text-slate-500">El seguimiento refleja los cambios registrados por la tienda. El estado del pago se controla por separado.</p>
  </div>
}
