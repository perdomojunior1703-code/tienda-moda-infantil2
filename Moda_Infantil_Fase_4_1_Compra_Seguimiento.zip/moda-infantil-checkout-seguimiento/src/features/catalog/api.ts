import { supabase } from '../../lib/supabase'

export interface Category { id: string; parent_id: string | null; name: string; slug: string; description: string | null; image_path: string | null; is_active: boolean; created_at: string }
export interface Product { id: string; category_id: string | null; name: string; slug: string; description: string | null; sku: string | null; sale_price: number; previous_price: number | null; cost_price: number | null; is_active: boolean; is_featured: boolean; is_new: boolean; deleted_at: string | null; created_at: string }
export interface Size { id: string; label: string; sort_order: number }
export interface Color { id: string; name: string; hex_code: string | null }
export interface Variant { id: string; product_id: string; size_id: string; color_id: string; sku: string; barcode: string | null; price_override: number | null; is_active: boolean; created_at: string }
export interface Stock { variant_id: string; quantity: number; low_stock_threshold: number; updated_at: string }
export interface StockMovement { id: string; variant_id: string; movement_type: string; quantity_delta: number; balance_after: number; reason: string | null; created_at: string }
export interface ProductImage { id: string; product_id: string; storage_path: string; alt_text: string | null; sort_order: number }
export interface CatalogData { categories: Category[]; products: Product[]; sizes: Size[]; colors: Color[]; variants: Variant[]; inventory: Stock[]; movements: StockMovement[]; images: ProductImage[] }

function client() {
  if (!supabase) throw new Error('Primero configura la conexión pública de Supabase en .env')
  return supabase
}

export async function loadCatalog(): Promise<CatalogData> {
  const { data, error } = await client().rpc('catalog_management_data')
  if (error) throw new Error(error.message + ' · ¿Ejecutaste la migración SQL de fase 2?')
  if (!data || typeof data !== 'object' || Array.isArray(data)) throw new Error('Respuesta de catálogo inválida')
  const v = data as Record<string, unknown>
  const entries = ['categories', 'products', 'sizes', 'colors', 'variants', 'inventory', 'movements', 'images']
  if (entries.some(key => !Array.isArray(v[key]))) throw new Error('Faltan datos del catálogo')
  return data as unknown as CatalogData
}

type RpcName = 'catalog_save_category' | 'catalog_delete_category' | 'catalog_save_product' |
  'catalog_archive_product' | 'catalog_save_size' | 'catalog_save_color' |
  'catalog_save_variant' | 'catalog_adjust_stock' | 'catalog_add_product_image' |
  'catalog_remove_product_image'

export async function mutateCatalog<T = unknown>(name: RpcName, args: Record<string, unknown>): Promise<T> {
  const { data, error } = await client().rpc(name, args)
  if (error) {
    if (error.code === '23505') throw new Error('Ya existe un registro con ese identificador, nombre, SKU o combinación de talla y color.')
    if (error.code === '42501') throw new Error('Tu cuenta no tiene permiso para esta acción.')
    throw new Error(error.message)
  }
  return data as T
}

export function productImageUrl(path: string): string {
  return client().storage.from('product-images').getPublicUrl(path).data.publicUrl
}

export async function uploadProductImages(productId: string, files: File[], currentCount: number) {
  for (const [index, file] of files.entries()) {
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) throw new Error(`El formato de ${file.name} no está permitido. Usa JPG, PNG o WebP.`)
    if (file.size > 5 * 1024 * 1024) throw new Error(`${file.name} supera el límite de 5 MB.`)
    const extension = file.type === 'image/jpeg' ? 'jpg' : file.type === 'image/png' ? 'png' : 'webp'
    const path = `${productId}/${crypto.randomUUID()}.${extension}`
    const { error } = await client().storage.from('product-images').upload(path, file, { contentType: file.type, upsert: false })
    if (error) throw new Error(`No se pudo subir ${file.name}: ${error.message}`)
    try {
      await mutateCatalog('catalog_add_product_image', {
        p_product_id: productId, p_storage_path: path, p_alt_text: file.name,
        p_sort_order: currentCount + index,
      })
    } catch (rpcError) {
      await client().storage.from('product-images').remove([path])
      throw rpcError
    }
  }
}

export async function removeProductImage(image: ProductImage) {
  // Retirar primero el archivo; si falla, no se pierde su registro en la base.
  const { error } = await client().storage.from('product-images').remove([image.storage_path])
  if (error) throw new Error(`No se pudo eliminar el archivo: ${error.message}`)
  await mutateCatalog('catalog_remove_product_image', { p_id: image.id })
}

export const formatCop = (n: number | null | undefined) =>
  new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', maximumFractionDigits: 0 }).format(Number(n ?? 0))

export const slugify = (s: string) => s.trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '')

export function categoryImageUrl(path: string): string {
  return client().storage.from('category-images').getPublicUrl(path).data.publicUrl
}

export async function uploadCategoryImage(category: Category, file: File) {
  if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) throw new Error('Usa una imagen JPG, PNG o WebP.')
  if (file.size > 5 * 1024 * 1024) throw new Error('La imagen supera 5 MB.')
  const extension = file.type === 'image/jpeg' ? 'jpg' : file.type === 'image/png' ? 'png' : 'webp'
  const path = `categories/${category.id}/${crypto.randomUUID()}.${extension}`
  const { error } = await client().storage.from('category-images').upload(path, file, { contentType: file.type, upsert: false })
  if (error) throw new Error(error.message)
  try {
    await mutateCatalog('catalog_save_category', {
      p_id: category.id, p_name: category.name, p_slug: category.slug,
      p_description: category.description, p_is_active: category.is_active,
      p_parent_id: category.parent_id, p_image_path: path,
    })
  } catch (rpcError) {
    await client().storage.from('category-images').remove([path]); throw rpcError
  }
  // Es posible que la categoría tenga un archivo anterior: intentar limpiarlo sin revertir el guardado.
  if (category.image_path?.startsWith(`categories/${category.id}/`)) {
    await client().storage.from('category-images').remove([category.image_path])
  }
}
