import { useQuery, useQueryClient } from '@tanstack/react-query'
import { loadCatalog } from './api'
export function useCatalog() {
  return useQuery({ queryKey: ['catalog-management'], queryFn: loadCatalog, staleTime: 10_000 })
}
export function useRefreshCatalog() {
  const queryClient = useQueryClient()
  return () => queryClient.invalidateQueries({ queryKey: ['catalog-management'] })
}
