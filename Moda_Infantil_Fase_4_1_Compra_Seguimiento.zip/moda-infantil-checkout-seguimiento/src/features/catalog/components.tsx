import type { ReactNode } from 'react'
import { AlertCircle, CheckCircle2, LoaderCircle } from 'lucide-react'
export function Notice({ error, success }: { error?: string; success?: string }) {
  return <>{error && <div role="alert" className="mb-5 flex gap-2 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800"><AlertCircle className="shrink-0" size={19}/>{error}</div>}
    {success && <div role="status" className="mb-5 flex gap-2 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-900"><CheckCircle2 className="shrink-0" size={19}/>{success}</div>}</>
}
export function CatalogStatus({ loading, error, children }: { loading: boolean; error?: Error | null; children: ReactNode }) {
  if (loading) return <div className="panel-card flex items-center gap-3 text-sm text-slate-600"><LoaderCircle className="animate-spin text-brand" size={20}/> Consultando datos reales de Supabase…</div>
  if (error) return <Notice error={`No se pudo cargar el catálogo: ${error.message}`}/>
  return <>{children}</>
}
export function PageHeading({ eyebrow, title, description, action }: { eyebrow: string; title: string; description: string; action?: ReactNode }) {
  return <div className="mb-7 flex flex-wrap items-start justify-between gap-4"><div><p className="text-sm font-semibold text-brand">{eyebrow}</p><h1 className="mt-1 font-display text-3xl font-bold tracking-tight">{title}</h1><p className="mt-2 max-w-2xl text-sm leading-6 text-slate-500">{description}</p></div>{action}</div>
}
export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return <label className="form-label">{label}{children}{hint && <span className="mt-1 block text-xs font-normal text-slate-400">{hint}</span>}</label>
}
