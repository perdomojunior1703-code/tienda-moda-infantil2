import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react'
import type { StoreData, StoreVariant } from './api'

export interface CartLine { variantId: string; quantity: number }
interface CartState {
  lines: CartLine[]; favoriteIds: string[]; count: number;
  addLine: (variant: StoreVariant, quantity: number) => void;
  setLineQuantity: (variantId: string, quantity: number) => void;
  removeLine: (variantId: string) => void;
  clearCart: () => void;
  toggleFavorite: (id: string) => void;
}
const CART_KEY = 'moda-infantil:cart:v3'
const FAV_KEY = 'moda-infantil:favorites:v3'
function fromStorage<T>(key: string, fallback: T): T {
  try { const raw = window.localStorage.getItem(key); return raw ? JSON.parse(raw) as T : fallback } catch { return fallback }
}
function storedLines(): CartLine[] {
  const value = fromStorage<unknown>(CART_KEY, [])
  if (!Array.isArray(value)) return []
  return value.filter((v): v is CartLine => typeof v?.variantId === 'string' && Number.isInteger(v.quantity) && v.quantity > 0 && v.quantity <= 100).slice(0,150)
}
function storedFavorites(): string[] {
  const value = fromStorage<unknown>(FAV_KEY, [])
  return Array.isArray(value) ? value.filter((v): v is string => typeof v === 'string').slice(0,200) : []
}
const CartContext = createContext<CartState | null>(null)
export function CartProvider({children}:{children:ReactNode}) {
  const [lines, setLines] = useState<CartLine[]>(storedLines)
  const [favoriteIds,setFavorites] = useState<string[]>(storedFavorites)
  useEffect(() => { try { window.localStorage.setItem(CART_KEY, JSON.stringify(lines)) } catch { /* almacenamiento no disponible */ } },[lines])
  useEffect(() => { try { window.localStorage.setItem(FAV_KEY, JSON.stringify(favoriteIds)) } catch { /* almacenamiento no disponible */ } },[favoriteIds])
  const addLine = useCallback((variant: StoreVariant, quantity: number) => {
    const qty = Math.max(1,Math.trunc(quantity))
    setLines(old => {
      const existing = old.find(v => v.variantId === variant.id)
      const nextQty = Math.min(100, variant.quantity, (existing?.quantity ?? 0)+qty)
      if (nextQty <= 0) return old
      if (existing) return old.map(v => v.variantId === variant.id ? {...v,quantity:nextQty} : v)
      return [...old,{variantId:variant.id,quantity:nextQty}]
    })
  },[])
  const setLineQuantity = useCallback((id:string,quantity:number) => setLines(old => old.map(v => v.variantId === id ? {...v,quantity:Math.max(1,Math.min(100,Math.trunc(quantity)))} : v)),[])
  const removeLine = useCallback((id:string) => setLines(old => old.filter(v => v.variantId !== id)),[])
  const clearCart = useCallback(() => setLines([]),[])
  const toggleFavorite = useCallback((id:string) => setFavorites(old => old.includes(id) ? old.filter(v => v !== id) : [...old,id]),[])
  return <CartContext.Provider value={{lines,favoriteIds,count:lines.reduce((n,v)=>n+v.quantity,0),addLine,setLineQuantity,removeLine,clearCart,toggleFavorite}}>{children}</CartContext.Provider>
}
export function useCart() {
  const value = useContext(CartContext)
  if (!value) throw new Error('Falta CartProvider')
  return value
}
export function resolveCart(data: StoreData, lines: CartLine[]) {
  return lines.map(line => {
    const variant = data.variants.find(v => v.id === line.variantId)
    const product = data.products.find(p => p.id === variant?.product_id)
    if (!variant || !product) return null
    return {line,product,variant,available:variant.quantity,unitPrice:Number(variant.price_override ?? product.sale_price)}
  }).filter((x): x is NonNullable<typeof x> => x !== null)
}
