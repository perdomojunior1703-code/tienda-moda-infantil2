import { supabase } from '../../lib/supabase'
import { formatCop } from '../catalog/api'

export { formatCop }
export interface StoreCategory { id: string; name: string; slug: string; description: string | null; image_path: string | null; parent_id: string | null }
export interface StoreProduct { id: string; category_id: string | null; name: string; slug: string; description: string | null; sku: string | null; sale_price: number; previous_price: number | null; is_featured: boolean; is_new: boolean; created_at: string }
export interface StoreVariant { id: string; product_id: string; size_id: string; color_id: string; sku: string; price_override: number | null; quantity: number }
export interface StoreSize { id: string; label: string; sort_order: number }
export interface StoreColor { id: string; name: string; hex_code: string | null }
export interface StoreImage { id: string; product_id: string; storage_path: string; alt_text: string | null; sort_order: number }
export interface StoreBanner { id: string; title: string; description: string | null; image_path: string; button_text: string | null; target_url: string | null; sort_order: number }
export interface AdminBanner extends StoreBanner { is_active: boolean; starts_at: string | null; ends_at: string | null }
export interface StoreSettings {
  store_name: string; logo_path: string | null; whatsapp: string | null; phone: string | null; address: string | null;
  city: string | null; department: string | null; opening_hours: string | null; about_us: string | null;
  instagram_url: string | null; facebook_url: string | null; shipping_information: string | null; return_policy: string | null
}
export interface StoreData { categories: StoreCategory[]; products: StoreProduct[]; sizes: StoreSize[]; colors: StoreColor[]; variants: StoreVariant[]; images: StoreImage[]; banners: StoreBanner[]; settings: StoreSettings | null }

const publicUrl = (bucket: string, path: string) => supabase?.storage.from(bucket).getPublicUrl(path).data.publicUrl ?? ''
export const productPhoto = (path: string) => publicUrl('product-images', path)
export const categoryPhoto = (path: string) => publicUrl('category-images', path)
export const bannerPhoto = (path: string) => publicUrl('promo-banners', path)
export const storeLogoPhoto = (path: string) => publicUrl('store-assets', path)

export async function loadStorefront(): Promise<StoreData> {
  if (!supabase) throw new Error('Configura VITE_SUPABASE_URL y VITE_SUPABASE_PUBLISHABLE_KEY en el archivo .env')
  const { data, error } = await supabase.rpc('storefront_data')
  if (error) throw new Error(`${error.message}. Comprueba que ejecutaste la migración SQL de la fase 3.`)
  if (!data || Array.isArray(data) || typeof data !== 'object') throw new Error('Respuesta pública inválida')
  const result = data as Record<string, unknown>
  if (!['categories','products','sizes','colors','variants','images','banners'].every(k => Array.isArray(result[k]))) {
    throw new Error('La consulta del catálogo público devolvió datos incompletos')
  }
  return data as unknown as StoreData
}

export function productPhotos(data: StoreData, productId: string) {
  return data.images.filter(img => img.product_id === productId).sort((a,b) => a.sort_order - b.sort_order)
}
export function productVariants(data: StoreData, productId: string) {
  return data.variants.filter(v => v.product_id === productId)
}
export function totalAvailable(data: StoreData, productId: string) {
  return productVariants(data,productId).reduce((total, v) => total + v.quantity, 0)
}
export function productPrice(product: StoreProduct, variant?: StoreVariant) {
  return Number(variant?.price_override ?? product.sale_price)
}
export function hasDiscount(product: StoreProduct) {
  return product.previous_price !== null && Number(product.previous_price) > Number(product.sale_price)
}
export function safeSiteLink(url: string | null | undefined) {
  if (!url) return null
  if (/^\/(?!\/)[\w/?#=&%-]*$/.test(url)) return url
  if (/^https:\/\/[^\s]+$/i.test(url)) return url
  return null
}
export function waLink(phone: string | null | undefined) {
  const digits = (phone ?? '').replace(/\D/g,'')
  return digits.length >= 10 && digits.length <= 15 ? `https://wa.me/${digits}` : null
}
