import { Heart, Image as ImageIcon, ShoppingBag, ArrowUpRight } from 'lucide-react'
import { Link } from 'react-router-dom'
import { useCart } from './cart'
import { formatCop, hasDiscount, productPhoto, productPhotos, totalAvailable, type StoreData, type StoreProduct } from './api'

export function StoreState({loading,error,children}: {loading:boolean;error?:Error|null;children:React.ReactNode}) {
  if (loading) return <div className="mx-auto max-w-7xl px-5 py-24 text-center text-sm text-slate-500" role="status">Cargando productos desde la tienda…</div>
  if (error) return <div className="mx-auto my-12 max-w-3xl rounded-2xl border border-red-200 bg-red-50 p-6 text-sm text-red-900" role="alert"><b>No pudimos cargar la tienda.</b><p className="mt-2">{error.message}</p><p className="mt-2">Comprueba la conexión y la migración SQL de la fase 3.</p></div>
  return <>{children}</>
}
export function ProductVisual({data,product,large=false}: {data:StoreData;product:StoreProduct;large?:boolean}) {
  const photo = productPhotos(data,product.id)[0]
  return photo ? <img className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.04]" src={productPhoto(photo.storage_path)} loading="lazy" alt={photo.alt_text ?? product.name}/> :
    <div className="flex h-full w-full flex-col items-center justify-center gap-3 bg-gradient-to-br from-[#fff0ed] via-[#fff6f3] to-[#ffe0dd] text-[#c56762]">
      <div className={`rounded-[2rem] border-2 border-white/75 bg-white/50 p-7 shadow-inner ${large ? 'scale-125' : ''}`}><ShoppingBag strokeWidth={1.15} size={62}/></div>
      <span className="text-xs font-semibold tracking-wide">Imagen próximamente</span>
    </div>
}
export function ProductCard({data,product}: {data:StoreData;product:StoreProduct}) {
  const {favoriteIds,toggleFavorite} = useCart()
  const liked = favoriteIds.includes(product.id)
  const stock = totalAvailable(data,product.id)
  const category = data.categories.find(c => c.id === product.category_id)
  return <article className="group overflow-hidden rounded-[1.4rem] border border-slate-100 bg-white shadow-[0_12px_30px_-22px_rgba(22,22,22,.2)] transition hover:-translate-y-1 hover:shadow-lg">
    <div className="relative aspect-[4/4.8] overflow-hidden">
      <Link to={`/producto/${product.slug}`} className="block h-full" aria-label={`Ver ${product.name}`}><ProductVisual data={data} product={product}/></Link>
      <div className="absolute left-3 top-3 flex flex-col items-start gap-2 text-[10px] font-bold sm:text-xs">
        {hasDiscount(product) && <span className="rounded-full bg-brand px-3 py-1.5 text-white">Oferta</span>}
        {product.is_new && <span className="rounded-full bg-white px-3 py-1.5 text-slate-800 shadow-sm">Novedad</span>}
        {stock === 0 && <span className="rounded-full bg-slate-800 px-3 py-1.5 text-white">Agotado</span>}
      </div>
      <button type="button" className={`absolute right-3 top-3 rounded-full p-3 shadow-sm transition ${liked ? 'bg-red-50 text-brand' : 'bg-white/90 text-slate-500 hover:text-brand'}`} onClick={() => toggleFavorite(product.id)} aria-label={liked ? `Quitar ${product.name} de favoritos` : `Guardar ${product.name} como favorito`} title={liked ? 'Quitar de favoritos' : 'Añadir a favoritos'}><Heart size={18} fill={liked ? 'currentColor' : 'none'}/></button>
    </div>
    <div className="p-4 sm:p-5"><p className="mb-1 text-xs font-semibold text-slate-400">{category?.name ?? 'Moda Infantil'}</p><Link to={`/producto/${product.slug}`} className="line-clamp-2 font-display text-base font-bold text-ink hover:text-brand">{product.name}</Link>
      <div className="mt-3 flex flex-wrap items-center gap-2"><strong className="text-lg text-brand">{formatCop(product.sale_price)}</strong>{hasDiscount(product) && <s className="text-xs text-slate-400">{formatCop(product.previous_price)}</s>}</div>
      <Link to={`/producto/${product.slug}`} className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-xl border border-slate-200 px-3 py-3 text-sm font-bold text-ink transition hover:border-brand hover:bg-brand hover:text-white">{stock ? 'Ver tallas y colores' : 'Ver detalles'} <ArrowUpRight size={16}/></Link>
    </div>
  </article>
}
export function EmptyProducts({title='No hay productos disponibles',detail='Los productos activos que registres en tu panel aparecerán aquí.'}: {title?:string;detail?:string}) {
  return <div className="rounded-3xl border border-dashed border-slate-200 bg-white px-6 py-16 text-center"><ImageIcon size={40} className="mx-auto text-slate-300"/><h2 className="mt-4 font-display text-lg font-bold">{title}</h2><p className="mx-auto mt-2 max-w-lg text-sm leading-6 text-slate-500">{detail}</p><Link className="mt-6 inline-flex text-sm font-bold text-brand hover:underline" to="/catalogo">Ver todo el catálogo</Link></div>
}
