import { useQuery, useQueryClient } from '@tanstack/react-query'
import { loadStorefront } from './api'
export function useStore() {
  return useQuery({ queryKey: ['storefront'], queryFn: loadStorefront, staleTime: 30_000, refetchOnMount: 'always' })
}
export function useRefreshStore() {
  const qc = useQueryClient()
  return () => qc.invalidateQueries({ queryKey: ['storefront'] })
}
