import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from 'react'
import type { User } from '@supabase/supabase-js'
import { EMPTY_ACCESS, parseAccess, type AccessPayload } from '../lib/access'
import { supabase } from '../lib/supabase'

export interface Profile {
  id: string
  full_name: string
  phone: string | null
  created_at: string
}

interface AuthContextValue {
  user: User | null
  profile: Profile | null
  access: AccessPayload
  loading: boolean
  accessLoading: boolean
  error: string | null
  refreshAccess: () => Promise<void>
  signOut: () => Promise<void>
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [access, setAccess] = useState<AccessPayload>(EMPTY_ACCESS)
  const [loading, setLoading] = useState(true)
  const [accessLoading, setAccessLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const accessRequest = useRef(0)
  const userId = user?.id

  useEffect(() => {
    if (!supabase) {
      setLoading(false)
      return
    }
    const client = supabase
    let mounted = true
    client.auth.getUser().then(({ data, error: authError }) => {
      if (!mounted) return
      setUser(authError ? null : data.user)
      setLoading(false)
    }).catch(() => {
      if (mounted) setLoading(false)
    })
    const { data } = client.auth.onAuthStateChange((_event, session) => {
      // No hacer consultas Supabase asíncronas dentro de este callback.
      if (mounted) {
        setUser(session?.user ?? null)
        setLoading(false)
      }
    })
    return () => {
      mounted = false
      data.subscription.unsubscribe()
    }
  }, [])

  const refreshAccess = useCallback(async () => {
    const currentRequest = ++accessRequest.current
    if (!supabase || !userId) {
      setAccess(EMPTY_ACCESS)
      setProfile(null)
      setError(null)
      setAccessLoading(false)
      return
    }
    const client = supabase
    setAccessLoading(true)
    setError(null)
    try {
      const [profileResult, accessResult] = await Promise.all([
        client.from('profiles').select('id,full_name,phone,created_at').eq('id', userId).single(),
        client.rpc('get_my_access'),
      ])
      if (currentRequest !== accessRequest.current) return
      if (profileResult.error) throw profileResult.error
      if (accessResult.error) throw accessResult.error
      setProfile(profileResult.data as Profile)
      setAccess(parseAccess(accessResult.data))
    } catch (err) {
      if (currentRequest !== accessRequest.current) return
      // Fallar cerrado: ante un error no conceder permisos anteriores.
      setAccess(EMPTY_ACCESS)
      setProfile(null)
      setError(err instanceof Error ? err.message : 'No se pudieron cargar los permisos.')
    } finally {
      if (currentRequest === accessRequest.current) setAccessLoading(false)
    }
  }, [userId])

  useEffect(() => {
    if (!userId) {
      accessRequest.current++
      setAccess(EMPTY_ACCESS)
      setProfile(null)
      setAccessLoading(false)
      setError(null)
      return
    }
    setAccess(EMPTY_ACCESS)
    setProfile(null)
    void refreshAccess()
  }, [userId, refreshAccess])

  const signOut = useCallback(async () => {
    if (!supabase) return
    const { error: authError } = await supabase.auth.signOut()
    if (authError) throw authError
    accessRequest.current++
    setUser(null)
    setProfile(null)
    setAccess(EMPTY_ACCESS)
  }, [])

  return (
    <AuthContext.Provider value={{ user, profile, access, loading, accessLoading, error, refreshAccess, signOut }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) throw new Error('useAuth debe usarse dentro de AuthProvider')
  return context
}
