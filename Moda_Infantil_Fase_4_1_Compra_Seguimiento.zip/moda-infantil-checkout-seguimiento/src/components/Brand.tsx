import { Baby } from 'lucide-react'
import { Link } from 'react-router-dom'

export function Brand({ light = false }: { light?: boolean }) {
  return <Link to="/" className={`inline-flex items-center gap-3 font-display text-xl font-bold tracking-tight ${light ? 'text-white' : 'text-ink'}`}>
    <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand text-white shadow-sm"><Baby size={23}/></span>
    Moda<span className="-ml-2 text-brand">Infantil</span>
  </Link>
}
