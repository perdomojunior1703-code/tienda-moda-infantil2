import { Navigate, Outlet, useLocation } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { Loading } from './Loading'

export function ProtectedRoute({ permission }: { permission?: string }) {
  const { user, profile, loading, accessLoading, access, error } = useAuth()
  const location = useLocation()
  if (loading || (user && (accessLoading || (!error && profile?.id !== user.id)))) return <Loading label="Verificando acceso..." />
  if (!user) return <Navigate to="/ingresar" replace state={{ from: location.pathname }} />
  if (error) return <div className="mx-auto mt-16 max-w-lg rounded-2xl bg-rose-50 p-6 text-red-800">
    <h2 className="text-lg font-bold">No fue posible verificar los permisos</h2>
    <p className="mt-2 text-sm">{error}</p>
    <p className="mt-2 text-sm">Comprueba que aplicaste las migraciones SQL de la fase 1.</p>
  </div>
  if (permission && !access.permissions.includes(permission)) return <Navigate to="/sin-acceso" replace />
  return <Outlet />
}
