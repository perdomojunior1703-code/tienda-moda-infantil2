import { LoaderCircle } from 'lucide-react'

export function Loading({ label = 'Cargando...' }: { label?: string }) {
  return <div className="flex min-h-52 items-center justify-center gap-3 text-slate-600" role="status">
    <LoaderCircle className="h-5 w-5 animate-spin text-brand" /> {label}
  </div>
}
