export type RoleCode = 'administrador' | 'supervisor' | 'cajero' | 'inventario' | 'cliente'

export interface AccessPayload {
  roles: RoleCode[]
  permissions: string[]
}

export const EMPTY_ACCESS: AccessPayload = { roles: [], permissions: [] }

export function parseAccess(value: unknown): AccessPayload {
  if (!value || typeof value !== 'object') return EMPTY_ACCESS
  const raw = value as Record<string, unknown>
  const roleNames: RoleCode[] = ['administrador', 'supervisor', 'cajero', 'inventario', 'cliente']
  return {
    roles: Array.isArray(raw.roles)
      ? raw.roles.filter((item): item is RoleCode => typeof item === 'string' && roleNames.includes(item as RoleCode))
      : [],
    permissions: Array.isArray(raw.permissions)
      ? raw.permissions.filter((item): item is string => typeof item === 'string')
      : [],
  }
}

export const ROLE_NAMES: Record<RoleCode, string> = {
  administrador: 'Administrador',
  supervisor: 'Supervisor',
  cajero: 'Cajero',
  inventario: 'Encargado de inventario',
  cliente: 'Cliente',
}
