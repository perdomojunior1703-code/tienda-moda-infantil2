import { createClient, type SupabaseClient } from '@supabase/supabase-js'

const url = import.meta.env.VITE_SUPABASE_URL?.trim()
const publicKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY?.trim()

export const isSupabaseConfigured = Boolean(
  url && publicKey &&
    url.startsWith('https://') &&
    !url.includes('TU-PROYECTO') &&
    !publicKey.includes('TU_CLAVE'),
)

// La service_role key / secret key NO debe utilizarse en el navegador.
export const supabase: SupabaseClient | null = isSupabaseConfigured
  ? createClient(url!, publicKey!, {
      auth: { autoRefreshToken: true, persistSession: true, detectSessionInUrl: true },
    })
  : null
