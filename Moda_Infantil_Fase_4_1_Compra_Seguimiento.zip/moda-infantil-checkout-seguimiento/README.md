# Moda Infantil — Compra por WhatsApp y seguimiento (actualización 4.1)

**Esta entrega contiene las fases 1–4 y la corrección de «Cambiar unidades» de la variante.** Funciona con **el mismo proyecto Supabase**, usuarios, productos e inventario. La compra final de esta versión consiste en **registrar un pedido pendiente y contactar a la tienda por WhatsApp**, no en realizar un pago online.

## Nuevas mejoras 4.1

- En el carrito aparece **Finalizar pedido por WhatsApp** en lugar de «Próximamente».
- El cliente entra a `/checkout`, inicia sesión si todavía no lo ha hecho, elige **recogida / domicilio / envío nacional**, completa sus datos y registra el pedido con un total calculado desde Supabase.
- Al registrar se muestra **la referencia real** y los enlaces **Abrir WhatsApp** y **Seguir este pedido**.
- En `/mis-pedidos` hay un resumen visual del progreso de cada compra y un botón **Ver seguimiento completo**.
- La nueva ruta privada `/seguimiento/MI-...` muestra estado, historial, productos, importes, dirección y guía de envío si la tienda la registra. Consulta exclusivamente los pedidos de la cuenta autenticada.
- Los pedidos se actualizan automáticamente en la consulta cada 60 segundos mientras la pantalla está abierta y también hay un botón para actualizar manualmente.
- El administrador sigue gestionando estados y guías en `/panel/pedidos`. Las cantidades de stock se modifican por operaciones seguras y auditadas.

## Instalación en tu computadora (sin perder las fases anteriores)

1. **Detén todas las terminales que estén ejecutando `npm run dev`** de las fases 3 o 4 usando **Ctrl+C**. Si Vite indica `localhost:5174` porque 5173 estaba ocupado, es fácil abrir la versión vieja sin querer.
2. Descomprime `Moda_Infantil_Fase_4_1_Compra_Seguimiento.zip`. Abre **la carpeta interna `moda-infantil-checkout-seguimiento`** (tiene `package.json`).
3. Copia tu archivo `.env` que funciona de la Fase 4 dentro de esta carpeta. No compartas claves secretas ni cambies de proyecto Supabase.
4. Si **aún no ejecutaste** `supabase/migrations/20261120000800_phase4_orders_shipping.sql`, ejecútalo en Supabase SQL Editor ahora, **solo una vez y después del 00700**. Si ya lo ejecutaste correctamente, **no ejecutes de nuevo** ningún SQL: la actualización 4.1 solo cambia la interfaz.
5. En la terminal **dentro de la carpeta interna** ejecuta:

```cmd
npm install
npm run dev -- --port 5173 --strictPort
```

Si `5173` está ocupado, detén el otro Vite con Ctrl+C; no ejecutes dos versiones a la vez. Abre `http://localhost:5173/carrito` y comprueba que el botón indique **Finalizar pedido por WhatsApp**. Si indica «Próximamente», estás viendo la versión anterior.
6. Entra al panel como administrador en **Envíos y tarifas** y configura el WhatsApp real del almacén (incluido el indicativo 57 para Colombia); registra tarifas reales de domicilio/envío si ofrecerás esas modalidades. Sin WhatsApp configurado el sistema no permite emitir pedidos.
7. Añade al carrito un producto con **variante e inventario disponibles**. Entra a **Carrito → Finalizar pedido por WhatsApp → Registrar pedido**, después pulsa el botón de WhatsApp **para enviar el mensaje** (registrar el pedido no envía automáticamente el WhatsApp).
8. Visita **Mis pedidos → Ver seguimiento completo** y, con la cuenta administradora, **Panel → Pedidos** para confirmar y actualizar estados. Comprueba que al confirmar se descuentan unidades de la variante correcta y que no se marca como pagado sin comprobarlo.

### Comprobación SQL si te aparece un error de función inexistente

Ejecuta esta consulta segura en Supabase (solo lectura):

```sql
select
  to_regprocedure('public.orders_create_whatsapp(uuid,jsonb,text,text,text,uuid,text,text,text,text)') is not null as crear_pedido,
  to_regprocedure('public.orders_list(text)') is not null as mis_pedidos,
  to_regprocedure('public.orders_change_status(uuid,text,text,uuid,text)') is not null as cambiar_estado,
  to_regprocedure('public.shipping_public_options()') is not null as tarifas;
```

Las cuatro columnas deben mostrar `true`. Si no es así, verifica la migración 00800 antes de probar el checkout.

### Límites importantes

- **No procesa dinero** (ni tarjeta, Nequi, Daviplata o transferencias automáticas). Los pagos deben verificarse por el comercio; esta versión registra **pedidos por WhatsApp pendientes de confirmación y pago**.
- No hay compra sin iniciar sesión; solo la persona propietaria de la cuenta puede ver sus pedidos.
- Los pedidos pendientes mantienen reserva **lógica** de inventario hasta 60 minutos y su confirmación vuelve a comprobar disponibilidad; la confirmación descuenta stock físico.
- **No se probó contra tu base Supabase real** ni se completó `npm run build` en este entorno (sin acceso al registro npm). Ejecuta `npm install` y `npm run build` en tu PC y revisa los flujos antes de atender compradores reales.

---

# Moda Infantil — Fases 1 + 2 + 3 + 4

Aplicación de tienda infantil construida con **React + TypeScript + Vite + Tailwind CSS + Supabase**. Esta carpeta **reemplaza el código de la Fase 3**, pero utiliza **la misma base de datos Supabase** que ya configuraste. No importa de nuevo los productos ni vuelve a crear tu usuario.

## Qué funciona en la Fase 4

- Carrito de la Fase 3 con enlace a **preparar pedido**.
- Formulario para usuarios con sesión iniciada: contacto, recogida en tienda, domicilio local o envío nacional, dirección y observaciones.
- Tarifas de envíos **configurables manualmente** por zona, región y modalidad, sin precios inventados.
- Registro de pedido por WhatsApp en tablas reales de Supabase, con referencia, captura de precio en el momento del pedido y registro idempotente.
- Comprobación de existencias con bloqueo transaccional para evitar reservar la última unidad dos veces. Reservas lógicas de **60 minutos**, liberadas por vencimiento en las consultas de disponibilidad.
- Historial **Mis pedidos** para usuarios autenticados.
- Panel **Pedidos** con estados: pendiente → confirmado → en preparación → enviado → entregado; cancelación con motivo mientras no se haya enviado.
- La confirmación manual de un pedido descuenta la variante exacta del inventario; cancelar después de confirmar restaura existencias una sola vez.
- Panel **Envíos y tarifas**: tarifas y zonas, transportadoras, número comercial de WhatsApp.
- Las fases anteriores (autenticación, permisos, productos, inventario, banners, catálogo y carrito) siguen en la carpeta.

**No incluye aún:** cobros en línea, pago verificado, compra anónima/invitados, cotización real de transportadoras, notificaciones automáticas, devoluciones y POS. Los pagos están en estado `pendiente` y nadie puede marcarlos automáticamente como pagados con esta fase. El contacto por WhatsApp lo inicia el comprador al pulsar el enlace; abrirlo no confirma ni cobra el pedido. Las reservas tienen expiración lógica mediante `expires_at > now()`; sin un job de limpieza, el valor histórico `status` puede seguir siendo `reservada` aunque ya esté vencida, pero deja de bloquear nuevas reservas.

## Instalación paso a paso (Windows / VS Code)

1. Mantén tu proyecto de Fase 3 como copia de seguridad, por ejemplo `Moda_Infantil_Fase_3_respaldo`.
2. Descomprime este ZIP. Abre **la carpeta interna `moda-infantil-fase4`**, la que contiene `package.json` y `src`.
3. Copia **tu archivo `.env` que ya funciona en Fase 3** a la carpeta interna nueva. No reemplaces `.env.example`; conserva ambos. Nunca pegues claves `secret` o `service_role` en el frontend.
4. Ve a Supabase → SQL Editor → New query. Copia y ejecuta **solo** `supabase/migrations/20261120000800_phase4_orders_shipping.sql`. **No repitas los SQL 00100–00700**, pues ya están instalados.
5. En una segunda consulta verifica:

```sql
SELECT
  to_regprocedure('public.orders_create_whatsapp(uuid,jsonb,text,text,text,uuid,text,text,text,text)') IS NOT NULL AS crear_pedido,
  to_regprocedure('public.orders_list(text)') IS NOT NULL AS consultar_pedidos,
  to_regprocedure('public.orders_change_status(uuid,text,text,uuid,text)') IS NOT NULL AS gestionar_pedido,
  to_regprocedure('public.shipping_public_options()') IS NOT NULL AS opciones_envio;
```

Las cuatro columnas deben mostrar `true`. Si Supabase muestra algún error rojo, **no lo ignores**: copia el mensaje.

6. En VS Code selecciona **Terminal → New Terminal**, asegúrate de estar en la carpeta que contiene `package.json` y ejecuta uno por uno:

```cmd
npm install
npm run dev
```

7. Abre la URL indicada por Vite (`http://localhost:5173` o `http://localhost:5174` si el anterior está ocupado). Entra con tu cuenta de administrador. En **Panel → Envíos y tarifas** añade el número WhatsApp del comercio y, si vas a ofrecer entregas, registra tarifas **reales**. No se configura ningún precio automático por nuestra parte.
8. Entra como cliente o usa tu usuario con rol `cliente`, añade un producto con variante y existencias al carrito. Entra en **Carrito → Preparar pedido por WhatsApp**. Selecciona la modalidad, completa los datos y pulsa registrar. Aparecerá la referencia y un botón para abrir WhatsApp. Consulta **Mis pedidos**.
9. Como administrador abre **Panel → Pedidos** y confirma o cambia el estado. Observa que confirmar un pedido descuenta stock; mientras está pendiente, el stock físico no se descuenta.

## Importante sobre los pedidos por WhatsApp

- Para emitir el pedido en esta versión **debes haber iniciado sesión**. Los compradores invitados requieren protección antiabuso (por ejemplo, CAPTCHA validado en Edge Function), un token de consulta seguro y límites de peticiones. Eso **aún no está implementado** y el backend no concede acceso anónimo al registro.
- **Las tarifas se gestionan manualmente.** Para domicilio local la ciudad y el departamento deben coincidir con la zona; para envíos nacionales puedes dejar ciudad y departamento vacíos si tu tarifa realmente cubre todo el país, o especificar la región.
- Un pedido por WhatsApp está **pendiente de confirmación y de pago**: ninguna acción del navegador o botón WhatsApp lo marcará como pagado.
- Ante cualquier error de conexión al registrar un pedido, la solicitud conserva su identificador para que repetirla no registre otro pedido.
- No se ejecutan consultas de productos, pedidos ni pagos con datos de prueba permanentes.
- Las funciones SQL son `SECURITY DEFINER` con comprobaciones de permisos y la escritura directa de tablas sensibles continúa cerrada para los usuarios públicos.

## Revisión y pruebas

Consulta `docs/PRUEBAS_FASE4.md`. Ejecuta opcionalmente:

```cmd
npm run build
python scripts/check_project.py
python scripts/check_phase4.py
```

Las comprobaciones offline de esta entrega no sustituyen una ejecución real contra tu Supabase; no se probaron pagos, confirmación simultánea ni las políticas con usuarios reales desde este entorno. Antes de usar la tienda con compradores reales, probar compras concurrentes, cancelar, confirmar, revisar reservas y revisar las reglas tributarias aplicables.

## Próximas fases

**Fase 5:** POS presencial, caja, recibos, devoluciones y cambios.
**Fase 6:** estadísticas, clientes, reportes y configuración general.
**Fase 7:** pruebas de seguridad, optimización, despliegue y verificación final.


## Corrección 4.0.1: cambiar unidades directamente en el producto

En **Panel → Productos → Editar y gestionar**, ahora cada variante muestra dos botones distintos:

- **Editar datos** cambia talla, color, SKU, precio especial y alerta de inventario.
- **Cambiar unidades** abre un formulario para agregar o retirar unidades con motivo obligatorio.

El cambio de unidades utiliza la función SQL `catalog_adjust_stock` ya existente en la Fase 2. Registra responsable, fecha, saldo e historial; valida permisos y no permite existencias negativas. **No se necesita ejecutar otra migración SQL para esta corrección.**

### Si ya tienes la Fase 4 funcionando

No necesitas reemplazar todo el proyecto. Descarga y reemplaza únicamente `src/pages/ProductEditorPage.tsx` por el archivo corregido; guarda y Vite actualizará la página. Para una instalación nueva, este ZIP incluye todas las fases anteriores. Conserva tu `.env` local y tu base de datos de Supabase.
