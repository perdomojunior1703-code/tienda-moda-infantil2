# Plan de pruebas Fase 3 — Moda Infantil

## Preparación
- Mantener las migraciones Fase 1 (00100–00500) y Fase 2 (00600) sin volver a ejecutarlas.
- Ejecutar solo 00700 en el proyecto existente.
- Tener como mínimo un producto visible, una variante activa con stock, y otro producto oculto o sin stock.

## Tienda pública
1. Abrir `/` en ventana privada y comprobar carga de categorías y productos sin iniciar sesión.
2. Crear un producto visible en `/panel/productos`, recargar `/catalogo` y comprobar que está visible.
3. Cambiar `Mostrar en tienda` a falso y comprobar que desaparece de la tienda.
4. Marcar un producto como destacado y otro como novedad; revisar secciones de inicio.
5. Registrar un precio anterior mayor al actual; verificar oferta y tachado de precio anterior.
6. Probar búsquedas con mayúsculas, texto inexistente y SKU.
7. Filtrar por categoría, talla, color, novedad y oferta; ordenar por precio.
8. En detalle, probar seleccionar talla/color con existencias; impedir agregar si agotado.
9. Verificar que imagen de Supabase Storage se visualiza cuando está subida, y marcador cuando falta.
10. Añadir carrito, sumar/restar, quitar, vaciar, recargar (localStorage), y comprobar subtotal.
11. Comprobar que el botón de pago sigue deshabilitado y nunca crea registros en `orders`.
12. Añadir favoritos, recargar, retirar favorito.
13. En `/panel/banners`, crear, editar, desactivar y borrar un banner; comprobar cambios en portada.
14. Intentar invocar CRUD de banners como cliente sin permisos: debe denegar con código 42501.
15. Comprobar móvil: menú, catálogo, detalle, carrito y favoritos.

## No declarar aún como terminado
- Cobros, reservas, pedidos, descuentos automáticos distintos del precio anterior, envíos, sincronización de carrito entre dispositivos y puntos de venta.
