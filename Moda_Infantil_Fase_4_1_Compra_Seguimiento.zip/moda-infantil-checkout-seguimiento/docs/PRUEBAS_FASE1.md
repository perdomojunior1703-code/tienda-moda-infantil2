# Pruebas de aceptación de la fase 1

**Estas son pruebas para ejecutar con un proyecto Supabase configurado; no están declaradas como ya ejecutadas.**

| # | Acción | Resultado esperado |
|---|--------|--------------------|
| 1 | Abrir la aplicación sin `.env` | Aviso de configuración; no se finge autenticación |
| 2 | Configurar `.env` y las 5 migraciones | Carga la portada, sin errores de SQL o conexión |
| 3 | Registrar cliente A | Si hay confirmación de correo, llega enlace; existe profile y rol `cliente` en la BD |
| 4 | Ingresar con cliente A | Abre su perfil; `/panel` muestra acceso restringido |
| 5 | Editar nombre y teléfono del cliente A | Cambios guardados en `public.profiles`; correo y rol no cambian |
| 6 | Ejecutar `bootstrap_admin.sql` con el correo A | Solo desde SQL Editor, A recibe rol `administrador` |
| 7 | Actualizar permisos en `/cuenta` y entrar a `/panel` | Panel accesible; lista módulos futuros como pendientes, sin métricas falsas |
| 8 | Registrar cliente B | B solo obtiene rol `cliente` y no puede entrar al panel |
| 9 | Desde sesión B intentar actualizar perfil de A con SDK/API | RLS impide modificación |
| 10 | Desde sesión B intentar insertar en `user_roles` | Falta de privilegio SQL / RLS impide autoconcederse admin |
| 11 | Desde sesión B intentar modificar stock, pedidos o ventas | Se rechaza (sin permiso ni policies operativas) |
| 12 | Desde Panel > Gestión de personal, asignar `cajero` al cliente B | Se guarda rol y auditoría; B puede ver `/panel` tras refrescar permisos |
| 12a | B intenta usar `admin_assign_role()` para darse administrador | La función rechaza la operación |
| 12b | A retira el rol `cajero` a B | B deja de poder acceder al panel tras refrescar permisos |
| 13 | Cerrar sesión como A y visitar `/panel` | Redirección a `/ingresar` |
| 14 | Recuperar contraseña | Se emite enlace (si SMTP configurado y permitido) y se puede actualizar contraseña |
| 15 | Activar Google en Supabase y Google Cloud | OAuth lleva a `/cuenta` con perfil creado como cliente |
| 16 | Ejecutar `npm run build` | TypeScript y Vite terminan sin errores |

## Pruebas de seguridad con cuentas reales

Las consultas del **SQL Editor** suelen ejecutarse con privilegios elevados y pueden ignorar RLS. Para probar el aislamiento, haz solicitudes autenticadas con la clave publicable y el token real de cada cuenta cliente desde el navegador o una herramienta de API. Nunca pruebes acceso a roles publicando la clave de servicio.

El esquema de la fase 1 aún **no valida** compras simultáneas, inventario real, devoluciones ni pagos; esas pruebas pertenecen a las fases 2, 4, 5 y 7. Las políticas de producción y las transacciones críticas deben auditarse antes del despliegue comercial.
