# Validación de la fase 4

1. Antes de probar, ejecutar la migración 00800 en Supabase tras la 00700.
2. En **Panel > Envíos y tarifas**, configurar un WhatsApp válido y, si corresponde, una tarifa real de domicilio o envío. No crear valores ficticios en producción.
3. En un producto visible, crear una variante con, por ejemplo, 3 unidades de stock de prueba.
4. Con una cuenta cliente, agregar una variante y entrar a **Carrito > Preparar pedido por WhatsApp**.
5. Seleccionar recogida en tienda, completar datos y registrar. Verificar el número de referencia y el enlace de WhatsApp.
6. Revisar **Mis pedidos**. Debe aparecer pendiente / pago pendiente.
7. Repetir llamada con el mismo `p_request_id` (solo en entorno de prueba): no debe crear otro pedido.
8. Desde el panel, ver el pedido; confirmar (descuenta inventario una vez) y comprobar historial de movimientos.
9. Con otro pedido pendiente, cancelarlo: libera reserva sin descontar stock.
10. Comprobar transición inválida (pendiente → entregado) y usuario sin rol administrativo: deben ser rechazados.
11. Probar dos pedidos simultáneos sobre la última unidad: el segundo debe fallar en el backend.
12. Probar reserva vencida luego de 60 min: debe dejar de bloquear stock; confirmar solo si queda suficiente.
13. No es posible completar las pruebas de forma automática desde este ZIP sin acceso a un Supabase de pruebas.

Limitaciones: no hay pasarela de pago, compradores invitados ni consulta por código; se requiere sesión para pedidos. La disponibilidad se recalcula al confirmar. Los movimientos de caja y devoluciones corresponden a la fase 5.
