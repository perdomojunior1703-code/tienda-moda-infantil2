# Pruebas manuales — Checkout y seguimiento 4.1

- [ ] Ver que al abrir `http://localhost:5173/carrito` dice **Finalizar pedido por WhatsApp** (no «Próximamente»).
- [ ] Confirmar que un visitante que abre `/checkout` es enviado a iniciar sesión y vuelve al checkout al ingresar.
- [ ] Configurar WhatsApp en Panel > Envíos; si no existe un WhatsApp configurado, el botón de pedido debe estar deshabilitado.
- [ ] Registrar pedido con recogida y una variante que tenga existencias disponibles; anotar referencia.
- [ ] Ver el pedido en `Mis pedidos` y abrir `Seguimiento completo`; confirmar que se ven los productos correctos, precio y estado pendiente.
- [ ] Confirmar que el botón de WhatsApp abre la conversación con la referencia correcta; comprobar que la conversación NO se envía sola.
- [ ] Abrir el mismo `/seguimiento/<referencia>` desde otra cuenta: no debe mostrar información del pedido.
- [ ] Como administrador, confirmar pedido en Panel > Pedidos: descuenta stock y aparece `Confirmado` en el seguimiento.
- [ ] Cambiar a `En preparación`, luego `Enviado` con guía (solo para entregas), y `Entregado`; comprobar el historial completo.
- [ ] Para recogida, comprobar que no existe la transición «Enviado».
- [ ] Cancelar un pedido pendiente de prueba y comprobar que libera su reserva sin inventario negativo.
- [ ] Probar dos pedidos simultáneos sobre la última unidad en un entorno de pruebas: solo uno debe reservarla.
- [ ] Revisar si Vite está usando otro puerto (`5174`, etc.). El carrito del navegador puede diferir entre puertos.
- [ ] Ejecutar `npm run build` y revisar consola y errores de Supabase; no vender en producción sin completar las pruebas críticas.
