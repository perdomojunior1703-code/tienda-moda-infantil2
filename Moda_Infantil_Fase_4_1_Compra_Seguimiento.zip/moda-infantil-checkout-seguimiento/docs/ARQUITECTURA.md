# Arquitectura — Fase 1

## Diagrama de dependencias

```text
Navegador (React + Vite + TypeScript + Tailwind)
   │
   ├── React Router (rutas públicas y protegidas)
   ├── AuthContext (sesión, perfil, permisos)
   └── supabase-js (solo con clave PUBLICABLE)
       │
       ├── Supabase Auth (correo, OAuth, recuperación)
       │     └── auth.users → trigger → public.profiles + rol cliente
       ├── PostgreSQL con RLS
       │     ├── roles / permissions / role_permissions / user_roles
       │     ├── get_my_access() → roles y permisos del usuario conectado
       │     ├── admin_list_staff() / admin_assign_role() → gestión de empleados auditada
       │     ├── has_permission(código) → autorización en futura operación SQL
       │     ├── catálogo / inventario (bloqueado para mutaciones en fase 1)
       │     └── pedidos / POS / caja / envíos (bloqueados en fase 1)
       └── Storage (buckets de imágenes públicas, sin cargas de clientes)
```

## Decisiones técnicas

1. **Fuente única de autorización:** tablas Postgres. No se toma el rol de un campo editable por el usuario. Se consulta `get_my_access()` al autenticar y al pulsar Actualizar permisos.
2. **Defensa en profundidad:** rutas privadas de React para experiencia de usuario + RLS y privilegios SQL para seguridad real. El frontend no es la frontera de seguridad.
3. **Mínimo privilegio:** los usuarios nuevos solo obtienen rol cliente; nadie puede asignarse a sí mismo un rol administrativo desde la API.
4. **Separación por fases:** los modelos de pedidos y POS se crean, pero no se abren políticas de inserción ni funciones de compra hasta implementar sus transacciones.
5. **Valores monetarios:** `numeric(12,2)` en COP, evitando `float` para precios.
6. **Integridad referencial:** variantes únicas por combinación producto+talla+color, inventario no negativo, SKU único, historial de movimientos inmutable; los flujos transaccionales se implementarán más adelante.
7. **Custodia de credenciales:** publishable key en React, secret/service role y credenciales Google **nunca** en React.
8. **Privacidad:** información de clientes, pagos y caja sin acceso al navegador hasta diseñar políticas de mínimo privilegio por cada operación.

## Inventario: pendiente crítico de la fase 2

En la fase 2 hay que crear funciones SQL atómicas para registrar entrada, salida y ajustes con: validación de permisos (`has_permission('inventory.adjust')`), bloqueo de filas por variante, cambio de existencia, inserción de movimiento, clave idempotente y auditoría. No habilitar `UPDATE public.inventory` directo al navegador. Posteriormente, las reservas de stock se implementarán con vencimiento controlado del lado servidor.

## Módulos por fase

| Fase | Alcance | Estado |
|------|---------|--------|
| 1 | Arquitectura, Auth, RLS, perfiles, roles, esquema SQL | Código entregado; integración pendiente de credenciales |
| 2 | CRUD catálogo y stock transaccional | Pendiente |
| 3 | Tienda pública, banners, búsqueda y carrito | Pendiente |
| 4 | Pedidos, WhatsApp, envíos y seguimiento | Pendiente |
| 5 | POS, caja, devoluciones y recibos PDF | Pendiente |
| 6 | Dashboard con métricas reales y configuración | Pendiente |
| 7 | Seguridad, pruebas integrales, despliegue | Pendiente |

## Ampliación de Fase 2 (2026-11-20)

- `supabase/migrations/20261120000600_phase2_catalog_operations.sql`: RPC de gestión y ajuste atómico, seguridad y políticas de Storage para imágenes.
- `src/features/catalog/api.ts`: cliente tipado para operaciones del catálogo vía RPC, fotos y formato COP.
- `src/features/catalog/hooks.ts`: caché de lectura e invalidación con TanStack Query.
- `src/pages/CategoriesPage.tsx`, `ProductsPage.tsx`, `ProductEditorPage.tsx`, `OptionsPage.tsx`, `InventoryPage.tsx`: módulos protegidos por ruta y permiso.
- Las mutaciones usan funciones `SECURITY DEFINER` con `search_path=''` y permiso verificado *dentro de cada función*; la clave pública de React no otorga permisos elevados.
- No se implementan transacciones de venta ni reserva de stock en esta etapa; solo movimientos manuales auditables.

## Ampliación Fase 3 — Catálogo web público

- `src/features/storefront/api.ts`: lectura por RPC pública `storefront_data` de campos seguros; URLs de imágenes desde Storage.
- `src/features/storefront/hooks.ts`: caché TanStack Query para la tienda.
- `src/features/storefront/cart.tsx`: carrito y favoritos del navegador; sin pagos, órdenes ni reservas.
- `src/features/storefront/ui.tsx`: tarjetas de productos reales con imágenes o marcador.
- `src/pages/HomePage.tsx`, `ShopPage.tsx`, `ProductDetailPage.tsx`, `CartPage.tsx`, `FavoritesPage.tsx`, `AboutStorePage.tsx`: experiencia pública.
- `src/pages/BannersPage.tsx`: administración de banners protegida por el permiso `banners.manage`.
- `supabase/migrations/20261120000700_phase3_public_storefront.sql`: función pública de catálogo (sin costos) + CRUD de banners con privilegios de servidor.

**Principio de seguridad:** el navegador nunca accede directamente a datos de administración para construir el catálogo público. El RPC público expone campos concretos y filtra por producto activo, no archivado y categoría activa. El carrito local no mueve stock ni constituye un pedido. Es obligatorio revalidar stock al implementar compras en Fase 4.
