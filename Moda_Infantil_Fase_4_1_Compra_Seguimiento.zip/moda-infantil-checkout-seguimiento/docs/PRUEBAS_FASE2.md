# Lista de comprobación — Moda Infantil Fase 2

- [ ] Aplicar migración 006 sin errores (una sola vez).
- [ ] Ejecutar `npm run build` en tu máquina y corregir cualquier error de compilación.
- [ ] Administrador puede ver menú y crear una categoría.
- [ ] Crear categoría con slug único, cambiar su estado y subir foto.
- [ ] Crear producto con precio y costo; lista muestra producto y precio correcto.
- [ ] Editar nombre, categoría, precio, destacado y novedad.
- [ ] Archivar producto sin borrar movimientos.
- [ ] Registrar tallas y colores nuevos.
- [ ] Registrar dos variantes distintas de un producto con SKU único.
- [ ] Intentar repetir SKU o combinación talla/color: operación rechazada.
- [ ] Subir JPG/PNG/WebP menor a 5 MB y eliminarla; rechazar archivo de mayor tamaño.
- [ ] Una entrada de +8 solo cambia el stock de la variante elegida.
- [ ] Una salida de -5 produce saldo correcto y deja historial.
- [ ] Salida mayor al saldo se rechaza sin variar el inventario.
- [ ] Dos operadores con inventario suficiente deben poder ajustar sin perder actualizaciones; probar concurrencia.
- [ ] Repetir el mismo `p_request_id` no debe aplicar el movimiento otra vez.
- [ ] El cliente no puede consultar datos de gestión ni escribir productos o existencias.
- [ ] Supervisor puede ver y ajustar stock, pero no crear productos.
- [ ] Cajero puede consultar pero no ajustar stock.
- [ ] La vista pública no divulga `cost_price`.

## Consultas de diagnóstico en SQL Editor

```sql
select id, name, slug, is_active from public.categories order by name;
select id, name, sale_price, is_active from public.products order by created_at desc limit 10;
select v.sku, i.quantity, i.low_stock_threshold
from public.product_variants v join public.inventory i on i.variant_id=v.id
order by v.sku;
select movement_type, quantity_delta, balance_after, reason, created_at
from public.inventory_movements order by created_at desc limit 20;
```

**Advertencia:** SQL Editor usa permisos elevados; consultas exitosas allí NO demuestran que un cliente normal tenga permiso. Para verificar RLS, utiliza una sesión cliente real o pruebas con rol `authenticated` y JWT correspondiente.
